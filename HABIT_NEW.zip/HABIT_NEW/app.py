import streamlit as st
from src.signup import render_signup
from src.signin import render_signin
from src.habits import create_habit, list_habits
from src.logs import mark_today, is_marked_today, recent_logs
from src.profile import get_profile, upsert_profile
from src.auth import get_session_version, bump_session_version
from src.frequency import VALID_FREQUENCIES, set_frequency_by_name, get_frequencies_for_user, set_frequency
from src.habit_manage import update_habit, delete_habit
from src.category import (
    get_categories_for_user,
    get_category_map_for_user,
    set_category_by_name,
    set_category,
)
from src.status import complete_habit, reopen_habit, get_completion_map_for_user
from src.calendar_view import render_calendar_block
from src.progress import get_progress_for_user
from src.summaries import render_summaries_block
from src.log_edit import undo_today as undo_today_log, add_log_on, remove_log_on, list_recent_logs
from src.notifications import get_notification_settings_page, check_and_show_notifications
from src.habit_reminders import get_habit_reminders_manager, check_and_show_reminders
from src.snooze_system import render_snooze_manager, check_and_show_expired_snoozes
from src.daily_summary import check_and_show_daily_summary, render_daily_summary_manager, create_daily_summary_table
try:
    from src.init_all_tables import create_all_tables
    INIT_TABLES_AVAILABLE = True
except ImportError:
    INIT_TABLES_AVAILABLE = False
from src.notification_settings import render_notification_manager
from src.habit_progress_charts import render_progress_manager
from src.streak_tracker import render_streak_manager
from src.habit_consistency_analyzer import render_consistency_manager
from src.motivational_tips_system import render_motivational_manager, get_daily_motivation, render_motivational_card
from src.badge_system import render_badge_center, check_and_award_badges, render_badge_overview


def is_authenticated() -> bool:
    if not st.session_state.get("auth_provider"):
        return False
    email = st.session_state.get("user_email")
    sess_ver = st.session_state.get("session_version", 0)
    try:
        current = get_session_version(email)
        if current != sess_ver:
            sign_out()
            return False
    except Exception:
        pass
    return True


def sign_out():
    st.session_state.pop("auth_provider", None)
    st.session_state.pop("user_email", None)
    st.session_state.pop("route", None)


def set_route(route: str):
    st.session_state["route"] = route


def get_route(default: str = "auth") -> str:
    return st.session_state.get("route", default)


def dashboard():
    st.title("Habit Tracker Dashboard")
    st.write("Welcome! You're signed in as:")
    st.code(f"{st.session_state.get('user_email')}")

    # Check and show daily summary at the top
    check_and_show_daily_summary(st.session_state.get("user_email"))
    
    # Show daily motivational content
    daily_motivation = get_daily_motivation(st.session_state.get("user_email"))
    if daily_motivation['quote'] or daily_motivation['tip']:
        st.markdown("---")
        st.subheader("🌟 Today's Motivation")
        
        if daily_motivation['quote']:
            render_motivational_card(daily_motivation['quote'], 'quote')
        
        if daily_motivation['tip']:
            render_motivational_card(daily_motivation['tip'], 'tip')
    
    # Check for new badges and show overview
    newly_earned = check_and_award_badges(st.session_state.get("user_email"))
    
    # Show badge overview
    st.markdown("---")
    render_badge_overview(st.session_state.get("user_email"))

    tabs = st.tabs(["Habits", "Notifications", "Reminders", "Snooze", "Daily Summary", "Notification Settings", "Progress Charts", "Streak Tracker", "Consistency Analyzer", "Motivational Center", "Badge Center", "Profile"])
    with tabs[0]:
        st.subheader("Your habits")
        with st.form("add_habit_form", clear_on_submit=True):
            new_name = st.text_input("New habit name")
            goal = st.number_input("Daily goal", min_value=1, value=1, step=1)
            freq = st.selectbox("Frequency", options=VALID_FREQUENCIES, index=0)
            # categories: choose existing or type your own (no '(none)' option)
            existing_cats = []
            try:
                existing_cats = get_categories_for_user(st.session_state.get("user_email", "")) or []
            except Exception:
                existing_cats = []
            # filter out any accidental sentinel values stored earlier
            existing_cats = [c for c in existing_cats if c not in ("(add new)", "(none)")]
            cat_choice = None
            if existing_cats:
                cat_choice = st.selectbox("Category", options=existing_cats, index=0, key="create_cat_choice")
            submitted = st.form_submit_button("Add habit")
            if submitted and new_name:
                if create_habit(st.session_state["user_email"], new_name, goal):
                    # store frequency separately
                    try:
                        set_frequency_by_name(st.session_state["user_email"], new_name, freq)
                    except Exception:
                        pass
                    # store category separately
                    try:
                        final_cat = cat_choice if cat_choice else None
                        if final_cat is not None:
                            set_category_by_name(st.session_state["user_email"], new_name, final_cat)
                    except Exception:
                        pass
                    st.success("Habit added")
                    st.rerun()

        habits = list_habits(st.session_state["user_email"]) or []
        if not habits:
            st.info("No habits yet. Add your first one above.")
        else:
            # one-shot fetch of frequencies for display and editing
            freq_map = {}
            try:
                freq_map = get_frequencies_for_user(st.session_state["user_email"]) or {}
            except Exception:
                freq_map = {}
            # one-shot fetch of categories for display and editing (no '(none)' option)
            cat_map = {}
            cat_choices = []
            try:
                cat_map = get_category_map_for_user(st.session_state["user_email"]) or {}
                existing_cats_all = get_categories_for_user(st.session_state["user_email"]) or []
                existing_cats_all = [c for c in existing_cats_all if c not in ("(add new)", "(none)")]
                cat_choices = list(existing_cats_all)
            except Exception:
                cat_map = {}
            # completion map and filter
            comp_map = {}
            try:
                comp_map = get_completion_map_for_user(st.session_state["user_email"]) or {}
            except Exception:
                comp_map = {}
            # progress map (last 30 days)
            prog_map = {}
            try:
                prog_map = get_progress_for_user(st.session_state["user_email"], window_days=30) or {}
            except Exception:
                prog_map = {}
            view_filter = st.selectbox("Show habits", options=["All", "Active", "Completed"], index=0, key="habit_view_filter")
            for hid, name, goal, is_active in habits:
                completed = bool(comp_map.get(hid, False))
                if view_filter == "Active" and completed:
                    continue
                if view_filter == "Completed" and not completed:
                    continue
                col1, col2, col3 = st.columns([3, 1.5, 3])
                with col1:
                    current_freq = freq_map.get(hid, "daily")
                    current_cat = cat_map.get(hid)
                    cat_label = current_cat if current_cat else "uncategorized"
                    status_label = "completed" if completed else ("active" if is_active else "inactive")
                    st.write(f"• {name} (goal: {goal}, {current_freq}, {cat_label}, {status_label})")
                    # allow inline update of frequency per habit
                    new_freq = st.selectbox(
                        "Set frequency",
                        options=VALID_FREQUENCIES,
                        index=VALID_FREQUENCIES.index(current_freq) if current_freq in VALID_FREQUENCIES else 0,
                        key=f"freq_sel_{hid}",
                    )
                    if st.button("Update", key=f"freq_upd_{hid}"):
                        try:
                            if set_frequency(hid, new_freq):
                                st.toast("Frequency updated")
                                st.rerun()
                            else:
                                st.warning("Failed to update frequency")
                        except Exception:
                            st.warning("Failed to update frequency")
                    # inline update of category
                    new_cat_choice = None
                    if cat_choices:
                        cat_index = cat_choices.index(current_cat) if (current_cat and current_cat in cat_choices) else 0
                        new_cat_choice = st.selectbox(
                            "Set category",
                            options=cat_choices,
                            index=cat_index,
                            key=f"cat_sel_{hid}",
                        )
                    if st.button("Save category", key=f"cat_upd_{hid}"):
                        try:
                            final_cat2 = new_cat_choice if new_cat_choice else None
                            if final_cat2 is not None and set_category(hid, final_cat2):
                                st.toast("Category updated")
                                st.rerun()
                            else:
                                st.warning("Failed to update category")
                        except Exception:
                            st.warning("Failed to update category")
                    with st.expander("Edit habit", expanded=False):
                        new_name = st.text_input("Name", value=name, key=f"edit_name_{hid}")
                        new_goal = st.number_input("Goal", min_value=1, value=int(goal), step=1, key=f"edit_goal_{hid}")
                        active = st.checkbox("Active", value=bool(is_active), key=f"edit_active_{hid}")
                        c1, c2 = st.columns(2)
                        with c1:
                            if st.button("Save", key=f"save_habit_{hid}"):
                                ok = update_habit(hid, name=new_name, goal=int(new_goal), is_active=1 if active else 0)
                                if ok:
                                    st.success("Habit updated")
                                    st.rerun()
                                else:
                                    st.error("Failed to update habit")
                        with c2:
                            if st.button("Delete", key=f"del_habit_{hid}"):
                                if delete_habit(hid):
                                    st.success("Habit deleted")
                                    st.rerun()
                                else:
                                    st.error("Failed to delete habit")
                with col2:
                    marked = is_marked_today(hid)
                    if marked:
                        st.success("Marked today")
                        if st.button("Undo today", key=f"undo_{hid}"):
                            if undo_today_log(hid):
                                st.toast("Undid today's mark")
                                st.rerun()
                    else:
                        if st.button("Mark today", key=f"mark_{hid}"):
                            if mark_today(hid):
                                st.toast(f"Marked {name} for today")
                                st.rerun()
                    with st.expander("Edit logs", expanded=False):
                        edit_date = st.date_input("Pick a date", key=f"edit_date_{hid}")
                        c_add, c_rm = st.columns(2)
                        with c_add:
                            if st.button("Add log", key=f"add_log_{hid}"):
                                if add_log_on(hid, edit_date):
                                    st.toast("Log added")
                                    st.rerun()
                                else:
                                    st.warning("Could not add log (maybe exists)")
                        with c_rm:
                            if st.button("Remove log", key=f"rm_log_{hid}"):
                                if remove_log_on(hid, edit_date):
                                    st.toast("Log removed")
                                    st.rerun()
                                else:
                                    st.warning("No log to remove on that date")
                    # status actions
                    if completed:
                        if st.button("Reopen", key=f"reopen_{hid}"):
                            if reopen_habit(hid):
                                st.toast("Habit reopened")
                                st.rerun()
                    else:
                        if st.button("Mark completed", key=f"complete_{hid}"):
                            if complete_habit(hid):
                                st.toast("Habit marked as completed")
                                st.rerun()
                with col3:
                    logs = [str(d[0]) for d in recent_logs(hid, limit=5)]
                    st.caption("Recent: " + ", ".join(logs) if logs else "No logs yet")
                    # progress bar (last 30 days)
                    ach, exp, pct = prog_map.get(hid, (0, 0, 0))
                    st.progress(pct, text=f"{pct}% of last 30 days ({ach}/{exp})")
                    with st.expander("Calendar", expanded=False):
                        render_calendar_block(hid)
                    with st.expander("Summaries", expanded=False):
                        render_summaries_block(hid)

    with tabs[1]:
        # Check for pending notifications and show them
        check_and_show_notifications(st.session_state.get("user_email"))
        get_notification_settings_page(st.session_state.get("user_email"))

    with tabs[2]:
        # Check for pending reminders and show them
        check_and_show_reminders(st.session_state.get("user_email"))
        get_habit_reminders_manager(st.session_state.get("user_email"))

    with tabs[3]:
        # Check for expired snoozes and show them
        check_and_show_expired_snoozes(st.session_state.get("user_email"))
        render_snooze_manager(st.session_state.get("user_email"))

    with tabs[4]:
        render_daily_summary_manager(st.session_state.get("user_email"))

    with tabs[5]:
        render_notification_manager(st.session_state.get("user_email"))

    with tabs[6]:
        render_progress_manager(st.session_state.get("user_email"))

    with tabs[7]:
        render_streak_manager(st.session_state.get("user_email"))

    with tabs[8]:
        render_consistency_manager(st.session_state.get("user_email"))

    with tabs[9]:
        render_motivational_manager(st.session_state.get("user_email"))

    with tabs[10]:
        render_badge_center(st.session_state.get("user_email"))

    with tabs[11]:
        st.subheader("Your profile")
        email = st.session_state.get("user_email")
        prof = get_profile(email)
        if prof.get("picture"):
            st.image(prof["picture"], caption="Current picture", use_column_width=False)
        with st.form("profile_form"):
            full_name = st.text_input("Full name", value=prof.get("full_name", ""))
            address = st.text_area("Address", value=prof.get("address", ""))
            bio = st.text_area("Bio", value=prof.get("bio", ""))
            uploaded = st.file_uploader("Profile picture", type=["png", "jpg", "jpeg"], accept_multiple_files=False)
            remove_pic = st.checkbox("Remove existing picture", value=False)
            save = st.form_submit_button("Save profile")
            if save:
                pic_bytes = uploaded.read() if uploaded is not None else None
                ok = upsert_profile(email, full_name, address, bio, pic_bytes, remove_picture=remove_pic)
                if ok:
                    st.success("Profile saved")
                    st.rerun()
                else:
                    st.error("Failed to save profile")
    colA, colB = st.columns(2)
    with colA:
        if st.button("Sign out"):
            sign_out()
            st.rerun()
    with colB:
        if st.button("Log out from all devices"):
            try:
                if bump_session_version(st.session_state.get("user_email")):
                    sign_out()
                    st.success("All sessions invalidated")
                    st.rerun()
                else:
                    st.error("Failed to invalidate sessions")
            except Exception:
                st.error("Failed to invalidate sessions")


def auth_gate():
    st.title("Welcome to Habit Tracker")
    st.caption("Sign up or sign in to continue")
    tabs = st.tabs(["Sign up", "Sign in"])
    with tabs[0]:
        render_signup()
    with tabs[1]:
        render_signin()
        if st.button("Forgot password?", key="forgot_pw_btn"):
            set_route("reset")
            st.rerun()
    if is_authenticated():
        st.rerun()


def reset_page():
    from src.reset_password import render_reset_password
    st.title("Reset your password")
    render_reset_password()
    if st.button("Back to Sign in"):
        set_route("auth")
        st.rerun()


def main():
    st.set_page_config(page_title="Habit Tracker", page_icon="✅", layout="centered")
    
    # Initialize all database tables if available
    if INIT_TABLES_AVAILABLE:
        try:
            create_all_tables()
        except Exception as e:
            st.warning(f"Could not initialize all tables: {e}")
    
    # Initialize required tables
    create_daily_summary_table()

    if is_authenticated():
        dashboard()
    else:
        route = get_route("auth")
        if route == "reset":
            reset_page()
        else:
            auth_gate()


if __name__ == "__main__":
    main()
