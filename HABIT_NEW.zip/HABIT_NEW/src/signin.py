import streamlit as st
from .auth import verify_user_email, get_session_version


def render_signin():
    st.subheader("Email sign in")
    email = st.text_input("Email", key="signin_email")
    password = st.text_input("Password", type="password", key="signin_password")
    if st.button("Sign in"):
        if not email or not password:
            st.error("Enter email and password")
            return
        ok = verify_user_email(email, password)
        if ok:
            st.success("Signed in")
            st.session_state["user_email"] = email.lower()
            st.session_state["auth_provider"] = "email"
            try:
                st.session_state["session_version"] = get_session_version(email)
            except Exception:
                st.session_state["session_version"] = 0
        else:
            st.error("Invalid credentials")
