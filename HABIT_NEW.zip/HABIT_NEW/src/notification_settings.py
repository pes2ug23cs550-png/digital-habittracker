import streamlit as st
import mysql.connector
from datetime import datetime, time, timedelta
from typing import List, Dict, Optional, Tuple
import json

from src.db import get_db_connection

def create_notification_settings_table():
    """Create notification_settings table if it doesn't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notification_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                notification_tone VARCHAR(50) DEFAULT 'default',
                volume_level INT DEFAULT 70,
                vibration_enabled BOOLEAN DEFAULT TRUE,
                led_notification BOOLEAN DEFAULT TRUE,
                sound_enabled BOOLEAN DEFAULT TRUE,
                do_not_disturb_start TIME,
                do_not_disturb_end TIME,
                do_not_disturb_enabled BOOLEAN DEFAULT FALSE,
                quiet_hours_weekend BOOLEAN DEFAULT TRUE,
                repeat_reminder_interval INT DEFAULT 5,
                max_repeat_attempts INT DEFAULT 3,
                priority_notifications BOOLEAN DEFAULT TRUE,
                group_notifications BOOLEAN DEFAULT FALSE,
                notification_style ENUM('simple', 'detailed', 'minimal') DEFAULT 'simple',
                custom_message_template TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_email (user_email),
                INDEX idx_user_email (user_email)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notification_tones (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tone_name VARCHAR(100) NOT NULL,
                tone_file VARCHAR(255) NOT NULL,
                category VARCHAR(50) DEFAULT 'general',
                is_premium BOOLEAN DEFAULT FALSE,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_category (category),
                INDEX idx_active (is_active)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notification_preferences (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT,
                notification_type ENUM('habit_reminder', 'daily_summary', 'streak_milestone', 'goal_achievement') NOT NULL,
                custom_tone VARCHAR(50),
                custom_volume INT,
                custom_vibration BOOLEAN,
                custom_led BOOLEAN,
                custom_repeat_interval INT,
                is_enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user_email (user_email),
                INDEX idx_habit_id (habit_id),
                INDEX idx_notification_type (notification_type)
            )
        """)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def initialize_default_tones():
    """Initialize default notification tones"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if tones already exist
        cursor.execute("SELECT COUNT(*) FROM notification_tones")
        if cursor.fetchone()[0] > 0:
            return
        
        # Insert default tones
        default_tones = [
            ('default', 'sounds/default.mp3', 'general', False),
            ('gentle', 'sounds/gentle.mp3', 'calm', False),
            ('energetic', 'sounds/energetic.mp3', 'energetic', False),
            ('chime', 'sounds/chime.mp3', 'classic', False),
            ('bell', 'sounds/bell.mp3', 'classic', False),
            ('digital', 'sounds/digital.mp3', 'modern', False),
            ('nature', 'sounds/nature.mp3', 'calm', False),
            ('motivation', 'sounds/motivation.mp3', 'energetic', True),
            ('achievement', 'sounds/achievement.mp3', 'celebration', True),
            ('zen', 'sounds/zen.mp3', 'calm', True)
        ]
        
        cursor.executemany("""
            INSERT INTO notification_tones (tone_name, tone_file, category, is_premium)
            VALUES (%s, %s, %s, %s)
        """, default_tones)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def get_notification_settings(user_email: str) -> Optional[Dict]:
    """Get notification settings for a user"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT * FROM notification_settings WHERE user_email = %s
        """, (user_email.lower(),))
        result = cursor.fetchone()
        return result
    finally:
        cursor.close()
        conn.close()

def create_or_update_notification_settings(user_email: str, settings: Dict) -> bool:
    """Create or update notification settings"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            INSERT INTO notification_settings 
            (user_email, notification_tone, volume_level, vibration_enabled, 
             led_notification, sound_enabled, do_not_disturb_start, do_not_disturb_end,
             do_not_disturb_enabled, quiet_hours_weekend, repeat_reminder_interval,
             max_repeat_attempts, priority_notifications, group_notifications,
             notification_style, custom_message_template)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
            notification_tone = VALUES(notification_tone),
            volume_level = VALUES(volume_level),
            vibration_enabled = VALUES(vibration_enabled),
            led_notification = VALUES(led_notification),
            sound_enabled = VALUES(sound_enabled),
            do_not_disturb_start = VALUES(do_not_disturb_start),
            do_not_disturb_end = VALUES(do_not_disturb_end),
            do_not_disturb_enabled = VALUES(do_not_disturb_enabled),
            quiet_hours_weekend = VALUES(quiet_hours_weekend),
            repeat_reminder_interval = VALUES(repeat_reminder_interval),
            max_repeat_attempts = VALUES(max_repeat_attempts),
            priority_notifications = VALUES(priority_notifications),
            group_notifications = VALUES(group_notifications),
            notification_style = VALUES(notification_style),
            custom_message_template = VALUES(custom_message_template),
            updated_at = CURRENT_TIMESTAMP
        """, (user_email.lower(), 
              settings.get('notification_tone', 'default'),
              settings.get('volume_level', 70),
              settings.get('vibration_enabled', True),
              settings.get('led_notification', True),
              settings.get('sound_enabled', True),
              settings.get('do_not_disturb_start'),
              settings.get('do_not_disturb_end'),
              settings.get('do_not_disturb_enabled', False),
              settings.get('quiet_hours_weekend', True),
              settings.get('repeat_reminder_interval', 5),
              settings.get('max_repeat_attempts', 3),
              settings.get('priority_notifications', True),
              settings.get('group_notifications', False),
              settings.get('notification_style', 'simple'),
              settings.get('custom_message_template')))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error saving notification settings: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_available_tones() -> List[Dict]:
    """Get all available notification tones"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT * FROM notification_tones WHERE is_active = TRUE ORDER BY category, tone_name
        """)
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def get_tone_preview_url(tone_name: str) -> str:
    """Get preview URL for a tone (simulated)"""
    return f"https://example.com/tones/{tone_name}.mp3"

def is_do_not_disturb_active(user_email: str) -> bool:
    """Check if Do Not Disturb is currently active for user"""
    settings = get_notification_settings(user_email)
    if not settings or not settings['do_not_disturb_enabled']:
        return False
    
    now = datetime.now().time()
    start_time = settings['do_not_disturb_start']
    end_time = settings['do_not_disturb_end']
    
    if not start_time or not end_time:
        return False
    
    # Check if current time is within DND range
    if start_time <= end_time:
        # Normal case (e.g., 22:00 to 07:00 crosses midnight)
        return start_time <= now <= end_time
    else:
        # Crosses midnight (e.g., 22:00 to 07:00)
        return now >= start_time or now <= end_time

def should_send_notification(user_email: str, notification_type: str, habit_id: Optional[int] = None) -> bool:
    """Check if notification should be sent based on settings"""
    # Check Do Not Disturb
    if is_do_not_disturb_active(user_email):
        return False
    
    # Check weekend quiet hours
    settings = get_notification_settings(user_email)
    if settings and settings['quiet_hours_weekend']:
        now = datetime.now()
        if now.weekday() >= 5:  # Saturday or Sunday
            return False
    
    # Check specific notification preferences
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT is_enabled FROM notification_preferences 
            WHERE user_email = %s AND notification_type = %s 
            AND (habit_id = %s OR habit_id IS NULL)
            ORDER BY habit_id DESC LIMIT 1
        """, (user_email.lower(), notification_type, habit_id))
        result = cursor.fetchone()
        
        if result:
            return result['is_enabled']
        
        return True  # Default to enabled if no specific preference
    finally:
        cursor.close()
        conn.close()

def get_notification_sound(user_email: str, notification_type: str, habit_id: Optional[int] = None) -> Dict:
    """Get notification sound settings for specific notification"""
    settings = get_notification_settings(user_email)
    if not settings:
        return {'tone': 'default', 'volume': 70, 'vibration': True, 'led': True}
    
    # Check for specific notification preferences
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT * FROM notification_preferences 
            WHERE user_email = %s AND notification_type = %s 
            AND (habit_id = %s OR habit_id IS NULL)
            ORDER BY habit_id DESC LIMIT 1
        """, (user_email.lower(), notification_type, habit_id))
        pref = cursor.fetchone()
        
        if pref:
            return {
                'tone': pref['custom_tone'] or settings['notification_tone'],
                'volume': pref['custom_volume'] or settings['volume_level'],
                'vibration': pref['custom_vibration'] if pref['custom_vibration'] is not None else settings['vibration_enabled'],
                'led': pref['custom_led'] if pref['custom_led'] is not None else settings['led_notification']
            }
        
        return {
            'tone': settings['notification_tone'],
            'volume': settings['volume_level'],
            'vibration': settings['vibration_enabled'],
            'led': settings['led_notification']
        }
    finally:
        cursor.close()
        conn.close()

def render_tone_selector(selected_tone: str = 'default') -> str:
    """Render tone selection interface"""
    tones = get_available_tones()
    
    # Group tones by category
    categories = {}
    for tone in tones:
        if tone['category'] not in categories:
            categories[tone['category']] = []
        categories[tone['category']].append(tone)
    
    selected_category = st.selectbox(
        "Tone Category",
        options=list(categories.keys()),
        index=0
    )
    
    category_tones = categories[selected_category]
    tone_options = []
    tone_labels = []
    
    for tone in category_tones:
        tone_options.append(tone['tone_name'])
        label = tone['tone_name']
        if tone['is_premium']:
            label += " 🌟"
        tone_labels.append(label)
    
    selected_index = tone_options.index(selected_tone) if selected_tone in tone_options else 0
    chosen_tone = st.selectbox(
        "Select Tone",
        options=tone_options,
        format_func=lambda x: tone_labels[tone_options.index(x)],
        index=selected_index
    )
    
    # Show preview info (use form-safe submit button)
    col1, col2 = st.columns([1, 3])
    with col1:
        if st.form_submit_button("🔊 Preview", use_container_width=True):
            st.info(f"Playing preview: {chosen_tone}")
            # In a real implementation, this would play the sound
    with col2:
        st.info(f"Selected: {chosen_tone}")
    
    return chosen_tone

def render_notification_settings_form(user_email: str):
    """Render comprehensive notification settings form"""
    st.subheader("🔔 Notification Settings")
    
    # Get current settings
    current_settings = get_notification_settings(user_email)
    
    # Default settings if none exist
    if not current_settings:
        current_settings = {
            'notification_tone': 'default',
            'volume_level': 70,
            'vibration_enabled': True,
            'led_notification': True,
            'sound_enabled': True,
            'do_not_disturb_start': None,
            'do_not_disturb_end': None,
            'do_not_disturb_enabled': False,
            'quiet_hours_weekend': True,
            'repeat_reminder_interval': 5,
            'max_repeat_attempts': 3,
            'priority_notifications': True,
            'group_notifications': False,
            'notification_style': 'simple',
            'custom_message_template': None
        }
    
    with st.form("notification_settings_form"):
        st.write("**Sound Settings**")
        
        # Sound enabled
        sound_enabled = st.checkbox("Enable Sound", value=current_settings['sound_enabled'])
        
        if sound_enabled:
            # Tone selection
            st.write("**Notification Tone**")
            notification_tone = render_tone_selector(current_settings['notification_tone'])
            
            # Volume
            volume_level = st.slider("Volume Level", 0, 100, current_settings['volume_level'])
            
            # Vibration
            vibration_enabled = st.checkbox("Enable Vibration", value=current_settings['vibration_enabled'])
            
            # LED notification
            led_notification = st.checkbox("Enable LED Notification", value=current_settings['led_notification'])
        else:
            notification_tone = current_settings['notification_tone']
            volume_level = current_settings['volume_level']
            vibration_enabled = current_settings['vibration_enabled']
            led_notification = current_settings['led_notification']
        
        st.write("---")
        st.write("**Do Not Disturb**")
        
        do_not_disturb_enabled = st.checkbox("Enable Do Not Disturb", value=current_settings['do_not_disturb_enabled'])
        
        if do_not_disturb_enabled:
            col1, col2 = st.columns(2)
            with col1:
                start_time = st.time_input(
                    "From",
                    value=current_settings['do_not_disturb_start'] or time(22, 0)
                )
            with col2:
                end_time = st.time_input(
                    "To",
                    value=current_settings['do_not_disturb_end'] or time(7, 0)
                )
            
            quiet_hours_weekend = st.checkbox(
                "Also apply to weekends",
                value=current_settings['quiet_hours_weekend']
            )
        else:
            start_time = current_settings['do_not_disturb_start']
            end_time = current_settings['do_not_disturb_end']
            quiet_hours_weekend = current_settings['quiet_hours_weekend']
        
        st.write("---")
        st.write("**Reminder Behavior**")
        
        col1, col2 = st.columns(2)
        with col1:
            repeat_interval = st.number_input(
                "Repeat Reminder Every (minutes)",
                min_value=1,
                max_value=60,
                value=current_settings['repeat_reminder_interval']
            )
        with col2:
            max_attempts = st.number_input(
                "Max Repeat Attempts",
                min_value=1,
                max_value=10,
                value=current_settings['max_repeat_attempts']
            )
        
        st.write("---")
        st.write("**Notification Style**")
        
        notification_style = st.selectbox(
            "Notification Style",
            options=['simple', 'detailed', 'minimal'],
            index=['simple', 'detailed', 'minimal'].index(current_settings['notification_style'])
        )
        
        priority_notifications = st.checkbox(
            "Priority Notifications (bypass DND for important items)",
            value=current_settings['priority_notifications']
        )
        
        group_notifications = st.checkbox(
            "Group Similar Notifications",
            value=current_settings['group_notifications']
        )
        
        st.write("---")
        st.write("**Custom Message Template**")
        
        custom_template = st.text_area(
            "Custom Message Template (use {habit_name}, {time}, {goal} placeholders)",
            value=current_settings['custom_message_template'] or "",
            placeholder="Time to {habit_name}! Goal: {goal} at {time}"
        )
        
        submitted = st.form_submit_button("Save Settings")
        
        if submitted:
            settings = {
                'notification_tone': notification_tone,
                'volume_level': volume_level,
                'vibration_enabled': vibration_enabled,
                'led_notification': led_notification,
                'sound_enabled': sound_enabled,
                'do_not_disturb_start': start_time,
                'do_not_disturb_end': end_time,
                'do_not_disturb_enabled': do_not_disturb_enabled,
                'quiet_hours_weekend': quiet_hours_weekend,
                'repeat_reminder_interval': repeat_interval,
                'max_repeat_attempts': max_attempts,
                'priority_notifications': priority_notifications,
                'group_notifications': group_notifications,
                'notification_style': notification_style,
                'custom_message_template': custom_template if custom_template.strip() else None
            }
            
            success = create_or_update_notification_settings(user_email, settings)
            if success:
                st.success("Notification settings saved successfully!")
                st.rerun()

def render_habit_specific_settings(user_email: str):
    """Render habit-specific notification preferences"""
    st.subheader("🎯 Habit-Specific Settings")
    
    # Get user habits
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT id, name FROM habits WHERE user_email = %s AND is_active = TRUE
            ORDER BY name
        """, (user_email.lower(),))
        habits = cursor.fetchall()
        
        if not habits:
            st.info("No habits found. Create some habits first!")
            return
        
        # Select habit (use unique key to avoid duplicate widget IDs)
        selected_habit = st.selectbox(
            "Select Habit",
            options=habits,
            format_func=lambda x: x['name'],
            key=f"habit_select_{user_email}"
        )
        
        if not selected_habit:
            return
        
        habit_id = selected_habit['id']
        habit_name = selected_habit['name']
        
        # Get current preferences for this habit
        cursor.execute("""
            SELECT * FROM notification_preferences 
            WHERE user_email = %s AND habit_id = %s
        """, (user_email.lower(), habit_id))
        current_pref = cursor.fetchone()
        
        with st.form(f"habit_settings_{habit_id}"):
            st.write(f"**Settings for: {habit_name}**")
            
            is_enabled = st.checkbox(
                "Enable Notifications",
                value=current_pref['is_enabled'] if current_pref else True
            )
            
            if is_enabled:
                # Custom tone
                st.write("**Custom Sound**")
                use_custom_tone = st.checkbox("Use Custom Tone", value=current_pref is not None)
                
                if use_custom_tone:
                    custom_tone = render_tone_selector(current_pref['custom_tone'] if current_pref else 'default')
                    custom_volume = st.slider(
                        "Custom Volume",
                        0, 100,
                        current_pref['custom_volume'] if current_pref else 70
                    )
                    custom_vibration = st.checkbox(
                        "Custom Vibration",
                        value=current_pref['custom_vibration'] if current_pref is not None else True
                    )
                    custom_led = st.checkbox(
                        "Custom LED",
                        value=current_pref['custom_led'] if current_pref is not None else True
                    )
                    custom_repeat = st.number_input(
                        "Custom Repeat Interval (minutes)",
                        min_value=1, max_value=60,
                        value=current_pref['custom_repeat_interval'] if current_pref else 5
                    )
                else:
                    custom_tone = None
                    custom_volume = None
                    custom_vibration = None
                    custom_led = None
                    custom_repeat = None
            else:
                use_custom_tone = False
                custom_tone = None
                custom_volume = None
                custom_vibration = None
                custom_led = None
                custom_repeat = None
            
            submitted = st.form_submit_button("Save Habit Settings")
            
            if submitted:
                conn = get_db_connection()
                cursor2 = conn.cursor()
                
                try:
                    if use_custom_tone:
                        cursor2.execute("""
                            INSERT INTO notification_preferences 
                            (user_email, habit_id, notification_type, custom_tone, 
                             custom_volume, custom_vibration, custom_led, 
                             custom_repeat_interval, is_enabled)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                            ON DUPLICATE KEY UPDATE
                            custom_tone = VALUES(custom_tone),
                            custom_volume = VALUES(custom_volume),
                            custom_vibration = VALUES(custom_vibration),
                            custom_led = VALUES(custom_led),
                            custom_repeat_interval = VALUES(custom_repeat_interval),
                            is_enabled = VALUES(is_enabled),
                            updated_at = CURRENT_TIMESTAMP
                        """, (user_email.lower(), habit_id, 'habit_reminder',
                              custom_tone, custom_volume, custom_vibration, 
                              custom_led, custom_repeat, is_enabled))
                    else:
                        cursor2.execute("""
                            INSERT INTO notification_preferences 
                            (user_email, habit_id, notification_type, is_enabled)
                            VALUES (%s, %s, %s, %s)
                            ON DUPLICATE KEY UPDATE
                            is_enabled = VALUES(is_enabled),
                            updated_at = CURRENT_TIMESTAMP
                        """, (user_email.lower(), habit_id, 'habit_reminder', is_enabled))
                    
                    conn.commit()
                    st.success(f"Settings saved for {habit_name}!")
                    st.rerun()
                finally:
                    cursor2.close()
                    conn.close()
    
    finally:
        cursor.close()
        conn.close()

def render_notification_manager(user_email: str):
    """Main notification settings manager"""
    st.title("🔔 Notification Settings Manager")
    
    # Create tables if they don't exist
    create_notification_settings_table()
    initialize_default_tones()
    
    # Tab layout
    tab1, tab2, tab3 = st.tabs(["⚙️ General Settings", "🎯 Per-Habit Settings", "🔊 Tone Library"])
    
    with tab1:
        render_notification_settings_form(user_email)
    
    with tab2:
        render_habit_specific_settings(user_email)
    
    with tab3:
        st.subheader("🔊 Available Notification Tones")
        
        tones = get_available_tones()
        categories = {}
        for tone in tones:
            if tone['category'] not in categories:
                categories[tone['category']] = []
            categories[tone['category']].append(tone)
        
        for category, category_tones in categories.items():
            st.write(f"**{category.title()}**")
            
            for tone in category_tones:
                col1, col2, col3 = st.columns([2, 1, 1])
                with col1:
                    label = tone['tone_name']
                    if tone['is_premium']:
                        label += " 🌟"
                    st.write(label)
                with col2:
                    if st.button(f"🔊 Preview", key=f"preview_{tone['id']}"):
                        st.info(f"Playing: {tone['tone_name']}")
                with col3:
                    if st.button(f"👍 Use", key=f"use_{tone['id']}"):
                        # Update user's default tone
                        settings = get_notification_settings(user_email)
                        if settings:
                            settings['notification_tone'] = tone['tone_name']
                            create_or_update_notification_settings(user_email, settings)
                            st.success(f"Default tone changed to {tone['tone_name']}")
                            st.rerun()
            
            st.write("---")

def apply_notification_settings(user_email: str, notification_type: str, habit_id: Optional[int] = None) -> Dict:
    """Apply notification settings and return configuration"""
    if not should_send_notification(user_email, notification_type, habit_id):
        return None
    
    sound_config = get_notification_sound(user_email, notification_type, habit_id)
    
    # Get message template
    settings = get_notification_settings(user_email)
    message_template = None
    if settings and settings['custom_message_template']:
        message_template = settings['custom_message_template']
    
    return {
        'sound': sound_config,
        'message_template': message_template,
        'style': settings['notification_style'] if settings else 'simple',
        'group': settings['group_notifications'] if settings else False
    }
