import streamlit as st
import mysql.connector
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta, date
from typing import List, Dict, Optional, Tuple
import calendar
import numpy as np
import json
from collections import defaultdict

from src.db import get_db_connection

def create_consistency_tables():
    """Create consistency analysis tables if they don't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_consistency (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                analysis_date DATE NOT NULL,
                consistency_score DECIMAL(5,2) NOT NULL,
                skipped_days INT NOT NULL,
                low_consistency_days INT NOT NULL,
                total_days_analyzed INT NOT NULL,
                weekly_pattern JSON,
                monthly_pattern JSON,
                best_day VARCHAR(10),
                worst_day VARCHAR(10),
                improvement_score DECIMAL(5,2),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_habit_date (user_email, habit_id, analysis_date),
                INDEX idx_user_email (user_email),
                INDEX idx_habit_id (habit_id),
                INDEX idx_consistency_score (consistency_score),
                INDEX idx_analysis_date (analysis_date)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS skipped_day_patterns (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                skipped_date DATE NOT NULL,
                day_of_week VARCHAR(10) NOT NULL,
                week_number INT NOT NULL,
                month_number INT NOT NULL,
                reason_category ENUM('weekend', 'holiday', 'busy_schedule', 'low_energy', 'other') DEFAULT 'other',
                consecutive_skip_count INT DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_habit (user_email, habit_id),
                INDEX idx_skipped_date (skipped_date),
                INDEX idx_day_of_week (day_of_week),
                INDEX idx_consecutive (consecutive_skip_count)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS consistency_recommendations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                recommendation_type ENUM('time_adjustment', 'goal_reduction', 'frequency_change', 'reminder_optimization', 'environment_change') NOT NULL,
                recommendation_text TEXT NOT NULL,
                priority ENUM('high', 'medium', 'low') NOT NULL,
                implemented BOOLEAN DEFAULT FALSE,
                effectiveness_score DECIMAL(5,2),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user_habit (user_email, habit_id),
                INDEX idx_priority (priority),
                INDEX idx_type (recommendation_type)
            )
        """)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def get_habit_consistency_data(user_email: str, habit_id: Optional[int] = None, 
                              days_back: int = 30) -> pd.DataFrame:
    """Get detailed habit data for consistency analysis"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        query = """
            SELECT h.id as habit_id, h.name as habit_name, h.goal, h.frequency,
                   l.log_date, l.amount, l.completed_at
            FROM habits h
            LEFT JOIN habit_logs l ON h.id = l.habit_id
            WHERE h.user_email = %s AND h.is_active = TRUE
            AND (l.log_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY) OR l.log_date IS NULL)
        """
        params = [user_email.lower(), days_back]
        
        if habit_id:
            query += " AND h.id = %s"
            params.append(habit_id)
        
        query += " ORDER BY h.name, l.log_date"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        
        df = pd.DataFrame(results)
        if not df.empty:
            df['date'] = pd.to_datetime(df['log_date']).dt.date
            df['amount'] = df['amount'].fillna(0)
            df['completed'] = df['amount'] > 0
            df['met_goal'] = df['amount'] >= df['goal']
            df['day_of_week'] = df['date'].apply(lambda x: calendar.day_abbr[x.weekday()] if pd.notna(x) else None)
            
        return df
    finally:
        cursor.close()
        conn.close()

def calculate_consistency_score(habit_data: pd.DataFrame) -> Dict:
    """Calculate comprehensive consistency metrics"""
    if habit_data.empty:
        return {}
    
    # Filter out rows with no date
    valid_data = habit_data[habit_data['date'].notna()]
    if valid_data.empty:
        return {}
    
    habit_name = valid_data['habit_name'].iloc[0]
    goal = valid_data['goal'].iloc[0]
    
    # Date range analysis
    date_range = pd.date_range(start=valid_data['date'].min(), end=valid_data['date'].max(), freq='D')
    total_days = len(date_range)
    
    # Create completion lookup
    completion_lookup = valid_data.set_index('date').to_dict('index')
    
    # Daily analysis
    daily_status = []
    skipped_days = []
    low_consistency_days = []
    
    for check_date in date_range:
        date_only = check_date.date()
        
        if date_only in completion_lookup:
            log = completion_lookup[date_only]
            amount = log['amount']
            
            if amount >= goal:
                status = 'completed'
            elif amount > 0:
                status = 'partial'
                low_consistency_days.append(date_only)
            else:
                status = 'skipped'
                skipped_days.append(date_only)
        else:
            status = 'skipped'
            skipped_days.append(date_only)
        
        daily_status.append({
            'date': date_only,
            'status': status,
            'amount': completion_lookup.get(date_only, {}).get('amount', 0),
            'day_of_week': calendar.day_abbr[date_only.weekday()]
        })
    
    # Calculate metrics
    completed_days = len([d for d in daily_status if d['status'] == 'completed'])
    partial_days = len([d for d in daily_status if d['status'] == 'partial'])
    actual_skipped_days = len(skipped_days)
    
    # Consistency score (0-100)
    if total_days > 0:
        completion_rate = (completed_days / total_days) * 100
        partial_penalty = (partial_days / total_days) * 50  # Partial completion gets half penalty
        skip_penalty = (actual_skipped_days / total_days) * 100
        consistency_score = max(0, 100 - skip_penalty - (partial_penalty * 0.5))
    else:
        consistency_score = 0
    
    # Weekly patterns
    weekly_patterns = defaultdict(lambda: {'completed': 0, 'partial': 0, 'skipped': 0, 'total': 0})
    for day in daily_status:
        weekly_patterns[day['day_of_week']]['total'] += 1
        weekly_patterns[day['day_of_week']][day['status']] += 1
    
    # Calculate success rates by day
    day_success_rates = {}
    for day_name, counts in weekly_patterns.items():
        if counts['total'] > 0:
            success_rate = ((counts['completed'] + (counts['partial'] * 0.5)) / counts['total']) * 100
            day_success_rates[day_name] = success_rate
    
    # Find best and worst days
    if day_success_rates:
        best_day = max(day_success_rates.items(), key=lambda x: x[1])
        worst_day = min(day_success_rates.items(), key=lambda x: x[1])
    else:
        best_day = (None, 0)
        worst_day = (None, 0)
    
    # Monthly patterns
    monthly_patterns = defaultdict(lambda: {'completed': 0, 'partial': 0, 'skipped': 0, 'total': 0})
    for day in daily_status:
        month_key = day['date'].strftime('%Y-%m')
        monthly_patterns[month_key]['total'] += 1
        monthly_patterns[month_key][day['status']] += 1
    
    # Skip pattern analysis
    consecutive_skips = analyze_consecutive_skips(skipped_days)
    
    # Improvement potential
    improvement_score = calculate_improvement_potential(daily_status, goal)
    
    return {
        'habit_name': habit_name,
        'goal': goal,
        'consistency_score': round(consistency_score, 2),
        'total_days_analyzed': total_days,
        'completed_days': completed_days,
        'partial_days': partial_days,
        'skipped_days': actual_skipped_days,
        'low_consistency_days': len(low_consistency_days),
        'weekly_patterns': dict(weekly_patterns),
        'monthly_patterns': dict(monthly_patterns),
        'best_day': best_day[0],
        'best_day_rate': best_day[1],
        'worst_day': worst_day[0],
        'worst_day_rate': worst_day[1],
        'consecutive_skips': consecutive_skips,
        'improvement_score': round(improvement_score, 2),
        'daily_status': daily_status
    }

def analyze_consecutive_skips(skipped_days: List[date]) -> Dict:
    """Analyze patterns in consecutive skipped days"""
    if not skipped_days:
        return {'max_consecutive': 0, 'total_sequences': 0, 'average_length': 0}
    
    skipped_days.sort()
    
    sequences = []
    current_sequence = [skipped_days[0]]
    
    for i in range(1, len(skipped_days)):
        if skipped_days[i] == skipped_days[i-1] + timedelta(days=1):
            current_sequence.append(skipped_days[i])
        else:
            if len(current_sequence) > 1:
                sequences.append(current_sequence)
            current_sequence = [skipped_days[i]]
    
    if len(current_sequence) > 1:
        sequences.append(current_sequence)
    
    if sequences:
        max_consecutive = max(len(seq) for seq in sequences)
        total_sequences = len(sequences)
        average_length = sum(len(seq) for seq in sequences) / total_sequences
    else:
        max_consecutive = 1 if skipped_days else 0
        total_sequences = 0
        average_length = 0
    
    return {
        'max_consecutive': max_consecutive,
        'total_sequences': total_sequences,
        'average_length': round(average_length, 1),
        'sequences': sequences
    }

def calculate_improvement_potential(daily_status: List[Dict], goal: int) -> float:
    """Calculate potential for improvement based on partial completions"""
    partial_days = [d for d in daily_status if d['status'] == 'partial']
    
    if not partial_days:
        return 0
    
    # Calculate average completion on partial days
    avg_partial_amount = np.mean([d['amount'] for d in partial_days])
    
    # Potential improvement = how far partial days are from goal
    if goal > 0:
        improvement_potential = (avg_partial_amount / goal) * 100
    else:
        improvement_potential = 0
    
    return min(100, improvement_potential)

def generate_consistency_recommendations(consistency_data: Dict) -> List[Dict]:
    """Generate personalized recommendations based on consistency analysis"""
    recommendations = []
    
    if not consistency_data:
        return recommendations
    
    score = consistency_data['consistency_score']
    skip_rate = (consistency_data['skipped_days'] / consistency_data['total_days_analyzed']) * 100
    partial_rate = (consistency_data['low_consistency_days'] / consistency_data['total_days_analyzed']) * 100
    
    # High skip rate recommendations
    if skip_rate > 30:
        recommendations.append({
            'type': 'reminder_optimization',
            'priority': 'high',
            'text': f"High skip rate ({skip_rate:.1f}%). Consider setting more frequent reminders or adjusting notification times."
        })
    
    # Worst day analysis
    worst_day = consistency_data['worst_day']
    if worst_day and consistency_data['worst_day_rate'] < 50:
        recommendations.append({
            'type': 'time_adjustment',
            'priority': 'medium',
            'text': f"{worst_day} is your weakest day ({consistency_data['worst_day_rate']:.1f}% success). Consider scheduling this habit for a different time or reducing the goal on {worst_day}."
        })
    
    # Consecutive skip patterns
    consecutive_skips = consistency_data['consecutive_skips']
    if consecutive_skips['max_consecutive'] >= 3:
        recommendations.append({
            'type': 'frequency_change',
            'priority': 'high',
            'text': f"You've skipped up to {consecutive_skips['max_consecutive']} days consecutively. Consider breaking this into smaller, more manageable goals."
        })
    
    # Partial completion issues
    if partial_rate > 20:
        recommendations.append({
            'type': 'goal_reduction',
            'priority': 'medium',
            'text': f"Partial completions occur {partial_rate:.1f}% of the time. Your current goal might be too ambitious - consider reducing it temporarily."
        })
    
    # Low overall consistency
    if score < 50:
        recommendations.append({
            'type': 'environment_change',
            'priority': 'high',
            'text': f"Overall consistency is low ({score:.1f}%). Consider changing your environment or routine to make this habit easier to complete."
        })
    elif score < 70:
        recommendations.append({
            'type': 'reminder_optimization',
            'priority': 'medium',
            'text': f"Consistency is moderate ({score:.1f}%). Focus on your weak days and consider accountability partners."
        })
    
    # Best day reinforcement
    best_day = consistency_data['best_day']
    if best_day and consistency_data['best_day_rate'] > 80:
        recommendations.append({
            'type': 'time_adjustment',
            'priority': 'low',
            'text': f"{best_day} is your strongest day ({consistency_data['best_day_rate']:.1f}% success). Try to replicate whatever makes this day successful."
        })
    
    return recommendations

def save_consistency_analysis(user_email: str, consistency_data: Dict):
    """Save consistency analysis to database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get habit ID
        cursor.execute("""
            SELECT id FROM habits WHERE user_email = %s AND name = %s
        """, (user_email.lower(), consistency_data['habit_name']))
        result = cursor.fetchone()
        
        if not result:
            return
        
        habit_id = result[0]
        
        # Save consistency record
        cursor.execute("""
            INSERT INTO habit_consistency 
            (user_email, habit_id, analysis_date, consistency_score, 
             skipped_days, low_consistency_days, total_days_analyzed,
             weekly_pattern, monthly_pattern, best_day, worst_day, improvement_score)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
            consistency_score = VALUES(consistency_score),
            skipped_days = VALUES(skipped_days),
            low_consistency_days = VALUES(low_consistency_days),
            total_days_analyzed = VALUES(total_days_analyzed),
            weekly_pattern = VALUES(weekly_pattern),
            monthly_pattern = VALUES(monthly_pattern),
            best_day = VALUES(best_day),
            worst_day = VALUES(worst_day),
            improvement_score = VALUES(improvement_score)
        """, (user_email.lower(), habit_id, date.today(),
              consistency_data['consistency_score'],
              consistency_data['skipped_days'],
              consistency_data['low_consistency_days'],
              consistency_data['total_days_analyzed'],
              json.dumps(consistency_data['weekly_patterns']),
              json.dumps(consistency_data['monthly_patterns']),
              consistency_data['best_day'],
              consistency_data['worst_day'],
              consistency_data['improvement_score']))
        
        # Save skipped day patterns
        for skipped_date in consistency_data['daily_status']:
            if skipped_date['status'] == 'skipped':
                cursor.execute("""
                    INSERT INTO skipped_day_patterns 
                    (user_email, habit_id, skipped_date, day_of_week, 
                     week_number, month_number)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                    day_of_week = VALUES(day_of_week),
                    week_number = VALUES(week_number),
                    month_number = VALUES(month_number)
                """, (user_email.lower(), habit_id, skipped_date['date'],
                      skipped_date['day_of_week'],
                      skipped_date['date'].isocalendar()[1],
                      skipped_date['date'].month))
        
        # Save recommendations
        recommendations = generate_consistency_recommendations(consistency_data)
        for rec in recommendations:
            cursor.execute("""
                INSERT INTO consistency_recommendations 
                (user_email, habit_id, recommendation_type, 
                 recommendation_text, priority)
                VALUES (%s, %s, %s, %s, %s)
            """, (user_email.lower(), habit_id, 
                  rec['type'], rec['text'], rec['priority']))
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def create_consistency_heatmap(daily_status: List[Dict]) -> go.Figure:
    """Create a heatmap showing daily consistency patterns"""
    if not daily_status:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    # Create date grid
    dates = [d['date'] for d in daily_status]
    start_date = min(dates)
    end_date = max(dates)
    
    # Create week structure
    weeks = []
    current_week = []
    
    current_date = start_date
    while current_date <= end_date:
        day_data = next((d for d in daily_status if d['date'] == current_date), None)
        if day_data:
            status_value = 1 if day_data['status'] == 'completed' else (0.5 if day_data['status'] == 'partial' else 0)
        else:
            status_value = 0
        
        current_week.append({
            'date': current_date,
            'day': current_date.weekday(),
            'status': status_value
        })
        
        if current_date.weekday() == 6:  # Sunday
            weeks.append(current_week)
            current_week = []
        
        current_date += timedelta(days=1)
    
    if current_week:
        weeks.append(current_week)
    
    # Create heatmap data
    heatmap_data = []
    week_labels = []
    day_labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    
    for week in weeks:
        week_data = [0] * 7  # Initialize week with 0s
        for day in week:
            week_data[day['day']] = day['status']
        heatmap_data.append(week_data)
        week_labels.append(f"Week {len(week_labels) + 1}")
    
    fig = go.Figure(data=go.Heatmap(
        z=heatmap_data,
        x=day_labels,
        y=week_labels,
        colorscale='RdYlGn',
        showscale=True,
        hovertemplate='Day: %{x}<br>Week: %{y}<br>Completion: %{z:.0%}<extra></extra>'
    ))
    
    fig.update_layout(
        title="Daily Consistency Heatmap",
        xaxis_title="Day of Week",
        yaxis_title="Week",
        height=max(300, len(weeks) * 40)
    )
    
    return fig

def create_weekly_pattern_chart(weekly_patterns: Dict) -> go.Figure:
    """Create a chart showing weekly success patterns"""
    if not weekly_patterns:
        fig = go.Figure()
        fig.add_annotation(text="No weekly data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    success_rates = []
    completion_counts = []
    
    for day in days:
        if day in weekly_patterns:
            counts = weekly_patterns[day]
            total = counts['total']
            if total > 0:
                success_rate = ((counts['completed'] + (counts['partial'] * 0.5)) / total) * 100
                success_rates.append(success_rate)
                completion_counts.append(counts['completed'])
            else:
                success_rates.append(0)
                completion_counts.append(0)
        else:
            success_rates.append(0)
            completion_counts.append(0)
    
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=('Success Rate by Day', 'Completions by Day'),
        vertical_spacing=0.1
    )
    
    # Success rate
    fig.add_trace(go.Bar(
        x=days,
        y=success_rates,
        name='Success Rate',
        marker_color='lightblue',
        text=[f"{rate:.1f}%" for rate in success_rates],
        textposition='auto',
        hovertemplate='Day: %{x}<br>Success Rate: %{y:.1f}%<extra></extra>'
    ), row=1, col=1)
    
    # Completion counts
    fig.add_trace(go.Bar(
        x=days,
        y=completion_counts,
        name='Completions',
        marker_color='darkblue',
        text=[str(count) for count in completion_counts],
        textposition='auto',
        hovertemplate='Day: %{x}<br>Completions: %{y}<extra></extra>'
    ), row=2, col=1)
    
    fig.update_layout(
        title="Weekly Pattern Analysis",
        height=500,
        showlegend=False
    )
    
    fig.update_yaxes(title_text="Success Rate (%)", row=1, col=1)
    fig.update_yaxes(title_text="Completions", row=2, col=1)
    
    return fig

def create_consistency_comparison_chart(all_consistency_data: List[Dict]) -> go.Figure:
    """Create comparison chart for multiple habits"""
    if not all_consistency_data:
        fig = go.Figure()
        fig.add_annotation(text="No consistency data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    habits = [data['habit_name'] for data in all_consistency_data]
    scores = [data['consistency_score'] for data in all_consistency_data]
    skip_rates = [(data['skipped_days'] / data['total_days_analyzed']) * 100 for data in all_consistency_data]
    
    fig = go.Figure()
    
    # Consistency scores
    fig.add_trace(go.Bar(
        x=habits,
        y=scores,
        name='Consistency Score',
        marker_color='lightgreen',
        text=[f"{score:.1f}%" for score in scores],
        textposition='auto',
        hovertemplate='Habit: %{x}<br>Consistency: %{y:.1f}%<extra></extra>'
    ))
    
    # Skip rates
    fig.add_trace(go.Bar(
        x=habits,
        y=skip_rates,
        name='Skip Rate',
        marker_color='lightcoral',
        text=[f"{rate:.1f}%" for rate in skip_rates],
        textposition='auto',
        hovertemplate='Habit: %{x}<br>Skip Rate: %{y:.1f}%<extra></extra>'
    ))
    
    fig.update_layout(
        title="Habit Consistency Comparison",
        xaxis_title="Habit",
        yaxis_title="Percentage (%)",
        barmode='group',
        height=max(400, len(habits) * 50)
    )
    
    return fig

def render_consistency_analysis_page(user_email: str):
    """Main consistency analysis page"""
    st.title("📊 Habit Consistency Analyzer")
    
    # Get data
    habit_data = get_habit_consistency_data(user_email, days_back=30)
    
    if habit_data.empty:
        st.warning("No habit data found. Start tracking your habits to see consistency analysis!")
        return
    
    # Analyze each habit
    all_consistency_data = []
    
    for habit_name in habit_data['habit_name'].unique():
        habit_specific_data = habit_data[habit_data['habit_name'] == habit_name]
        consistency_data = calculate_consistency_score(habit_specific_data)
        
        if consistency_data:
            all_consistency_data.append(consistency_data)
            save_consistency_analysis(user_email, consistency_data)
    
    if not all_consistency_data:
        st.warning("No consistency data available for analysis.")
        return
    
    # Overall summary
    st.subheader("📈 Overall Consistency Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        avg_score = np.mean([data['consistency_score'] for data in all_consistency_data])
        st.metric("📊 Average Consistency", f"{avg_score:.1f}%")
    
    with col2:
        total_skips = sum(data['skipped_days'] for data in all_consistency_data)
        st.metric("⏭️ Total Skipped Days", total_skips)
    
    with col3:
        low_consistency_habits = len([data for data in all_consistency_data if data['consistency_score'] < 70])
        st.metric("⚠️ Low Consistency Habits", low_consistency_habits)
    
    with col4:
        high_consistency_habits = len([data for data in all_consistency_data if data['consistency_score'] >= 80])
        st.metric("✨ High Consistency Habits", high_consistency_habits)
    
    # Individual habit analysis
    st.write("---")
    st.subheader("🎯 Individual Habit Analysis")
    
    # Sort by consistency score (lowest first for improvement focus)
    sorted_data = sorted(all_consistency_data, key=lambda x: x['consistency_score'])
    
    selected_habit = st.selectbox(
        "Select Habit for Detailed Analysis",
        options=[data['habit_name'] for data in sorted_data],
        index=0
    )
    
    selected_data = next(data for data in sorted_data if data['habit_name'] == selected_habit)
    
    # Habit details
    col1, col2, col3 = st.columns(3)
    
    with col1:
        score_color = "🔴" if selected_data['consistency_score'] < 50 else "🟡" if selected_data['consistency_score'] < 80 else "🟢"
        st.metric(f"{score_color} Consistency Score", f"{selected_data['consistency_score']:.1f}%")
    
    with col2:
        st.metric("📅 Days Analyzed", selected_data['total_days_analyzed'])
    
    with col3:
        st.metric("🎯 Improvement Potential", f"{selected_data['improvement_score']:.1f}%")
    
    # Detailed breakdown
    st.write("**Performance Breakdown:**")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("✅ Completed", f"{selected_data['completed_days']} days")
    
    with col2:
        st.metric("⚡ Partial", f"{selected_data['low_consistency_days']} days")
    
    with col3:
        st.metric("⏭️ Skipped", f"{selected_data['skipped_days']} days")
    
    with col4:
        if selected_data['best_day']:
            st.metric(f"🌟 Best Day", f"{selected_data['best_day']} ({selected_data['best_day_rate']:.1f}%)")
    
    # Charts
    st.write("---")
    st.subheader("📊 Visual Analysis")
    
    tab1, tab2, tab3 = st.tabs(["🔥 Consistency Heatmap", "📅 Weekly Patterns", "📈 Comparisons"])
    
    with tab1:
        st.plotly_chart(create_consistency_heatmap(selected_data['daily_status']), use_container_width=True)
    
    with tab2:
        st.plotly_chart(create_weekly_pattern_chart(selected_data['weekly_patterns']), use_container_width=True)
    
    with tab3:
        st.plotly_chart(create_consistency_comparison_chart(all_consistency_data), use_container_width=True)
    
    # Recommendations
    st.write("---")
    st.subheader("💡 Personalized Recommendations")
    
    recommendations = generate_consistency_recommendations(selected_data)
    
    if recommendations:
        for i, rec in enumerate(recommendations, 1):
            priority_color = "🔴" if rec['priority'] == 'high' else "🟡" if rec['priority'] == 'medium' else "🟢"
            
            with st.expander(f"{priority_color} {rec['type'].replace('_', ' ').title()}"):
                st.write(rec['text'])
                
                # Action buttons
                col1, col2 = st.columns(2)
                with col1:
                    if st.button(f"Apply Recommendation {i}", key=f"apply_{i}"):
                        st.success("Recommendation marked for implementation!")
                with col2:
                    if st.button(f"Dismiss {i}", key=f"dismiss_{i}"):
                        st.info("Recommendation dismissed.")
    else:
        st.success("🎉 Great job! Your consistency is excellent. Keep up the good work!")

def render_consistency_manager(user_email: str):
    """Render consistency analyzer manager"""
    render_consistency_analysis_page(user_email)
