from __future__ import annotations
from datetime import date, datetime, timedelta
from typing import List, Tuple
import streamlit as st
from .db import get_conn


def _fetch_logs(habit_id: int, start: date, end: date) -> List[date]:
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT log_date FROM habit_logs WHERE habit_id=%s AND log_date BETWEEN %s AND %s ORDER BY log_date ASC",
            (habit_id, start, end),
        )
        rows = cur.fetchall() or []
        out: List[date] = []
        for r in rows:
            d = r[0]
            if isinstance(d, date):
                out.append(d)
            else:
                try:
                    out.append(datetime.strptime(str(d), "%Y-%m-%d").date())
                except Exception:
                    pass
        return out


def get_weekly_summary(habit_id: int, weeks: int = 8) -> List[Tuple[str, int]]:
    """Returns list of (label, count) for the last `weeks` ISO weeks including current.
    Label format: 'YYYY-Www' (e.g., 2025-W45)."""
    today = date.today()
    # Align start to Monday of the week (ISO)
    start_of_week = today - timedelta(days=(today.isoweekday() - 1))
    start = start_of_week - timedelta(weeks=weeks - 1)
    end = start_of_week + timedelta(days=6)  # end of current week
    logs = _fetch_logs(habit_id, start, end)
    counts = {}
    for w in range(weeks):
        week_start = start + timedelta(weeks=w)
        iso_year, iso_week, _ = week_start.isocalendar()
        key = f"{iso_year}-W{iso_week:02d}"
        counts[key] = 0
    for d in logs:
        iso_year, iso_week, _ = d.isocalendar()
        key = f"{iso_year}-W{iso_week:02d}"
        if key in counts:
            counts[key] += 1
    return [(k, counts[k]) for k in sorted(counts.keys())]


def get_monthly_summary(habit_id: int, months: int = 12) -> List[Tuple[str, int]]:
    """Returns list of (label, count) for the last `months` months including current.
    Label format: 'YYYY-MM'."""
    today = date.today()
    # Compute the first day of current month
    start_month = date(today.year, today.month, 1)
    # Helper to subtract months
    def add_months(dt: date, delta: int) -> date:
        y = dt.year + (dt.month - 1 + delta) // 12
        m = (dt.month - 1 + delta) % 12 + 1
        return date(y, m, 1)
    start = add_months(start_month, -(months - 1))
    # End is last day of current month
    end = add_months(start_month, 1) - timedelta(days=1)
    logs = _fetch_logs(habit_id, start, end)
    counts = {}
    labels: List[str] = []
    for i in range(months):
        dt = add_months(start, i)
        key = f"{dt.year}-{dt.month:02d}"
        counts[key] = 0
        labels.append(key)
    for d in logs:
        key = f"{d.year}-{d.month:02d}"
        if key in counts:
            counts[key] += 1
    return [(k, counts[k]) for k in labels]


def render_summaries_block(habit_id: int):
    weeks = 8
    months = 12
    st.caption("Weekly and monthly summaries")
    wdata = get_weekly_summary(habit_id, weeks=weeks)
    mdata = get_monthly_summary(habit_id, months=months)
    colw, colm = st.columns(2)
    with colw:
        st.write("Weekly (last 8)")
        try:
            st.bar_chart({"week": [w for w, _ in wdata], "count": [c for _, c in wdata]}, x="week", y="count", use_container_width=True)
        except Exception:
            st.write(wdata)
    with colm:
        st.write("Monthly (last 12)")
        try:
            st.bar_chart({"month": [m for m, _ in mdata], "count": [c for _, c in mdata]}, x="month", y="count", use_container_width=True)
        except Exception:
            st.write(mdata)
