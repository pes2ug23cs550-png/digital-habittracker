import streamlit as st
import mysql.connector
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta, date
from typing import List, Dict, Optional, Tuple
import calendar
from collections import defaultdict

from src.db import get_db_connection

def create_streak_tables():
    """Create streak tracking tables if they don't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_streaks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                current_streak INT DEFAULT 0,
                longest_streak INT DEFAULT 0,
                last_completion_date DATE,
                streak_start_date DATE,
                previous_longest_streak INT DEFAULT 0,
                total_days_completed INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_habit (user_email, habit_id),
                INDEX idx_user_email (user_email),
                INDEX idx_habit_id (habit_id),
                INDEX idx_current_streak (current_streak),
                INDEX idx_longest_streak (longest_streak)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS streak_milestones (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                milestone_days INT NOT NULL,
                achieved_date DATE NOT NULL,
                streak_type ENUM('current', 'longest') NOT NULL,
                celebration_sent BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_habit (user_email, habit_id),
                INDEX idx_milestone (milestone_days),
                INDEX idx_achieved_date (achieved_date)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS streak_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                streak_length INT NOT NULL,
                streak_start_date DATE NOT NULL,
                streak_end_date DATE NOT NULL,
                is_current BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_habit (user_email, habit_id),
                INDEX idx_streak_length (streak_length),
                INDEX idx_dates (streak_start_date, streak_end_date)
            )
        """)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def calculate_habit_streaks(user_email: str, habit_id: Optional[int] = None) -> Dict:
    """Calculate current and longest streaks for habits"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Get completion data
        query = """
            SELECT h.id as habit_id, h.name as habit_name, h.goal,
                   l.log_date, l.amount
            FROM habits h
            LEFT JOIN habit_logs l ON h.id = l.habit_id
            WHERE h.user_email = %s AND h.is_active = TRUE
        """
        params = [user_email.lower()]
        
        if habit_id:
            query += " AND h.id = %s"
            params.append(habit_id)
        
        query += " ORDER BY h.name, l.log_date"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        
        if not results:
            return {}
        
        # Group by habit
        habits_data = defaultdict(list)
        for row in results:
            habits_data[row['habit_id']].append(row)
        
        streak_info = {}
        
        for hid, logs in habits_data.items():
            if not logs:
                continue
            
            # Filter out logs with no completion
            completed_logs = [log for log in logs if log['amount'] and log['amount'] > 0]
            if not completed_logs:
                continue
            
            # Sort by date
            completed_logs.sort(key=lambda x: x['date'])
            
            # Calculate streaks
            streaks = []
            current_streak = 0
            current_start = None
            longest_streak = 0
            longest_start = None
            longest_end = None
            
            # Get all dates in range
            if completed_logs:
                start_date = completed_logs[0]['date']
                end_date = completed_logs[-1]['date']
                date_range = pd.date_range(start=start_date, end=end_date)
                
                # Create completion lookup
                completion_lookup = {log['date']: log for log in completed_logs}
                
                # Track current streak
                current_streak = 0
                current_start = None
                
                for check_date in date_range:
                    date_only = check_date.date()
                    
                    if date_only in completion_lookup:
                        log = completion_lookup[date_only]
                        if log['amount'] >= log['goal']:
                            if current_streak == 0:
                                current_start = date_only
                            current_streak += 1
                        else:
                            # Save streak if it ended
                            if current_streak > 0:
                                streaks.append({
                                    'length': current_streak,
                                    'start_date': current_start,
                                    'end_date': check_date - timedelta(days=1)
                                })
                                if current_streak > longest_streak:
                                    longest_streak = current_streak
                                    longest_start = current_start
                                    longest_end = check_date - timedelta(days=1)
                            current_streak = 0
                            current_start = None
                    else:
                        # Missing day - streak breaks
                        if current_streak > 0:
                            streaks.append({
                                'length': current_streak,
                                'start_date': current_start,
                                'end_date': check_date - timedelta(days=1)
                            })
                            if current_streak > longest_streak:
                                longest_streak = current_streak
                                longest_start = current_start
                                longest_end = check_date - timedelta(days=1)
                        current_streak = 0
                        current_start = None
                
                # Check if current streak is still active (ends today)
                if current_streak > 0:
                    if current_start and current_start <= date.today():
                        streaks.append({
                            'length': current_streak,
                            'start_date': current_start,
                            'end_date': date.today(),
                            'is_current': True
                        })
                        if current_streak > longest_streak:
                            longest_streak = current_streak
                            longest_start = current_start
                            longest_end = date.today()
            
            # Get habit info
            habit_info = logs[0]
            
            streak_info[hid] = {
                'habit_id': hid,
                'habit_name': habit_info['habit_name'],
                'goal': habit_info['goal'],
                'current_streak': current_streak,
                'longest_streak': longest_streak,
                'current_start_date': current_start,
                'longest_start_date': longest_start,
                'longest_end_date': longest_end,
                'last_completion_date': completed_logs[-1]['date'] if completed_logs else None,
                'total_completed_days': len(completed_logs),
                'all_streaks': streaks
            }
        
        return streak_info
    finally:
        cursor.close()
        conn.close()

def update_streak_records(user_email: str, habit_id: Optional[int] = None):
    """Update streak records in database"""
    streak_info = calculate_habit_streaks(user_email, habit_id)
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        for hid, info in streak_info.items():
            # Update or insert streak record
            cursor.execute("""
                INSERT INTO habit_streaks 
                (user_email, habit_id, current_streak, longest_streak, 
                 last_completion_date, streak_start_date, previous_longest_streak, 
                 total_days_completed)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                current_streak = VALUES(current_streak),
                longest_streak = VALUES(longest_streak),
                last_completion_date = VALUES(last_completion_date),
                streak_start_date = VALUES(streak_start_date),
                previous_longest_streak = IF(longest_streak > VALUES(longest_streak), longest_streak, VALUES(longest_streak)),
                total_days_completed = VALUES(total_days_completed),
                updated_at = CURRENT_TIMESTAMP
            """, (user_email.lower(), hid, info['current_streak'], info['longest_streak'],
                  info['last_completion_date'], info['current_start_date'], 
                  info['longest_streak'], info['total_completed_days']))
            
            # Check for new milestones
            check_milestones(cursor, user_email, hid, info)
            
            # Update streak history
            update_streak_history(cursor, user_email, hid, info['all_streaks'])
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def check_milestones(cursor, user_email: str, habit_id: int, streak_info: Dict):
    """Check and record streak milestones"""
    milestones = [3, 7, 14, 21, 30, 50, 60, 90, 100, 120, 150, 180, 200, 365, 500, 730, 1000]
    
    for milestone in milestones:
        # Check current streak milestone
        if streak_info['current_streak'] >= milestone:
            cursor.execute("""
                SELECT id FROM streak_milestones 
                WHERE user_email = %s AND habit_id = %s 
                AND milestone_days = %s AND streak_type = 'current'
            """, (user_email.lower(), habit_id, milestone))
            
            if not cursor.fetchone():
                cursor.execute("""
                    INSERT INTO streak_milestones 
                    (user_email, habit_id, milestone_days, achieved_date, streak_type)
                    VALUES (%s, %s, %s, %s, 'current')
                """, (user_email.lower(), habit_id, milestone, date.today()))
        
        # Check longest streak milestone
        if streak_info['longest_streak'] >= milestone:
            cursor.execute("""
                SELECT id FROM streak_milestones 
                WHERE user_email = %s AND habit_id = %s 
                AND milestone_days = %s AND streak_type = 'longest'
            """, (user_email.lower(), habit_id, milestone))
            
            if not cursor.fetchone():
                # Find when this longest streak was achieved
                if streak_info['longest_end_date']:
                    cursor.execute("""
                        INSERT INTO streak_milestones 
                        (user_email, habit_id, milestone_days, achieved_date, streak_type)
                        VALUES (%s, %s, %s, %s, 'longest')
                    """, (user_email.lower(), habit_id, milestone, streak_info['longest_end_date']))

def update_streak_history(cursor, user_email: str, habit_id: int, streaks: List[Dict]):
    """Update streak history records"""
    # Clear existing history for this habit
    cursor.execute("""
        DELETE FROM streak_history WHERE user_email = %s AND habit_id = %s
    """, (user_email.lower(), habit_id))
    
    # Insert all streaks
    for streak in streaks:
        cursor.execute("""
            INSERT INTO streak_history 
            (user_email, habit_id, streak_length, streak_start_date, 
             streak_end_date, is_current)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (user_email.lower(), habit_id, streak['length'], 
              streak['start_date'], streak['end_date'], 
              streak.get('is_current', False)))

def get_streak_summary(user_email: str) -> pd.DataFrame:
    """Get streak summary for all habits"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT hs.*, h.name as habit_name
            FROM habit_streaks hs
            JOIN habits h ON hs.habit_id = h.id
            WHERE hs.user_email = %s AND h.is_active = TRUE
            ORDER BY hs.current_streak DESC, hs.longest_streak DESC
        """, (user_email.lower(),))
        
        results = cursor.fetchall()
        return pd.DataFrame(results) if results else pd.DataFrame()
    finally:
        cursor.close()
        conn.close()

def get_milestone_achievements(user_email: str, habit_id: Optional[int] = None) -> pd.DataFrame:
    """Get milestone achievements"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        query = """
            SELECT sm.*, h.name as habit_name
            FROM streak_milestones sm
            JOIN habits h ON sm.habit_id = h.id
            WHERE sm.user_email = %s
        """
        params = [user_email.lower()]
        
        if habit_id:
            query += " AND sm.habit_id = %s"
            params.append(habit_id)
        
        query += " ORDER BY sm.achieved_date DESC, sm.milestone_days DESC"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        return pd.DataFrame(results) if results else pd.DataFrame()
    finally:
        cursor.close()
        conn.close()

def get_streak_history(user_email: str, habit_id: Optional[int] = None) -> pd.DataFrame:
    """Get streak history"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        query = """
            SELECT sh.*, h.name as habit_name
            FROM streak_history sh
            JOIN habits h ON sh.habit_id = h.id
            WHERE sh.user_email = %s
        """
        params = [user_email.lower()]
        
        if habit_id:
            query += " AND sh.habit_id = %s"
            params.append(habit_id)
        
        query += " ORDER BY sh.streak_start_date DESC"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        return pd.DataFrame(results) if results else pd.DataFrame()
    finally:
        cursor.close()
        conn.close()

def create_streak_comparison_chart(df: pd.DataFrame) -> go.Figure:
    """Create streak comparison chart"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No streak data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    fig = go.Figure()
    
    # Current streaks
    fig.add_trace(go.Bar(
        x=df['current_streak'],
        y=df['habit_name'],
        orientation='h',
        name='Current Streak',
        marker_color='lightblue',
        text=[f"{s} days" for s in df['current_streak']],
        textposition='auto',
        hovertemplate='<b>%{y}</b><br>Current Streak: %{x} days<extra></extra>'
    ))
    
    # Longest streaks
    fig.add_trace(go.Bar(
        x=df['longest_streak'],
        y=df['habit_name'],
        orientation='h',
        name='Longest Streak',
        marker_color='darkblue',
        text=[f"{s} days" for s in df['longest_streak']],
        textposition='auto',
        hovertemplate='<b>%{y}</b><br>Longest Streak: %{x} days<extra></extra>'
    ))
    
    fig.update_layout(
        title="Streak Comparison",
        xaxis_title="Days",
        yaxis_title="Habit",
        barmode='group',
        height=max(400, len(df) * 40)
    )
    
    return fig

def create_streak_timeline_chart(df: pd.DataFrame) -> go.Figure:
    """Create streak timeline chart"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No streak history available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    fig = go.Figure()
    
    habits = df['habit_name'].unique()
    colors = px.colors.qualitative.Set3
    
    for i, habit in enumerate(habits):
        habit_data = df[df['habit_name'] == habit]
        color = colors[i % len(colors)]
        
        for _, streak in habit_data.iterrows():
            fig.add_trace(go.Scatter(
                x=[streak['streak_start_date'], streak['streak_end_date']],
                y=[habit, habit],
                mode='lines+markers',
                line=dict(color=color, width=8),
                marker=dict(size=10),
                name=habit if i == 0 else "",
                showlegend=i == 0,
                hovertemplate=f'<b>{habit}</b><br>Streak: {streak["streak_length"]} days<br>Start: {streak["streak_start_date"]}<br>End: {streak["streak_end_date"]}<extra></extra>'
            ))
    
    fig.update_layout(
        title="Streak Timeline",
        xaxis_title="Date",
        yaxis_title="Habit",
        height=max(300, len(habits) * 50),
        showlegend=True
    )
    
    return fig

def create_milestone_chart(df: pd.DataFrame) -> go.Figure:
    """Create milestone achievement chart"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No milestones achieved yet", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    # Group by milestone and count achievements
    milestone_counts = df.groupby('milestone_days').size().reset_index(name='count')
    milestone_counts = milestone_counts.sort_values('milestone_days')
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=milestone_counts['milestone_days'],
        y=milestone_counts['count'],
        marker_color='gold',
        text=[f"{count}x" for count in milestone_counts['count']],
        textposition='auto',
        hovertemplate='<b>%{x} days</b><br>Achieved %{y} times<extra></extra>'
    ))
    
    fig.update_layout(
        title="Milestone Achievements",
        xaxis_title="Days",
        yaxis_title="Number of Achievements",
        height=400
    )
    
    return fig

def render_streak_summary_card(streak_info: Dict) -> None:
    """Render individual streak summary card"""
    habit_name = streak_info['habit_name']
    current_streak = streak_info['current_streak']
    longest_streak = streak_info['longest_streak']
    total_days = streak_info['total_completed_days']
    
    # Card styling based on current streak
    if current_streak >= 30:
        streak_color = "🔥"
    elif current_streak >= 14:
        streak_color = "⚡"
    elif current_streak >= 7:
        streak_color = "✨"
    elif current_streak >= 3:
        streak_color = "🌟"
    else:
        streak_color = "💫"
    
    with st.container():
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(f"{streak_color} Current", f"{current_streak} days")
        
        with col2:
            st.metric("🏆 Longest", f"{longest_streak} days")
        
        with col3:
            st.metric("📊 Total Days", total_days)
        
        with col4:
            if current_streak > 0:
                next_milestone = next((m for m in [3, 7, 14, 21, 30, 50, 60, 90, 100, 120, 150, 180, 200, 365] if m > current_streak), None)
                if next_milestone:
                    days_to_milestone = next_milestone - current_streak
                    st.metric("🎯 Next", f"{days_to_milestone} days")
                else:
                    st.metric("🎯 Next", "🏅 Master")
            else:
                st.metric("🎯 Next", "Start today!")

def render_streak_tracker_page(user_email: str):
    """Main streak tracker page"""
    st.title("🔥 Streak Tracker")
    
    # Update streak records
    update_streak_records(user_email)
    
    # Get data
    streak_summary = get_streak_summary(user_email)
    milestones = get_milestone_achievements(user_email)
    streak_history = get_streak_history(user_email)
    
    if streak_summary.empty:
        st.warning("No habits found or no completions yet. Start building your streaks!")
        return
    
    # Overall stats
    st.subheader("📊 Overall Streak Stats")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_current = streak_summary['current_streak'].sum()
        st.metric("🔥 Total Current Streak Days", total_current)
    
    with col2:
        max_current = streak_summary['current_streak'].max()
        st.metric("⚡ Best Current Streak", f"{max_current} days")
    
    with col3:
        total_longest = streak_summary['longest_streak'].max()
        st.metric("🏆 Best Longest Streak", f"{total_longest} days")
    
    with col4:
        active_streaks = len(streak_summary[streak_summary['current_streak'] > 0])
        st.metric("🌟 Active Streaks", active_streaks)
    
    # Individual habit streaks
    st.write("---")
    st.subheader("🎯 Habit Streak Details")
    
    # Sort by current streak
    streak_summary_sorted = streak_summary.sort_values('current_streak', ascending=False)
    
    for _, row in streak_summary_sorted.iterrows():
        render_streak_summary_card(row.to_dict())
        st.write("---")
    
    # Charts
    st.write("---")
    st.subheader("📈 Streak Visualizations")
    
    tab1, tab2, tab3 = st.tabs(["📊 Comparison", "📅 Timeline", "🏆 Milestones"])
    
    with tab1:
        st.plotly_chart(create_streak_comparison_chart(streak_summary), use_container_width=True)
    
    with tab2:
        st.plotly_chart(create_streak_timeline_chart(streak_history), use_container_width=True)
    
    with tab3:
        st.plotly_chart(create_milestone_chart(milestones), use_container_width=True)
    
    # Recent milestones
    if not milestones.empty:
        st.write("---")
        st.subheader("🎉 Recent Milestone Achievements")
        
        recent_milestones = milestones.head(10)
        for _, milestone in recent_milestones.iterrows():
            streak_type = "🔥 Current" if milestone['streak_type'] == 'current' else "🏆 Longest"
            st.success(f"{streak_type} **{milestone['habit_name']}** - {milestone['milestone_days']} days achieved on {milestone['achieved_date']}")

def render_streak_manager(user_email: str):
    """Render streak tracker manager"""
    render_streak_tracker_page(user_email)
