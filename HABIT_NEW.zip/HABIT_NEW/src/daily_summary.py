import streamlit as st
import mysql.connector
from datetime import datetime, date, time, timedelta
from typing import List, Dict, Optional, Tuple
import json

from src.db import get_db_connection

def create_daily_summary_table():
    """Create daily_summary_preferences table if it doesn't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_summary_preferences (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                summary_time TIME NOT NULL DEFAULT '20:00:00',
                is_enabled BOOLEAN DEFAULT TRUE,
                include_streaks BOOLEAN DEFAULT TRUE,
                include_progress BOOLEAN DEFAULT TRUE,
                include_missed BOOLEAN DEFAULT TRUE,
                include_completion_rate BOOLEAN DEFAULT TRUE,
                include_motivation BOOLEAN DEFAULT TRUE,
                timezone VARCHAR(50) DEFAULT 'UTC',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_email (user_email),
                INDEX idx_user_email (user_email)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_summary_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                summary_date DATE NOT NULL,
                summary_data JSON NOT NULL,
                sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_read BOOLEAN DEFAULT FALSE,
                INDEX idx_user_email_date (user_email, summary_date),
                INDEX idx_sent_at (sent_at)
            )
        """)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def get_daily_summary_preferences(user_email: str) -> Optional[Dict]:
    """Get daily summary preferences for a user"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT * FROM daily_summary_preferences WHERE user_email = %s
        """, (user_email.lower(),))
        result = cursor.fetchone()
        return result
    finally:
        cursor.close()
        conn.close()

def create_or_update_summary_preferences(user_email: str, summary_time: str, 
                                       is_enabled: bool = True, 
                                       include_streaks: bool = True,
                                       include_progress: bool = True,
                                       include_missed: bool = True,
                                       include_completion_rate: bool = True,
                                       include_motivation: bool = True,
                                       timezone: str = 'UTC') -> bool:
    """Create or update daily summary preferences"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            INSERT INTO daily_summary_preferences 
            (user_email, summary_time, is_enabled, include_streaks, include_progress, 
             include_missed, include_completion_rate, include_motivation, timezone)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
            summary_time = VALUES(summary_time),
            is_enabled = VALUES(is_enabled),
            include_streaks = VALUES(include_streaks),
            include_progress = VALUES(include_progress),
            include_missed = VALUES(include_missed),
            include_completion_rate = VALUES(include_completion_rate),
            include_motivation = VALUES(include_motivation),
            timezone = VALUES(timezone),
            updated_at = CURRENT_TIMESTAMP
        """, (user_email.lower(), summary_time, is_enabled, include_streaks, 
              include_progress, include_missed, include_completion_rate, 
              include_motivation, timezone))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error saving summary preferences: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_habit_completion_data(user_email: str, target_date: date) -> Dict:
    """Get habit completion data for a specific date"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Get all habits for user
        cursor.execute("""
            SELECT id, name, goal FROM habits 
            WHERE user_email = %s AND is_active = TRUE
            ORDER BY created_at
        """, (user_email.lower(),))
        habits = cursor.fetchall()
        
        if not habits:
            return {'habits': [], 'completed': [], 'missed': [], 'completion_rate': 0}
        
        habit_ids = [h['id'] for h in habits]
        
        # Get completion data for target date
        cursor.execute("""
            SELECT habit_id, SUM(amount) as total_amount, COUNT(*) as entries
            FROM habit_logs 
            WHERE user_email = %s AND DATE(log_date) = %s AND habit_id IN %s
            GROUP BY habit_id
        """, (user_email.lower(), target_date, tuple(habit_ids)))
        completions = cursor.fetchall()
        
        # Build completion map
        completion_map = {}
        for comp in completions:
            completion_map[comp['habit_id']] = comp['total_amount']
        
        # Categorize habits
        completed = []
        missed = []
        
        for habit in habits:
            total = completion_map.get(habit['id'], 0)
            if total >= habit['goal']:
                completed.append({
                    'name': habit['name'],
                    'goal': habit['goal'],
                    'completed': total,
                    'progress': min(100, (total / habit['goal']) * 100)
                })
            else:
                missed.append({
                    'name': habit['name'],
                    'goal': habit['goal'],
                    'completed': total,
                    'progress': (total / habit['goal']) * 100 if habit['goal'] > 0 else 0
                })
        
        completion_rate = (len(completed) / len(habits)) * 100 if habits else 0
        
        return {
            'habits': habits,
            'completed': completed,
            'missed': missed,
            'completion_rate': completion_rate
        }
    finally:
        cursor.close()
        conn.close()

def get_streak_data(user_email: str) -> Dict:
    """Get current streak information"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Get current streak for each habit
        cursor.execute("""
            SELECT h.id, h.name, COUNT(*) as streak
            FROM habits h
            LEFT JOIN (
                SELECT habit_id, DATE(log_date) as log_date
                FROM habit_logs
                WHERE user_email = %s
                GROUP BY habit_id, DATE(log_date)
                HAVING SUM(amount) >= h.goal
            ) l ON h.id = l.habit_id
            WHERE h.user_email = %s AND h.is_active = TRUE
            AND l.log_date >= (
                SELECT DATE_SUB(CURDATE(), INTERVAL days DAY)
                FROM (
                    SELECT MIN(DATEDIFF(CURDATE(), DATE(log_date))) as days
                    FROM habit_logs
                    WHERE user_email = %s
                    GROUP BY habit_id
                    HAVING SUM(amount) < h.goal OR SUM(amount) IS NULL
                ) as missing_days
                WHERE days IS NOT NULL
                LIMIT 1
            )
            GROUP BY h.id, h.name
        """, (user_email.lower(), user_email.lower(), user_email.lower()))
        
        streaks = cursor.fetchall()
        
        # Calculate overall streak
        current_streak = 0
        if streaks:
            current_streak = min([s['streak'] for s in streaks])
        
        return {
            'current_streak': current_streak,
            'habit_streaks': streaks
        }
    except Exception as e:
        # Fallback if complex query fails
        return {'current_streak': 0, 'habit_streaks': []}
    finally:
        cursor.close()
        conn.close()

def get_weekly_progress(user_email: str) -> Dict:
    """Get progress data for the past week"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        end_date = date.today()
        start_date = end_date - timedelta(days=6)
        
        cursor.execute("""
            SELECT DATE(log_date) as log_date, COUNT(*) as habits_completed
            FROM (
                SELECT habit_id, DATE(log_date) as log_date, SUM(amount) as total_amount
                FROM habit_logs
                WHERE user_email = %s AND DATE(log_date) BETWEEN %s AND %s
                GROUP BY habit_id, DATE(log_date)
                HAVING total_amount >= (
                    SELECT goal FROM habits WHERE id = completed_habits.habit_id
                )
            ) completed_habits
            GROUP BY DATE(log_date)
            ORDER BY log_date
        """, (user_email.lower(), start_date, end_date))
        
        weekly_data = cursor.fetchall()
        
        # Fill missing days with 0
        week_progress = []
        current_date = start_date
        while current_date <= end_date:
            day_data = next((d for d in weekly_data if d['log_date'] == current_date), None)
            week_progress.append({
                'date': current_date,
                'completed': day_data['habits_completed'] if day_data else 0
            })
            current_date += timedelta(days=1)
        
        return week_progress
    finally:
        cursor.close()
        conn.close()

def generate_daily_summary(user_email: str, target_date: date = None) -> Dict:
    """Generate comprehensive daily summary"""
    if target_date is None:
        target_date = date.today()
    
    preferences = get_daily_summary_preferences(user_email)
    if not preferences or not preferences['is_enabled']:
        return None
    
    # Get all data
    habit_data = get_habit_completion_data(user_email, target_date)
    streak_data = get_streak_data(user_email)
    weekly_progress = get_weekly_progress(user_email)
    
    # Build summary based on preferences
    summary = {
        'date': target_date.strftime('%Y-%m-%d'),
        'user_email': user_email,
        'generated_at': datetime.now().isoformat(),
        'preferences': preferences
    }
    
    # Add sections based on preferences
    if preferences['include_progress']:
        summary['progress'] = habit_data
    
    if preferences['include_streaks']:
        summary['streaks'] = streak_data
    
    if preferences['include_missed']:
        summary['missed'] = habit_data['missed']
    
    if preferences['include_completion_rate']:
        summary['completion_rate'] = habit_data['completion_rate']
    
    if preferences['include_motivation']:
        summary['motivation'] = generate_motivational_message(habit_data, streak_data)
    
    # Add weekly progress
    summary['weekly_progress'] = weekly_progress
    
    return summary

def generate_motivational_message(habit_data: Dict, streak_data: Dict) -> str:
    """Generate motivational message based on performance"""
    completion_rate = habit_data['completion_rate']
    current_streak = streak_data['current_streak']
    
    messages = []
    
    if completion_rate == 100:
        messages.append("🎉 Perfect day! You completed all your habits!")
    elif completion_rate >= 80:
        messages.append("🌟 Great job! You're on fire today!")
    elif completion_rate >= 60:
        messages.append("💪 Good effort! Keep pushing forward!")
    elif completion_rate >= 40:
        messages.append("📈 Making progress! Every step counts!")
    else:
        messages.append("🌱 Tomorrow is a new day to grow!")
    
    if current_streak >= 7:
        messages.append(f"🔥 Amazing {current_streak}-day streak!")
    elif current_streak >= 3:
        messages.append(f"⚡ Nice {current_streak}-day streak going!")
    
    missed_count = len(habit_data['missed'])
    if missed_count > 0:
        messages.append(f"📝 {missed_count} habit{'s' if missed_count > 1 else ''} to catch up on tomorrow.")
    
    return " ".join(messages)

def save_daily_summary(user_email: str, summary: Dict) -> bool:
    """Save daily summary to logs"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            INSERT INTO daily_summary_logs (user_email, summary_date, summary_data)
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE
            summary_data = VALUES(summary_data),
            sent_at = CURRENT_TIMESTAMP
        """, (user_email.lower(), summary['date'], json.dumps(summary)))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error saving daily summary: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_daily_summaries(user_email: str, days: int = 7) -> List[Dict]:
    """Get recent daily summaries"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        start_date = date.today() - timedelta(days=days-1)
        
        cursor.execute("""
            SELECT * FROM daily_summary_logs 
            WHERE user_email = %s AND summary_date >= %s
            ORDER BY summary_date DESC
        """, (user_email.lower(), start_date))
        
        results = cursor.fetchall()
        
        # Parse JSON data
        for result in results:
            if result['summary_data']:
                result['summary_data'] = json.loads(result['summary_data'])
        
        return results
    finally:
        cursor.close()
        conn.close()

def render_daily_summary_card(summary: Dict) -> None:
    """Render a daily summary as a card"""
    if not summary or not summary.get('summary_data'):
        return
    
    data = summary['summary_data']
    date_str = datetime.strptime(data['date'], '%Y-%m-%d').strftime('%A, %B %d, %Y')
    
    with st.container():
        st.markdown(f"""
        <div style="border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 8px; background-color: #f8f9fa;">
            <h4>📊 Daily Summary - {date_str}</h4>
        </div>
        """, unsafe_allow_html=True)
        
        # Completion Rate
        if data.get('completion_rate') is not None:
            st.metric("Completion Rate", f"{data['completion_rate']:.1f}%")
            st.progress(data['completion_rate'] / 100)
        
        # Progress Details
        if data.get('progress'):
            progress = data['progress']
            completed = progress['completed']
            missed = progress['missed']
            
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"✅ **Completed:** {len(completed)} habits")
                for habit in completed[:3]:  # Show first 3
                    st.write(f"  • {habit['name']} ({habit['completed']}/{habit['goal']})")
                if len(completed) > 3:
                    st.write(f"  ... and {len(completed) - 3} more")
            
            with col2:
                if missed:
                    st.write(f"⏳ **Missed:** {len(missed)} habits")
                    for habit in missed[:3]:  # Show first 3
                        st.write(f"  • {habit['name']} ({habit['completed']}/{habit['goal']})")
                    if len(missed) > 3:
                        st.write(f"  ... and {len(missed) - 3} more")
        
        # Streaks
        if data.get('streaks') and data['streaks']['current_streak'] > 0:
            st.write(f"🔥 **Current Streak:** {data['streaks']['current_streak']} days")
        
        # Motivation
        if data.get('motivation'):
            st.info(data['motivation'])
        
        # Weekly Progress
        if data.get('weekly_progress'):
            weekly = data['weekly_progress']
            total_weekly = sum(day['completed'] for day in weekly)
            st.write(f"📈 **Weekly Total:** {total_weekly} habits completed")

def render_daily_summary_settings(user_email: str):
    """Render daily summary settings form"""
    st.subheader("📊 Daily Summary Settings")
    
    preferences = get_daily_summary_preferences(user_email)
    
    # Default values if no preferences exist
    if not preferences:
        preferences = {
            'summary_time': '20:00:00',
            'is_enabled': True,
            'include_streaks': True,
            'include_progress': True,
            'include_missed': True,
            'include_completion_rate': True,
            'include_motivation': True,
            'timezone': 'UTC'
        }
    
    with st.form("daily_summary_settings"):
        # Enable/disable
        is_enabled = st.checkbox("Enable Daily Summaries", value=preferences['is_enabled'])
        
        if is_enabled:
            # Time selection
            # Handle TIME stored as Python time or simple strings like 'HH:MM' or 'HH:MM:SS'
            raw_time = preferences['summary_time']
            default_time = time(20, 0)

            parsed_time = default_time
            try:
                if isinstance(raw_time, time):
                    parsed_time = raw_time
                else:
                    parts = str(raw_time).split(":")
                    if len(parts) >= 2:
                        hour = int(parts[0])
                        minute = int(parts[1])
                        parsed_time = time(hour, minute)
            except Exception:
                parsed_time = default_time

            summary_time = st.time_input(
                "Summary Time",
                value=parsed_time
            )
            
            # Content preferences
            st.write("**Include in Summary:**")
            include_streaks = st.checkbox("Streak Information", value=preferences['include_streaks'])
            include_progress = st.checkbox("Habit Progress", value=preferences['include_progress'])
            include_missed = st.checkbox("Missed Habits", value=preferences['include_missed'])
            include_completion_rate = st.checkbox("Completion Rate", value=preferences['include_completion_rate'])
            include_motivation = st.checkbox("Motivational Messages", value=preferences['include_motivation'])
            
            # Timezone
            timezone = st.selectbox(
                "Timezone",
                options=['UTC', 'EST', 'PST', 'CST', 'MST', 'GMT', 'CET', 'JST'],
                index=0 if preferences['timezone'] == 'UTC' else 1
            )
        else:
            summary_time = preferences['summary_time']
            include_streaks = include_progress = include_missed = False
            include_completion_rate = include_motivation = False
            timezone = preferences['timezone']
        
        submitted = st.form_submit_button("Save Settings")
        
        if submitted:
            success = create_or_update_summary_preferences(
                user_email, summary_time.strftime('%H:%M:%S'), is_enabled,
                include_streaks, include_progress, include_missed,
                include_completion_rate, include_motivation, timezone
            )
            
            if success:
                st.success("Daily summary settings saved!")
                st.rerun()

def check_and_show_daily_summary(user_email: str):
    """Check if daily summary should be shown and display it"""
    preferences = get_daily_summary_preferences(user_email)
    
    if not preferences or not preferences['is_enabled']:
        return
    
    # Check if today's summary has already been shown
    today = date.today()
    summaries = get_daily_summaries(user_email, 1)
    
    if summaries and summaries[0]['summary_date'] == today and summaries[0]['is_read']:
        return  # Already shown today
    
    # Generate and show today's summary
    summary = generate_daily_summary(user_email, today)
    if summary:
        # Save to logs
        save_daily_summary(user_email, summary)
        
        # Show the summary
        st.success("📊 **Your Daily Summary is Ready!**")
        render_daily_summary_card({'summary_data': summary})
        
        # Mark as read
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                UPDATE daily_summary_logs SET is_read = TRUE 
                WHERE user_email = %s AND summary_date = %s
            """, (user_email.lower(), today))
            conn.commit()
        finally:
            cursor.close()
            conn.close()

def render_daily_summary_manager(user_email: str):
    """Main daily summary management page"""
    st.title("📊 Daily Summary Manager")
    
    # Create tables if they don't exist
    create_daily_summary_table()
    
    # Tab layout
    tab1, tab2, tab3 = st.tabs(["📈 Today's Summary", "⚙️ Settings", "📜 History"])
    
    with tab1:
        st.subheader("Today's Summary")
        check_and_show_daily_summary(user_email)
        
        # Manual generation option
        if st.button("🔄 Generate Today's Summary Now"):
            summary = generate_daily_summary(user_email)
            if summary:
                save_daily_summary(user_email, summary)
                st.success("Summary generated successfully!")
                st.rerun()
            else:
                st.info("Daily summaries are disabled in your settings.")
    
    with tab2:
        render_daily_summary_settings(user_email)
    
    with tab3:
        st.subheader("Summary History")
        summaries = get_daily_summaries(user_email, 30)  # Last 30 days
        
        if not summaries:
            st.info("No summary history available.")
        else:
            for summary in summaries:
                with st.expander(f"📊 {summary['summary_date']} - {'✅ Read' if summary['is_read'] else '🔔 Unread'}"):
                    render_daily_summary_card(summary)
