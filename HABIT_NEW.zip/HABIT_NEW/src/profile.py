import streamlit as st
from .db import get_conn


def _init_profile_table():
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS user_profiles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) UNIQUE NOT NULL,
                full_name VARCHAR(255),
                address TEXT,
                bio TEXT,
                picture LONGBLOB,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_user_profiles_user
                    FOREIGN KEY (user_email) REFERENCES users(email)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cnx.commit()


def get_profile(email: str) -> dict:
    _init_profile_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT full_name, address, bio, picture FROM user_profiles WHERE user_email=%s",
            (email.lower(),),
        )
        row = cur.fetchone()
        if not row:
            return {"full_name": "", "address": "", "bio": "", "picture": None}
        return {"full_name": row[0] or "", "address": row[1] or "", "bio": row[2] or "", "picture": row[3]}


essential_fields = ["full_name", "address", "bio"]


def upsert_profile(email: str, full_name: str, address: str, bio: str, picture_bytes: bytes | None, remove_picture: bool = False) -> bool:
    _init_profile_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute("SELECT 1 FROM user_profiles WHERE user_email=%s", (email.lower(),))
        exists = cur.fetchone() is not None
        try:
            if exists:
                if picture_bytes is not None:
                    cur.execute(
                        "UPDATE user_profiles SET full_name=%s, address=%s, bio=%s, picture=%s WHERE user_email=%s",
                        (full_name, address, bio, picture_bytes, email.lower()),
                    )
                elif remove_picture:
                    cur.execute(
                        "UPDATE user_profiles SET full_name=%s, address=%s, bio=%s, picture=NULL WHERE user_email=%s",
                        (full_name, address, bio, email.lower()),
                    )
                else:
                    cur.execute(
                        "UPDATE user_profiles SET full_name=%s, address=%s, bio=%s WHERE user_email=%s",
                        (full_name, address, bio, email.lower()),
                    )
            else:
                cur.execute(
                    "INSERT INTO user_profiles (user_email, full_name, address, bio, picture) VALUES (%s,%s,%s,%s,%s)",
                    (email.lower(), full_name, address, bio, picture_bytes if not remove_picture else None),
                )
            cnx.commit()
            return True
        except Exception:
            return False
