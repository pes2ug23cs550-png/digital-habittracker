import streamlit as st
import mysql.connector
from datetime import datetime, time, timedelta
from typing import List, Dict, Optional
import json

from src.db import get_db_connection
from src.snooze_system import get_snooze_button, is_item_snoozed
from src.notification_settings import apply_notification_settings


REMINDERS_TABLE = "habit_reminders"


def ensure_column_exists(cursor, column_name: str, definition: str):
    cursor.execute("""
        SELECT COUNT(*)
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = %s
          AND COLUMN_NAME = %s
    """, (REMINDERS_TABLE, column_name))
    if cursor.fetchone()[0] == 0:
        cursor.execute(f"ALTER TABLE {REMINDERS_TABLE} ADD COLUMN {column_name} {definition}")


def create_habit_reminders_table():
    """Ensure habit_reminders table exists with required columns."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {REMINDERS_TABLE} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                reminder_time TIME NOT NULL,
                reminder_days JSON NOT NULL,
                reminder_type ENUM('daily', 'weekly', 'custom') DEFAULT 'daily',
                is_active BOOLEAN DEFAULT TRUE,
                message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (habit_id) REFERENCES habits(id),
                INDEX idx_user_email (user_email),
                INDEX idx_habit_id (habit_id),
                INDEX idx_is_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        ensure_column_exists(cursor, "user_email", "VARCHAR(255) NOT NULL")
        ensure_column_exists(cursor, "reminder_days", "JSON NOT NULL")
        ensure_column_exists(cursor, "reminder_type", "ENUM('daily','weekly','custom') DEFAULT 'daily'")
        ensure_column_exists(cursor, "is_active", "BOOLEAN DEFAULT TRUE")
        ensure_column_exists(cursor, "message", "TEXT NULL")
        
        # Migrate legacy user_id column if present
        cursor.execute("""
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = 'user_id'
        """, (REMINDERS_TABLE,))
        if cursor.fetchone()[0]:
            cursor.execute(f"""
                UPDATE {REMINDERS_TABLE} hr
                JOIN users u ON hr.user_id = u.id
                SET hr.user_email = u.email
                WHERE (hr.user_email IS NULL OR hr.user_email = '')
            """)
            cursor.execute(f"ALTER TABLE {REMINDERS_TABLE} DROP COLUMN user_id")
        
        # Ensure reminder_days column is JSON type
        cursor.execute("""
            SELECT DATA_TYPE
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = 'reminder_days'
        """, (REMINDERS_TABLE,))
        data_type = cursor.fetchone()
        if data_type and data_type[0].lower() != "json":
            cursor.execute(f"ALTER TABLE {REMINDERS_TABLE} MODIFY COLUMN reminder_days JSON NOT NULL")
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def create_habit_reminder(user_email: str, habit_id: int, reminder_time: str, 
                         reminder_days: List[int], reminder_type: str = 'daily', 
                         message: str = "") -> bool:
    """Create a new reminder for a specific habit"""
    create_habit_reminders_table()
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        days_json = json.dumps(reminder_days)
        cursor.execute(f"""
            INSERT INTO {REMINDERS_TABLE} (user_email, habit_id, reminder_time, 
                                           reminder_days, reminder_type, message)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (user_email.lower(), habit_id, reminder_time, days_json, reminder_type, message))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error creating reminder: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_reminders_for_habit(user_email: str, habit_id: int) -> List[Dict]:
    """Get all reminders for a specific habit"""
    create_habit_reminders_table()
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute(f"""
            SELECT * FROM {REMINDERS_TABLE} 
            WHERE user_email = %s AND habit_id = %s AND is_active = TRUE
            ORDER BY reminder_time
        """, (user_email.lower(), habit_id))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def get_all_reminders_for_user(user_email: str) -> List[Dict]:
    """Get all reminders for a user with habit names"""
    create_habit_reminders_table()
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute(f"""
            SELECT r.*, h.name as habit_name 
            FROM {REMINDERS_TABLE} r
            JOIN habits h ON r.habit_id = h.id
            WHERE r.user_email = %s AND r.is_active = TRUE
            ORDER BY r.reminder_time, h.name
        """, (user_email.lower(),))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def update_habit_reminder(reminder_id: int, reminder_time: str, 
                         reminder_days: List[int], reminder_type: str = 'daily', 
                         message: str = "") -> bool:
    """Update an existing habit reminder"""
    create_habit_reminders_table()
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        days_json = json.dumps(reminder_days)
        cursor.execute(f"""
            UPDATE {REMINDERS_TABLE} 
            SET reminder_time = %s, reminder_days = %s, reminder_type = %s, 
                message = %s, updated_at = CURRENT_TIMESTAMP
            WHERE id = %s
        """, (reminder_time, days_json, reminder_type, message, reminder_id))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error updating reminder: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def delete_habit_reminder(reminder_id: int) -> bool:
    """Delete a habit reminder (set as inactive)"""
    create_habit_reminders_table()
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(f"""
            UPDATE {REMINDERS_TABLE} SET is_active = FALSE WHERE id = %s
        """, (reminder_id,))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error deleting reminder: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_pending_reminders(user_email: str) -> List[Dict]:
    """Get reminders that should trigger now for a user"""
    create_habit_reminders_table()
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        current_time = datetime.now().time()
        current_day = datetime.now().weekday()  # 0=Monday, 6=Sunday
        
        cursor.execute(f"""
            SELECT r.*, h.name as habit_name 
            FROM {REMINDERS_TABLE} r
            JOIN habits h ON r.habit_id = h.id
            WHERE r.user_email = %s 
            AND r.is_active = TRUE 
            AND r.reminder_time <= %s
            AND JSON_CONTAINS(r.reminder_days, %s)
        """, (user_email.lower(), current_time, json.dumps(current_day)))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def render_reminder_form(user_email: str, habit_id: int, habit_name: str, 
                        reminder: Optional[Dict] = None, form_context: str = "default"):
    """Render reminder creation/edit form for a specific habit"""
    st.subheader(f"⏰ Set Reminder for: {habit_name}" if not reminder else f"✏️ Edit Reminder for: {habit_name}")
    
    form_key = f"reminder_form_{habit_id}_{reminder['id']}" if reminder else f"reminder_form_{habit_id}_new_{form_context}"
    with st.form(form_key):
        # Reminder type selection
        reminder_type = st.selectbox(
            "Reminder Type",
            options=['daily', 'weekly', 'custom'],
            index=0 if not reminder else ['daily', 'weekly', 'custom'].index(reminder['reminder_type']),
            help="Daily: every day, Weekly: specific days, Custom: your selection"
        )
        
        # Time selection
        current_time = datetime.now().strftime("%H:%M")
        default_time = reminder['reminder_time'].strftime("%H:%M") if reminder else "09:00"
        reminder_time = st.time_input("Reminder Time", value=default_time)
        
        # Day selection (for weekly and custom)
        if reminder_type in ['weekly', 'custom']:
            days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            default_days = json.loads(reminder['reminder_days']) if reminder else [0, 1, 2, 3, 4]  # Weekdays default
            
            if reminder_type == 'weekly':
                selected_days = st.multiselect(
                    "Select Days",
                    options=days,
                    default=[days[i] for i in default_days],
                    help="Choose which days to receive reminders"
                )
            else:  # custom
                selected_days = st.multiselect(
                    "Custom Day Selection",
                    options=days,
                    default=[days[i] for i in default_days],
                    help="Customize your reminder schedule"
                )
        else:
            selected_days = list(range(7))  # All days for daily
        
        # Custom message
        default_message = reminder.get('message', '') if reminder else f"Time to {habit_name}!"
        custom_message = st.text_input("Custom Message (optional)", value=default_message)
        
        # Submit button
        submitted = st.form_submit_button("Save Reminder" if not reminder else "Update Reminder")
        
        if submitted:
            if reminder_type in ['weekly', 'custom'] and not selected_days:
                st.error("Please select at least one day")
                return False
            
            # Convert selected days back to indices
            selected_day_indices = [days.index(day) for day in selected_days] if selected_days else list(range(7))
            
            final_message = custom_message if custom_message else f"Time to {habit_name}!"
            
            if reminder:
                success = update_habit_reminder(
                    reminder['id'], 
                    reminder_time.strftime("%H:%M"), 
                    selected_day_indices, 
                    reminder_type, 
                    final_message
                )
            else:
                success = create_habit_reminder(
                    user_email, 
                    habit_id, 
                    reminder_time.strftime("%H:%M"), 
                    selected_day_indices, 
                    reminder_type, 
                    final_message
                )
            
            if success:
                st.success("Reminder saved successfully!")
                st.rerun()
            return success
        
        return False

def render_habit_reminders_list(user_email: str, habit_id: int, habit_name: str):
    """Render reminders for a specific habit"""
    reminders = get_reminders_for_habit(user_email, habit_id)
    
    if not reminders:
        st.info(f"No reminders set for '{habit_name}'.")
        return
    
    st.subheader(f"⏰ Reminders for {habit_name}")
    
    for reminder in reminders:
        with st.expander(f"⏰ {reminder['reminder_time']} - {reminder['reminder_type'].title()}"):
            days = json.loads(reminder['reminder_days'])
            day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            selected_days = [day_names[i] for i in days]
            
            st.write(f"**Days:** {', '.join(selected_days)}")
            st.write(f"**Type:** {reminder['reminder_type'].title()}")
            if reminder['message']:
                st.write(f"**Message:** {reminder['message']}")
            st.write(f"**Created:** {reminder['created_at'].strftime('%Y-%m-%d %H:%M')}")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("✏️ Edit", key=f"edit_reminder_{reminder['id']}"):
                    st.session_state[f"edit_reminder_{reminder['id']}"] = True
            with col2:
                if st.button("🗑️ Delete", key=f"delete_reminder_{reminder['id']}"):
                    if delete_habit_reminder(reminder['id']):
                        st.success("Reminder deleted!")
                        st.rerun()

def render_reminder_card(reminder: Dict) -> None:
    """Render a single reminder as a card"""
    days = json.loads(reminder['reminder_days'])
    day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    selected_days = [day_names[i] for i in days]
    
    with st.container():
        st.markdown(f"""
        <div style="border: 1px solid #ddd; padding: 10px; margin: 5px 0; border-radius: 5px; background-color: #f9f9f9;">
            <strong>🔔 {reminder['habit_name']}</strong><br>
            ⏰ {reminder['reminder_time']} | 📅 {', '.join(selected_days)}<br>
            📝 {reminder['reminder_type'].title()}
            {f"<br>💬 {reminder['message']}" if reminder['message'] else ""}
        </div>
        """, unsafe_allow_html=True)

def check_and_show_reminders(user_email: str):
    """Check for pending reminders and show them"""
    pending = get_pending_reminders(user_email)
    
    if pending:
        st.success("🔔 **Pending Reminders:**")
        for reminder in pending:
            # Check if reminder is snoozed
            if is_item_snoozed(user_email, reminder['id'], None, 'habit_reminder'):
                continue  # Skip snoozed reminders
            
            # Apply notification settings
            notification_config = apply_notification_settings(user_email, 'habit_reminder', reminder['habit_id'])
            if not notification_config:
                continue  # Notification disabled by settings
            
            # Format message based on settings
            message = reminder['message'] if reminder['message'] else f"Time to {reminder['habit_name']}!"
            if notification_config['message_template']:
                try:
                    message = notification_config['message_template'].format(
                        habit_name=reminder['habit_name'],
                        time=reminder['reminder_time'].strftime('%H:%M'),
                        goal="your daily goal"
                    )
                except:
                    pass  # Fallback to default message
            
            # Show reminder with appropriate style
            if notification_config['style'] == 'detailed':
                st.success(f"🔔 **{reminder['habit_name']} Reminder**")
                st.info(message)
                st.write(f"⏰ Scheduled for: {reminder['reminder_time'].strftime('%H:%M')}")
            elif notification_config['style'] == 'minimal':
                st.info(f"⏰ {reminder['habit_name']}")
            else:  # simple
                st.info(f"⏰ **{reminder['habit_name']}** - {reminder['reminder_time']}")
                st.write(message)
            
            # Add quick action buttons
            col1, col2, col3 = st.columns(3)
            with col1:
                if st.button(f"✅ Mark {reminder['habit_name']} Complete", key=f"quick_complete_r_{reminder['id']}"):
                    st.success(f"Great job completing {reminder['habit_name']}!")
            with col2:
                get_snooze_button(
                    user_email, reminder['id'], None, 'habit_reminder',
                    reminder['habit_name'], reminder['reminder_time']
                )
            with col3:
                if st.button(f"❌ Dismiss {reminder['habit_name']}", key=f"dismiss_r_{reminder['id']}"):
                    st.info(f"Dismissed reminder for {reminder['habit_name']}")

def get_habit_reminders_manager(user_email: str):
    """Main habit reminders management page"""
    st.title("🔔 Habit Reminders Manager")
    
    # Create reminders table if it doesn't exist
    create_habit_reminders_table()
    
    # Get user habits
    from src.habits import list_habits
    habits_list = list_habits(user_email)
    
    if not habits_list:
        st.warning("You need to create habits first before setting reminders!")
        return
    
    # Convert to dict format
    habits = []
    for habit in habits_list:
        habits.append({'id': habit[0], 'name': habit[1]})
    
    # Tab layout
    tab1, tab2, tab3 = st.tabs(["📋 All Reminders", "➕ Add New", "🎯 By Habit"])
    
    with tab1:
        all_reminders = get_all_reminders_for_user(user_email)
        if not all_reminders:
            st.info("No reminders set. Create one to remind yourself!")
        else:
            st.subheader("All Your Reminders")
            for reminder in all_reminders:
                render_reminder_card(reminder)
    
    with tab2:
        st.subheader("Add New Reminder")
        
        # Habit selection
        habit_options = {h['id']: h['name'] for h in habits}
        selected_habit_id = st.selectbox(
            "Select Habit",
            options=list(habit_options.keys()),
            format_func=lambda x: habit_options[x]
        )
        
        selected_habit_name = habit_options[selected_habit_id]
        
        # Render the reminder form
        render_reminder_form(user_email, selected_habit_id, selected_habit_name, form_context="add_new")
    
    with tab3:
        st.subheader("Reminders by Habit")
        
        # Habit selection for viewing
        selected_habit_id = st.selectbox(
            "Select Habit to View Reminders",
            options=list(habit_options.keys()),
            format_func=lambda x: habit_options[x],
            key="view_habit_select"
        )
        
        selected_habit_name = habit_options[selected_habit_id]
        
        # Show reminders for selected habit
        render_habit_reminders_list(user_email, selected_habit_id, selected_habit_name)
        
        # Add new reminder for this habit
        st.write("---")
        render_reminder_form(user_email, selected_habit_id, selected_habit_name, form_context=f"habit_{selected_habit_id}")
