"""
Initialize all database tables for the habit tracker application
"""
import sys
import os
from typing import Dict

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import streamlit as st
    import mysql.connector
    STREAMLIT_AVAILABLE = True
except ImportError:
    st = None
    mysql = None
    STREAMLIT_AVAILABLE = False

def get_conn():
    if not STREAMLIT_AVAILABLE or mysql is None:
        raise RuntimeError("streamlit and mysql-connector-python are required")
    
    # Use streamlit secrets for database connection
    cfg = st.secrets.get("mysql", {})
    kwargs = {
        "host": cfg.get("host", "localhost"),
        "user": cfg.get("user", "root"),
        "password": cfg.get("password", ""),
        "database": cfg.get("database", "habit"),
        "port": int(cfg.get("port", 3306)),
    }
    if cfg.get("auth_plugin"):
        kwargs["auth_plugin"] = cfg.get("auth_plugin")
    return mysql.connector.connect(**kwargs)

def ensure_columns_exist(cursor, table_name: str, columns: Dict[str, str]):
    """Ensure required columns exist on a table (adds them if missing)."""
    for column_name, column_definition in columns.items():
        cursor.execute("""
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = %s
        """, (table_name, column_name))
        exists = cursor.fetchone()[0]
        if not exists:
            cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_definition}")


def create_all_tables():
    """Create all necessary database tables"""
    conn = get_conn()
    cursor = conn.cursor()
    
    try:
        # Users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                password_salt VARCHAR(255) DEFAULT '',
                provider VARCHAR(50) DEFAULT 'email',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP NULL,
                is_active BOOLEAN DEFAULT TRUE,
                session_version INT DEFAULT 0
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Habits table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habits (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                goal INT NOT NULL DEFAULT 1,
                frequency VARCHAR(50) DEFAULT 'daily',
                category VARCHAR(100),
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user_email (user_email),
                INDEX idx_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Habit logs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL,
                log_date DATE NOT NULL,
                amount INT DEFAULT 1,
                completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_habit_date (habit_id, log_date),
                CONSTRAINT fk_habit_logs_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Add amount column to existing habit_logs table if it doesn't exist
        try:
            cursor.execute("SELECT amount FROM habit_logs LIMIT 1")
            cursor.fetchone()
        except Exception:
            cursor.execute("ALTER TABLE habit_logs ADD COLUMN amount INT DEFAULT 1")
        
        # Add completed_at column to existing habit_logs table if it doesn't exist
        try:
            cursor.execute("SELECT completed_at FROM habit_logs LIMIT 1")
            cursor.fetchone()
        except:
            cursor.execute("ALTER TABLE habit_logs ADD COLUMN completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
        
        # Add provider column to existing users table if it doesn't exist
        try:
            cursor.execute("SELECT provider FROM users LIMIT 1")
            cursor.fetchone()
        except:
            cursor.execute("ALTER TABLE users ADD COLUMN provider VARCHAR(50) DEFAULT 'email'")
        
        # Add password_salt column to existing users table if it doesn't exist
        try:
            cursor.execute("SELECT password_salt FROM users LIMIT 1")
            cursor.fetchone()
        except:
            cursor.execute("ALTER TABLE users ADD COLUMN password_salt VARCHAR(255) DEFAULT ''")
        
        # Add session_version column to existing users table if it doesn't exist
        try:
            cursor.execute("SELECT session_version FROM users LIMIT 1")
            cursor.fetchone()
        except:
            cursor.execute("ALTER TABLE users ADD COLUMN session_version INT DEFAULT 0")
        
        # Habit categories table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_category (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) UNIQUE NOT NULL,
                description TEXT,
                color VARCHAR(7) DEFAULT '#007bff',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "habit_category", {
            "name": "VARCHAR(100) NOT NULL DEFAULT ''",
            "description": "TEXT NULL",
            "color": "VARCHAR(7) DEFAULT '#007bff'"
        })
        
        # Habit frequency table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_frequency (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL,
                frequency_type VARCHAR(50) NOT NULL,
                days_of_week JSON,
                times_of_day JSON,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_frequency_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Daily summary preferences table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_summary_preferences (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                is_enabled BOOLEAN DEFAULT TRUE,
                time_preference TIME DEFAULT '20:00:00',
                include_streaks BOOLEAN DEFAULT TRUE,
                include_badges BOOLEAN DEFAULT TRUE,
                include_motivation BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_email (user_email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Daily summary logs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_summary_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                summary_date DATE NOT NULL,
                content TEXT,
                sent_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_date (user_email, summary_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Badge system tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS badges (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                description TEXT NOT NULL,
                icon VARCHAR(50) NOT NULL,
                category ENUM('consistency', 'streaks', 'milestones', 'improvement', 'special', 'seasonal', 'mastery') NOT NULL,
                tier ENUM('bronze', 'silver', 'gold', 'platinum', 'diamond') DEFAULT 'bronze',
                criteria JSON,
                points_value INT DEFAULT 10,
                is_active BOOLEAN DEFAULT TRUE,
                is_secret BOOLEAN DEFAULT FALSE,
                requirement_type VARCHAR(100),
                requirement_value INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_category (category),
                INDEX idx_tier (tier),
                INDEX idx_active (is_active),
                INDEX idx_points (points_value)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "badges", {
            "description": "TEXT NOT NULL",
            "icon": "VARCHAR(50) NOT NULL DEFAULT '🎯'",
            "category": "ENUM('consistency','streaks','milestones','improvement','special','seasonal','mastery') NOT NULL DEFAULT 'consistency'",
            "tier": "ENUM('bronze','silver','gold','platinum','diamond') NOT NULL DEFAULT 'bronze'",
            "criteria": "JSON NULL",
            "points_value": "INT DEFAULT 10",
            "is_active": "BOOLEAN DEFAULT TRUE",
            "is_secret": "BOOLEAN DEFAULT FALSE",
            "requirement_type": "VARCHAR(100) NULL",
            "requirement_value": "INT NULL"
        })
        cursor.execute("""
            UPDATE badges
            SET criteria = JSON_OBJECT('type', requirement_type, 'target', requirement_value)
            WHERE (criteria IS NULL OR JSON_TYPE(criteria) IS NULL)
              AND requirement_type IS NOT NULL
              AND requirement_value IS NOT NULL
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_badges (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                badge_id INT NOT NULL,
                earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                progress_data JSON,
                is_displayed BOOLEAN DEFAULT TRUE,
                notes TEXT,
                UNIQUE KEY uniq_user_badge (user_email, badge_id),
                CONSTRAINT fk_user_badge_badge
                    FOREIGN KEY (badge_id) REFERENCES badges(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "user_badges", {
            "progress_data": "JSON NULL",
            "is_displayed": "BOOLEAN DEFAULT TRUE",
            "notes": "TEXT NULL"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS badge_progress (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                badge_id INT NOT NULL,
                current_progress INT DEFAULT 0,
                target_progress INT NOT NULL,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_badge_progress (user_email, badge_id),
                CONSTRAINT fk_badge_progress_badge
                    FOREIGN KEY (badge_id) REFERENCES badges(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "badge_progress", {
            "current_progress": "INT DEFAULT 0",
            "target_progress": "INT NOT NULL DEFAULT 1",
            "last_updated": "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_points (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                total_points INT DEFAULT 0,
                level INT DEFAULT 1,
                points_to_next_level INT DEFAULT 100,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_points (user_email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "user_points", {
            "total_points": "INT DEFAULT 0",
            "level": "INT DEFAULT 1",
            "points_to_next_level": "INT DEFAULT 100",
            "last_updated": "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS badge_notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                badge_id INT NOT NULL,
                notification_type ENUM('earned', 'progress', 'milestone') NOT NULL,
                message TEXT,
                is_read BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_notification_badge
                    FOREIGN KEY (badge_id) REFERENCES badges(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "badge_notifications", {
            "notification_type": "ENUM('earned','progress','milestone') NOT NULL DEFAULT 'earned'",
            "is_read": "BOOLEAN DEFAULT FALSE"
        })
        
        # Streak tracker tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_streaks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                current_streak INT DEFAULT 0,
                longest_streak INT DEFAULT 0,
                last_completion_date DATE NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_habit (user_email, habit_id),
                CONSTRAINT fk_streak_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Streak milestones table (aligned with streak_tracker module)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS streak_milestones (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                milestone_days INT NOT NULL,
                achieved_date DATE NOT NULL,
                streak_type ENUM('current', 'longest') NOT NULL,
                celebration_sent BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_habit (user_email, habit_id),
                INDEX idx_milestone (milestone_days),
                INDEX idx_achieved_date (achieved_date),
                CONSTRAINT fk_milestone_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Streak history table (aligned with streak_tracker module)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS streak_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                streak_length INT NOT NULL,
                streak_start_date DATE NOT NULL,
                streak_end_date DATE NOT NULL,
                is_current BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_habit (user_email, habit_id),
                INDEX idx_streak_length (streak_length),
                INDEX idx_dates (streak_start_date, streak_end_date),
                CONSTRAINT fk_history_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Habit reminders table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_reminders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL,
                user_email VARCHAR(255) NOT NULL,
                reminder_time TIME NOT NULL,
                days_of_week JSON,
                is_enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                CONSTRAINT fk_reminder_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Notifications table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NULL,
                title VARCHAR(255) NOT NULL,
                message TEXT,
                notification_type VARCHAR(100) NOT NULL,
                is_read BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                read_at TIMESTAMP NULL,
                INDEX idx_user_email (user_email),
                INDEX idx_unread (is_read),
                INDEX idx_notification_habit (habit_id),
                CONSTRAINT fk_notification_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        # Ensure habit_id exists on older installations
        ensure_columns_exist(cursor, "notifications", {
            "habit_id": "INT NULL"
        })
        
        # Notification settings tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notification_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                email_notifications BOOLEAN DEFAULT TRUE,
                push_notifications BOOLEAN DEFAULT TRUE,
                reminder_notifications BOOLEAN DEFAULT TRUE,
                achievement_notifications BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_settings (user_email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Notification tones table (aligned with notification_settings module)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notification_tones (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tone_name VARCHAR(100) NOT NULL,
                tone_file VARCHAR(255) NOT NULL,
                category VARCHAR(50) DEFAULT 'general',
                is_premium BOOLEAN DEFAULT FALSE,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_category (category),
                INDEX idx_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "notification_tones", {
            "tone_name": "VARCHAR(100) NOT NULL DEFAULT ''",
            "tone_file": "VARCHAR(255) NOT NULL DEFAULT ''",
            "category": "VARCHAR(50) DEFAULT 'general'",
            "is_premium": "BOOLEAN DEFAULT FALSE",
            "is_active": "BOOLEAN DEFAULT TRUE"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notification_preferences (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NULL,
                notification_type VARCHAR(100) NOT NULL,
                tone_id INT,
                is_enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                CONSTRAINT fk_preference_tone
                    FOREIGN KEY (tone_id) REFERENCES notification_tones(id)
                    ON DELETE SET NULL,
                INDEX idx_habit_id (habit_id),
                UNIQUE KEY uniq_user_type (user_email, notification_type)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Motivational system tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS motivational_quotes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                quote_text TEXT NOT NULL,
                author VARCHAR(255),
                category ENUM('general', 'consistency', 'streaks', 'improvement', 'setback', 'achievement', 'motivation', 'discipline', 'success', 'persistence') NOT NULL,
                mood_tag ENUM('uplifting', 'encouraging', 'thoughtful', 'energetic', 'calm', 'determined') DEFAULT 'encouraging',
                length_tag ENUM('short', 'medium', 'long') DEFAULT 'medium',
                is_active BOOLEAN DEFAULT TRUE,
                usage_count INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_category (category),
                INDEX idx_mood_tag (mood_tag),
                INDEX idx_length_tag (length_tag),
                INDEX idx_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "motivational_quotes", {
            "quote_text": "TEXT",
            "author": "VARCHAR(255) NULL",
            "category": "ENUM('general','consistency','streaks','improvement','setback','achievement','motivation','discipline','success','persistence') NOT NULL DEFAULT 'motivation'",
            "mood_tag": "ENUM('uplifting','encouraging','thoughtful','energetic','calm','determined') DEFAULT 'encouraging'",
            "length_tag": "ENUM('short','medium','long') DEFAULT 'medium'",
            "usage_count": "INT DEFAULT 0"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS motivational_tips (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tip_text TEXT NOT NULL,
                tip_type ENUM('general', 'consistency', 'streak_building', 'habit_formation', 'goal_setting', 'time_management', 'motivation', 'overcoming_setbacks') NOT NULL,
                difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
                context_trigger ENUM('low_consistency', 'new_streak', 'broken_streak', 'milestone', 'plateau', 'high_performance', 'weekly_review') DEFAULT 'low_consistency',
                is_actionable BOOLEAN DEFAULT TRUE,
                priority_score INT DEFAULT 50,
                is_active BOOLEAN DEFAULT TRUE,
                usage_count INT DEFAULT 0,
                effectiveness_score DECIMAL(3,2) DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_tip_type (tip_type),
                INDEX idx_context_trigger (context_trigger),
                INDEX idx_difficulty (difficulty_level),
                INDEX idx_priority (priority_score),
                INDEX idx_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "motivational_tips", {
            "tip_text": "TEXT",
            "tip_type": "ENUM('general','consistency','streak_building','habit_formation','goal_setting','time_management','motivation','overcoming_setbacks') NOT NULL DEFAULT 'general'",
            "difficulty_level": "ENUM('beginner','intermediate','advanced') DEFAULT 'beginner'",
            "context_trigger": "ENUM('low_consistency','new_streak','broken_streak','milestone','plateau','high_performance','weekly_review') DEFAULT 'low_consistency'",
            "is_actionable": "BOOLEAN DEFAULT TRUE",
            "priority_score": "INT DEFAULT 50",
            "usage_count": "INT DEFAULT 0",
            "effectiveness_score": "DECIMAL(3,2) DEFAULT 0.0"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_motivational_preferences (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                preferred_quote_categories JSON,
                preferred_tip_types JSON,
                preferred_mood_tags JSON,
                delivery_frequency ENUM('daily', 'every_other_day', 'weekly', 'milestones_only') DEFAULT 'daily',
                preferred_time TIME DEFAULT '09:00:00',
                enable_tips BOOLEAN DEFAULT TRUE,
                enable_quotes BOOLEAN DEFAULT TRUE,
                enable_contextual BOOLEAN DEFAULT TRUE,
                last_tip_date DATE,
                last_quote_date DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_email (user_email),
                INDEX idx_user_email (user_email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "user_motivational_preferences", {
            "preferred_quote_categories": "JSON NULL",
            "preferred_tip_types": "JSON NULL",
            "preferred_mood_tags": "JSON NULL",
            "delivery_frequency": "ENUM('daily','every_other_day','weekly','milestones_only') DEFAULT 'daily'",
            "preferred_time": "TIME DEFAULT '09:00:00'",
            "enable_tips": "BOOLEAN DEFAULT TRUE",
            "enable_quotes": "BOOLEAN DEFAULT TRUE",
            "enable_contextual": "BOOLEAN DEFAULT TRUE",
            "last_tip_date": "DATE NULL",
            "last_quote_date": "DATE NULL"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_motivational_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                content_type ENUM('quote', 'tip') NOT NULL,
                content_id INT NOT NULL,
                context_trigger VARCHAR(255),
                user_reaction ENUM('liked', 'neutral', 'disliked') DEFAULT 'neutral',
                viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                was_helpful BOOLEAN DEFAULT NULL,
                INDEX idx_user_history (user_email),
                INDEX idx_content_type (content_type),
                INDEX idx_context_trigger (context_trigger),
                INDEX idx_viewed_at (viewed_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        ensure_columns_exist(cursor, "user_motivational_history", {
            "context_trigger": "VARCHAR(255) NULL",
            "user_reaction": "ENUM('liked','neutral','disliked') DEFAULT 'neutral'",
            "viewed_at": "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
            "was_helpful": "BOOLEAN DEFAULT NULL"
        })
        
        # Snooze system table (aligned with snooze_system module)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS snooze_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                reminder_id INT,
                notification_id INT,
                snooze_until TIMESTAMP NOT NULL,
                snooze_duration_minutes INT NOT NULL,
                original_time TIME,
                original_days VARCHAR(20),
                reminder_type ENUM('habit_reminder', 'notification') NOT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP GENERATED ALWAYS AS (DATE_ADD(created_at, INTERVAL snooze_duration_minutes MINUTE)) STORED,
                INDEX idx_user_email (user_email),
                INDEX idx_reminder_id (reminder_id),
                INDEX idx_notification_id (notification_id),
                INDEX idx_snooze_until (snooze_until),
                INDEX idx_expires_at (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Password reset table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS password_resets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                reset_token VARCHAR(255) UNIQUE NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                is_used BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_token (reset_token),
                INDEX idx_email (user_email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # User profiles table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_profiles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) UNIQUE NOT NULL,
                full_name VARCHAR(255),
                address TEXT,
                bio TEXT,
                picture LONGBLOB,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_user_profiles_user
                    FOREIGN KEY (user_email) REFERENCES users(email)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Habit completion status table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_completion (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                completion_date DATE NOT NULL,
                status VARCHAR(50) DEFAULT 'completed',
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_habit_date (user_email, habit_id, completion_date),
                CONSTRAINT fk_completion_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Habit consistency analyzer tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS habit_consistency (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                analysis_date DATE NOT NULL,
                consistency_score DECIMAL(5,2),
                best_day VARCHAR(20),
                worst_day VARCHAR(20),
                average_completion DECIMAL(5,2),
                streak_length INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_consistency_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS skipped_day_patterns (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                day_of_week VARCHAR(20) NOT NULL,
                skip_count INT DEFAULT 0,
                total_occurrences INT DEFAULT 0,
                skip_percentage DECIMAL(5,2),
                last_analyzed DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                CONSTRAINT fk_pattern_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS consistency_recommendations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                habit_id INT NOT NULL,
                recommendation_type VARCHAR(100) NOT NULL,
                recommendation_text TEXT NOT NULL,
                priority VARCHAR(20) DEFAULT 'medium',
                is_implemented BOOLEAN DEFAULT FALSE,
                implemented_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_recommendation_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        conn.commit()
        print("All tables created successfully!")
        
        # Insert default data
        insert_default_data(cursor, conn)
        
    except Exception as e:
        conn.rollback()
        print(f"Error creating tables: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

def insert_default_data(cursor, conn):
    """Insert default data for the application"""
    try:
        # Insert default motivational quotes
        cursor.execute("""
            INSERT IGNORE INTO motivational_quotes (quote_text, author, category, mood_tag, length_tag) VALUES
            ('The secret of getting ahead is getting started.', 'Mark Twain', 'motivation', 'energetic', 'short'),
            ('Success is the sum of small efforts repeated day in and day out.', 'Robert Collier', 'consistency', 'encouraging', 'medium'),
            ('Don''t watch the clock; do what it does. Keep going.', 'Sam Levenson', 'persistence', 'determined', 'short'),
            ('The future depends on what you do today.', 'Mahatma Gandhi', 'achievement', 'thoughtful', 'short'),
            ('Fall seven times, stand up eight.', 'Japanese Proverb', 'setback', 'determined', 'short')
        """)
        
        # Insert default motivational tips
        cursor.execute("""
            INSERT IGNORE INTO motivational_tips (tip_text, tip_type, difficulty_level, context_trigger, is_actionable, priority_score) VALUES
            ('Start with just 5 minutes - anyone can do that!', 'habit_formation', 'beginner', 'low_consistency', TRUE, 80),
            ('Track your progress visually to stay motivated.', 'consistency', 'beginner', 'weekly_review', TRUE, 85),
            ('Set up your environment to make good habits easier.', 'habit_formation', 'beginner', 'plateau', TRUE, 70),
            ('Celebrate small wins to build momentum.', 'motivation', 'beginner', 'milestone', TRUE, 85),
            ('Focus on consistency rather than perfection.', 'overcoming_setbacks', 'intermediate', 'broken_streak', TRUE, 90)
        """)
        
        # Insert default habit categories
        cursor.execute("""
            INSERT IGNORE INTO habit_category (name, description, color) VALUES
            ('Health', 'Physical and mental health habits', '#28a745'),
            ('Fitness', 'Exercise and physical activity', '#fd7e14'),
            ('Learning', 'Education and skill development', '#6f42c1'),
            ('Productivity', 'Work and personal productivity', '#20c997'),
            ('Mindfulness', 'Meditation and self-care', '#e83e8c'),
            ('Social', 'Relationships and community', '#17a2b8'),
            ('Finance', 'Money management and financial goals', '#343a40'),
            ('Creative', 'Artistic and creative pursuits', '#6610f2')
        """)
        
        conn.commit()
        print("Default data inserted successfully!")
        
    except Exception as e:
        conn.rollback()
        print(f"Error inserting default data: {e}")
        raise
