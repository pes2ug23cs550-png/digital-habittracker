import streamlit as st
from .db import get_conn


def update_habit(habit_id: int, name: str | None = None, goal: int | None = None, is_active: int | None = None) -> bool:
    if name is not None and not name.strip():
        st.warning("Habit name cannot be empty")
        return False
    sets = []
    params: list = []
    if name is not None:
        sets.append("name=%s")
        params.append(name.strip())
    if goal is not None:
        try:
            g = int(goal)
            if g < 1:
                st.warning("Goal must be at least 1")
                return False
            sets.append("goal=%s")
            params.append(g)
        except Exception:
            st.warning("Invalid goal")
            return False
    if is_active is not None:
        sets.append("is_active=%s")
        params.append(1 if bool(is_active) else 0)
    if not sets:
        return True
    params.append(habit_id)
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(f"UPDATE habits SET {', '.join(sets)} WHERE id=%s", tuple(params))
            cnx.commit()
            return cur.rowcount > 0
        except Exception:
            return False


essential_fields = ["name", "goal"]


def delete_habit(habit_id: int) -> bool:
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute("DELETE FROM habits WHERE id=%s", (habit_id,))
            cnx.commit()
            return cur.rowcount > 0
        except Exception:
            return False
