import streamlit as st
from .db import get_conn

# Supported frequency values
VALID_FREQUENCIES = [
    "daily",
    "weekly",
    "monthly",
]


def _init_table():
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habit_frequency (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL UNIQUE,
                frequency VARCHAR(16) NOT NULL DEFAULT 'daily',
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_habit_freq_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cnx.commit()


def set_frequency(habit_id: int, frequency: str) -> bool:
    _init_table()
    if frequency not in VALID_FREQUENCIES:
        return False
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            # upsert semantics
            cur.execute(
                "INSERT INTO habit_frequency (habit_id, frequency) VALUES (%s,%s)\n                 ON DUPLICATE KEY UPDATE frequency=VALUES(frequency)",
                (habit_id, frequency),
            )
            cnx.commit()
            return True
        except Exception:
            return False


def get_frequency(habit_id: int) -> str:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT frequency FROM habit_frequency WHERE habit_id=%s",
            (habit_id,),
        )
        row = cur.fetchone()
        return row[0] if row and row[0] else "daily"


def get_frequencies_for_user(user_email: str) -> dict[int, str]:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            SELECT h.id, COALESCE(f.frequency,'daily')
            FROM habits h
            LEFT JOIN habit_frequency f ON f.habit_id = h.id
            WHERE h.user_email=%s
            """,
            (user_email.lower(),),
        )
        rows = cur.fetchall() or []
        return {hid: freq or "daily" for hid, freq in rows}


def set_frequency_by_name(user_email: str, habit_name: str, frequency: str) -> bool:
    _init_table()
    if frequency not in VALID_FREQUENCIES:
        return False
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT id FROM habits WHERE user_email=%s AND name=%s",
            (user_email.lower(), habit_name.strip()),
        )
        row = cur.fetchone()
        if not row:
            return False
        habit_id = int(row[0])
        try:
            cur.execute(
                "INSERT INTO habit_frequency (habit_id, frequency) VALUES (%s,%s)\n                 ON DUPLICATE KEY UPDATE frequency=VALUES(frequency)",
                (habit_id, frequency),
            )
            cnx.commit()
            return True
        except Exception:
            return False
