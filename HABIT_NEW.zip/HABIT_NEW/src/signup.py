import streamlit as st
from .auth import create_user_email, mysql, get_session_version


def render_signup():
    st.subheader("Email sign up")
    if mysql is None:
        st.warning("Install mysql-connector-python to enable email sign up")
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    if st.button("Create account", type="primary"):
        if not email or "@" not in email:
            st.error("Enter a valid email")
            return
        if not password or len(password) < 8:
            st.error("Password must be at least 8 characters")
            return
        ok = create_user_email(email, password)
        if ok:
            st.success("Account created")
            st.session_state["user_email"] = email.lower()
            st.session_state["auth_provider"] = "email"
            try:
                st.session_state["session_version"] = get_session_version(email)
            except Exception:
                st.session_state["session_version"] = 0
