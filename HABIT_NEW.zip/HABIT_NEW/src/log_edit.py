from __future__ import annotations
from datetime import date
from typing import List, Tuple
from .db import get_conn


def _init_tables():
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habit_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL,
                log_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_habit_date (habit_id, log_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cnx.commit()


def undo_today(habit_id: int) -> bool:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "DELETE FROM habit_logs WHERE habit_id=%s AND log_date=%s",
                (habit_id, date.today()),
            )
            cnx.commit()
            return cur.rowcount > 0
        except Exception:
            return False


def add_log_on(habit_id: int, on_date: date) -> bool:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "INSERT INTO habit_logs (habit_id, log_date, completed_at) VALUES (%s,%s, CURRENT_TIMESTAMP)",
                (habit_id, on_date),
            )
            cnx.commit()
            return True
        except Exception:
            return False


def remove_log_on(habit_id: int, on_date: date) -> bool:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "DELETE FROM habit_logs WHERE habit_id=%s AND log_date=%s",
                (habit_id, on_date),
            )
            cnx.commit()
            return cur.rowcount > 0
        except Exception:
            return False


def list_recent_logs(habit_id: int, limit: int = 30) -> List[Tuple[date]]:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT log_date FROM habit_logs WHERE habit_id=%s ORDER BY log_date DESC LIMIT %s",
            (habit_id, limit),
        )
        return cur.fetchall() or []
