import streamlit as st
import mysql.connector
from datetime import datetime, time, timedelta
from typing import List, Dict, Optional
import json

from src.db import get_db_connection
from src.snooze_system import get_snooze_button, is_item_snoozed
from src.notification_settings import apply_notification_settings

REMINDER_TABLE = "habit_reminders"

def ensure_habit_reminders_table():
    """Ensure the habit reminders table exists with required columns."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {REMINDER_TABLE} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL,
                user_email VARCHAR(255) NOT NULL,
                reminder_time TIME NOT NULL,
                days_of_week JSON,
                is_enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                CONSTRAINT fk_reminder_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE,
                INDEX idx_user_email (user_email),
                INDEX idx_is_enabled (is_enabled)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        
        # Ensure columns exist for legacy tables
        cursor.execute("""
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = 'user_email'
        """, (REMINDER_TABLE,))
        if cursor.fetchone()[0] == 0:
            cursor.execute(f"ALTER TABLE {REMINDER_TABLE} ADD COLUMN user_email VARCHAR(255) NULL")
            cursor.execute(f"""
                UPDATE {REMINDER_TABLE} hr
                JOIN users u ON hr.user_id = u.id
                SET hr.user_email = u.email
                WHERE hr.user_email IS NULL
            """)
            cursor.execute(f"ALTER TABLE {REMINDER_TABLE} MODIFY COLUMN user_email VARCHAR(255) NOT NULL")
        
        cursor.execute("""
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = 'days_of_week'
        """, (REMINDER_TABLE,))
        if cursor.fetchone()[0] == 0:
            cursor.execute(f"ALTER TABLE {REMINDER_TABLE} ADD COLUMN days_of_week JSON NULL")
            cursor.execute(f"UPDATE {REMINDER_TABLE} SET days_of_week = JSON_ARRAY(0,1,2,3,4,5,6) WHERE days_of_week IS NULL")
        
        cursor.execute("""
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = 'is_enabled'
        """, (REMINDER_TABLE,))
        if cursor.fetchone()[0] == 0:
            cursor.execute(f"ALTER TABLE {REMINDER_TABLE} ADD COLUMN is_enabled BOOLEAN DEFAULT TRUE")
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def create_notification(user_email: str, habit_id: int, notification_time: str, notification_days: List[int]) -> bool:
    """Create a new notification for a habit"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        days_json = json.dumps(notification_days)
        cursor.execute(f"""
            INSERT INTO {REMINDER_TABLE} (user_email, habit_id, reminder_time, days_of_week)
            VALUES (%s, %s, %s, %s)
        """, (user_email.lower(), habit_id, notification_time, days_json))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error creating notification: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_notifications_for_user(user_email: str) -> List[Dict]:
    """Get all notifications for a user"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute(f"""
            SELECT n.*, h.name as habit_name 
            FROM {REMINDER_TABLE} n
            JOIN habits h ON n.habit_id = h.id
            WHERE n.user_email = %s AND n.is_enabled = TRUE
            ORDER BY n.reminder_time
        """, (user_email.lower(),))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def update_notification(notification_id: int, notification_time: str, notification_days: List[int]) -> bool:
    """Update an existing notification"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        days_json = json.dumps(notification_days)
        cursor.execute(f"""
            UPDATE {REMINDER_TABLE} 
            SET reminder_time = %s, days_of_week = %s, updated_at = CURRENT_TIMESTAMP
            WHERE id = %s
        """, (notification_time, days_json, notification_id))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error updating notification: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def delete_notification(notification_id: int) -> bool:
    """Delete a notification (set as inactive)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(f"""
            UPDATE {REMINDER_TABLE} SET is_enabled = FALSE WHERE id = %s
        """, (notification_id,))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error deleting notification: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_pending_notifications(user_email: str) -> List[Dict]:
    """Get notifications that should trigger now for a user"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        current_time = datetime.now().time()
        current_day = datetime.now().weekday()  # 0=Monday, 6=Sunday
        
        cursor.execute(f"""
            SELECT n.*, h.name as habit_name 
            FROM {REMINDER_TABLE} n
            JOIN habits h ON n.habit_id = h.id
            WHERE n.user_email = %s 
            AND n.is_enabled = TRUE 
            AND n.reminder_time <= %s
            AND JSON_CONTAINS(n.days_of_week, %s)
        """, (user_email.lower(), current_time, json.dumps(current_day)))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def render_notification_form(user_email: str, habits: List[Dict], notification: Optional[Dict] = None):
    """Render notification creation/edit form"""
    st.subheader("⏰ Set Notification" if not notification else "✏️ Edit Notification")
    
    # Habit selection
    habit_options = {h['id']: h['name'] for h in habits}
    selected_habit_id = st.selectbox(
        "Select Habit",
        options=list(habit_options.keys()),
        format_func=lambda x: habit_options[x],
        index=0 if not notification else list(habit_options.keys()).index(notification['habit_id'])
    )
    
    # Time selection
    current_time = datetime.now().strftime("%H:%M")
    default_time = notification['reminder_time'].strftime("%H:%M") if notification else current_time
    notification_time = st.time_input("Notification Time", value=default_time)
    
    # Day selection
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    default_days = json.loads(notification['days_of_week']) if notification else list(range(7))
    
    selected_days = st.multiselect(
        "Select Days",
        options=days,
        default=[days[i] for i in default_days],
        help="Choose which days to receive notifications"
    )
    
    # Convert selected days back to indices
    selected_day_indices = [days.index(day) for day in selected_days]
    
    # Submit button
    if st.form_submit_button("Save Notification" if not notification else "Update Notification"):
        if not selected_days:
            st.error("Please select at least one day")
            return False
        
        if notification:
            success = update_notification(notification['id'], notification_time.strftime("%H:%M"), selected_day_indices)
        else:
            success = create_notification(user_email, selected_habit_id, notification_time.strftime("%H:%M"), selected_day_indices)
        
        if success:
            st.success("Notification saved successfully!")
            st.rerun()
        return success
    
    return False

def render_notifications_list(user_email: str):
    """Render list of user's notifications"""
    notifications = get_notifications_for_user(user_email)
    
    if not notifications:
        st.info("No notifications set. Create one to remind yourself!")
        return
    
    st.subheader("🔔 Your Notifications")
    
    for notification in notifications:
        with st.expander(f"⏰ {notification['habit_name']} - {notification['reminder_time']}"):
            days = json.loads(notification['days_of_week'])
            day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            selected_days = [day_names[i] for i in days]
            
            st.write(f"**Days:** {', '.join(selected_days)}")
            st.write(f"**Created:** {notification['created_at'].strftime('%Y-%m-%d %H:%M')}")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("✏️ Edit", key=f"edit_{notification['id']}"):
                    st.session_state[f"edit_notification_{notification['id']}"] = True
            with col2:
                if st.button("🗑️ Delete", key=f"delete_{notification['id']}"):
                    if delete_notification(notification['id']):
                        st.success("Notification deleted!")
                        st.rerun()

def check_and_show_notifications(user_email: str):
    """Check for pending notifications and show them"""
    ensure_habit_reminders_table()
    
    pending = get_pending_notifications(user_email)
    
    if pending:
        for notification in pending:
            # Check if notification is snoozed
            if is_item_snoozed(user_email, None, notification['id'], 'notification'):
                continue  # Skip snoozed notifications
            
            # Apply notification settings
            notification_config = apply_notification_settings(user_email, 'habit_reminder', notification['habit_id'])
            if not notification_config:
                continue  # Notification disabled by settings
            
            # Format message based on settings
            message = f"Time to {notification['habit_name']}!"
            if notification_config['message_template']:
                try:
                    message = notification_config['message_template'].format(
                        habit_name=notification['habit_name'],
                        time=notification['reminder_time'].strftime('%H:%M'),
                        goal="your daily goal"
                    )
                except:
                    pass  # Fallback to default message
            
            # Show notification with appropriate style
            if notification_config['style'] == 'detailed':
                st.success(f"🔔 **{notification['habit_name']} Reminder**")
                st.info(message)
                st.write(f"⏰ Scheduled for: {notification['reminder_time'].strftime('%H:%M')}")
            elif notification_config['style'] == 'minimal':
                st.info(f"⏰ {notification['habit_name']}")
            else:  # simple
                st.success(f"🔔 **Reminder:** {message}")
            
            # Add quick action buttons
            col1, col2, col3 = st.columns(3)
            with col1:
                if st.button(f"✅ Mark {notification['habit_name']} Complete", key=f"quick_complete_{notification['id']}"):
                    # This would integrate with the existing habit completion system
                    st.success(f"Great job completing {notification['habit_name']}!")
            with col2:
                get_snooze_button(
                    user_email, None, notification['id'], 'notification',
                    notification['habit_name'], notification['reminder_time']
                )
            with col3:
                if st.button(f"❌ Dismiss {notification['habit_name']}", key=f"dismiss_{notification['id']}"):
                    st.info(f"Dismissed reminder for {notification['habit_name']}")

def get_notification_settings_page(user_email: str):
    """Main notification settings page"""
    st.title("🔔 Notification Settings")
    
    # Ensure reminders table exists
    ensure_habit_reminders_table()
    
    # Get user habits for selection
    from src.habits import list_habits
    habits_list = list_habits(user_email)
    
    # Convert to dict format expected by the form
    habits = []
    if habits_list:
        for habit in habits_list:
            habits.append({'id': habit[0], 'name': habit[1]})
    
    if not habits:
        st.warning("You need to create habits first before setting notifications!")
        return
    
    # Tab layout
    tab1, tab2 = st.tabs(["📋 Notifications", "➕ Add New"])
    
    with tab1:
        render_notifications_list(user_email)
    
    with tab2:
        with st.form("notification_form"):
            render_notification_form(user_email, habits)
