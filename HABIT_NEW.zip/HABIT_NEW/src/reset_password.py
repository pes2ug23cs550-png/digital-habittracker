import os
from datetime import datetime, timedelta
import secrets
import string
import smtplib
from email.message import EmailMessage
import streamlit as st
from .db import get_conn


def _init_reset_table():
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS password_resets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) NOT NULL,
                code VARCHAR(12) NOT NULL,
                expires_at DATETIME NOT NULL,
                used TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_email (email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cnx.commit()


def _user_exists(email: str) -> bool:
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute("SELECT 1 FROM users WHERE email=%s AND provider='email'", (email.lower(),))
        return cur.fetchone() is not None


def _generate_code(length: int = 6) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def _smtp_cfg():
    s = st.secrets
    host = s.get("SMTP_HOST")
    port = s.get("SMTP_PORT")
    user = s.get("SMTP_USER")
    pwd = s.get("SMTP_PASS")
    from_addr = s.get("SMTP_FROM") or user
    return host, port, user, pwd, from_addr


def _send_code(email: str, code: str) -> tuple[bool, str | None]:
    host, port, user, pwd, from_addr = _smtp_cfg()
    if not host or not port or not user or not pwd or not from_addr:
        return False, "SMTP settings missing (HOST/PORT/USER/PASS/FROM)."
    try:
        msg = EmailMessage()
        msg["Subject"] = "Your Habit Tracker password reset code"
        msg["From"] = from_addr
        msg["To"] = email
        msg.set_content(f"Your reset code is: {code}\nIt expires in 15 minutes.")
        with smtplib.SMTP(host, int(port)) as server:
            server.starttls()
            server.login(user, pwd)
            server.send_message(msg)
        return True, None
    except Exception as e:
        return False, str(e)

def request_reset(email: str) -> bool:
    _init_reset_table()
    if not _user_exists(email):
        return False
    code = _generate_code(6)
    expires = datetime.utcnow() + timedelta(minutes=15)
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "INSERT INTO password_resets (email, code, expires_at) VALUES (%s,%s,%s)",
            (email.lower(), code, expires.strftime("%Y-%m-%d %H:%M:%S")),
        )
        cnx.commit()
    sent, _err = _send_code(email, code)
    return bool(sent)


def confirm_reset(email: str, code: str, new_password: str) -> bool:
    _init_reset_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            SELECT id, expires_at, used FROM password_resets
            WHERE email=%s AND code=%s
            ORDER BY id DESC LIMIT 1
            """,
            (email.lower(), code),
        )
        row = cur.fetchone()
        if not row:
            return False
        reset_id, expires_at, used = row
        # MySQL returns datetime for DATETIME type, else string if configured; handle both
        if isinstance(expires_at, str):
            try:
                expires_at = datetime.strptime(expires_at, "%Y-%m-%d %H:%M:%S")
            except Exception:
                return False
        if used:
            return False
        if datetime.utcnow() > expires_at:
            return False
        # Update the user's password (plain text per project choice)
        cur.execute(
            "UPDATE users SET password_hash=%s, password_salt='' WHERE email=%s AND provider='email'",
            (new_password, email.lower()),
        )
        # Mark reset token used
        cur.execute("UPDATE password_resets SET used=1 WHERE id=%s", (reset_id,))
        cnx.commit()
        return True


def render_reset_password():
    st.subheader("Reset password")
    # Stage 1: ask for email and send code
    if "reset_email" not in st.session_state:
        email = st.text_input("Email")
        if st.button("Send reset code"):
            if not email or "@" not in email:
                st.error("Enter a valid email")
            else:
                sent = request_reset(email)
                if not sent:
                    st.error("Failed to send. Check SMTP settings or email address.")
                else:
                    st.success("Reset code sent to your email")
                    st.session_state["reset_email"] = email.lower()
                    st.rerun()
        if st.button("Back to Sign in"):
            st.session_state["route"] = "auth"
            st.rerun()
        return

    # Stage 2: confirm reset with code for the same email
    st.info(f"Reset code sent to: {st.session_state['reset_email']}")
    code = st.text_input("Reset code")
    new_pw = st.text_input("New password", type="password")
    if st.button("Reset password"):
        if not code or not new_pw:
            st.error("Fill all fields")
        elif len(new_pw) < 8:
            st.error("Password must be at least 8 characters")
        else:
            ok = confirm_reset(st.session_state["reset_email"], code, new_pw)
            if ok:
                st.success("Password updated. Redirecting to Sign in...")
                st.session_state.pop("reset_email", None)
                st.session_state["route"] = "auth"
                st.rerun()
            else:
                st.error("Invalid or expired code")
    if st.button("Back to Sign in"):
        st.session_state.pop("reset_email", None)
        st.session_state["route"] = "auth"
        st.rerun()
