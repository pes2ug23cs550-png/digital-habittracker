import streamlit as st
from .db import get_conn
from datetime import datetime


def _init_table():
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habit_completion (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL UNIQUE,
                completed TINYINT(1) NOT NULL DEFAULT 0,
                completed_at TIMESTAMP NULL DEFAULT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_habit_completion_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cnx.commit()


def complete_habit(habit_id: int) -> bool:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "INSERT INTO habit_completion (habit_id, completed, completed_at) VALUES (%s,1,%s)\n                 ON DUPLICATE KEY UPDATE completed=VALUES(completed), completed_at=VALUES(completed_at)",
                (habit_id, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")),
            )
            # Optionally also mark as inactive in habits table to hide from active workflows
            try:
                cur.execute("UPDATE habits SET is_active=0 WHERE id=%s", (habit_id,))
            except Exception:
                pass
            cnx.commit()
            return True
        except Exception:
            return False


def reopen_habit(habit_id: int) -> bool:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "INSERT INTO habit_completion (habit_id, completed, completed_at) VALUES (%s,0,NULL)\n                 ON DUPLICATE KEY UPDATE completed=VALUES(completed), completed_at=VALUES(completed_at)",
                (habit_id,),
            )
            try:
                cur.execute("UPDATE habits SET is_active=1 WHERE id=%s", (habit_id,))
            except Exception:
                pass
            cnx.commit()
            return True
        except Exception:
            return False


def is_completed(habit_id: int) -> bool:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute("SELECT completed FROM habit_completion WHERE habit_id=%s", (habit_id,))
        row = cur.fetchone()
        return bool(row[0]) if row else False


def get_completion_map_for_user(user_email: str) -> dict[int, bool]:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            SELECT h.id, COALESCE(c.completed, 0)
            FROM habits h
            LEFT JOIN habit_completion c ON c.habit_id = h.id
            WHERE h.user_email=%s
            """,
            (user_email.lower(),),
        )
        rows = cur.fetchall() or []
        return {int(hid): bool(comp) for hid, comp in rows}
