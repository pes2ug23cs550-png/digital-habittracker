import streamlit as st
import mysql.connector
import pandas as pd
from datetime import datetime, timedelta, date
from typing import List, Dict, Optional, Tuple
import json

from src.db import get_db_connection


def ensure_columns_exist(cursor, table_name: str, columns: Dict[str, str]):
    """Ensure the specified columns exist on a table; add them if missing."""
    for column_name, column_definition in columns.items():
        cursor.execute("""
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = %s
        """, (table_name, column_name))
        exists = cursor.fetchone()[0]
        if not exists:
            cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_definition}")

def create_badge_system_tables():
    """Create badge system tables if they don't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS badges (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                description TEXT NOT NULL,
                icon VARCHAR(50) NOT NULL,
                category ENUM('consistency', 'streaks', 'milestones', 'improvement', 'special', 'seasonal', 'mastery') NOT NULL,
                tier ENUM('bronze', 'silver', 'gold', 'platinum', 'diamond') DEFAULT 'bronze',
                criteria JSON,
                points_value INT DEFAULT 10,
                is_active BOOLEAN DEFAULT TRUE,
                is_secret BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_category (category),
                INDEX idx_tier (tier),
                INDEX idx_active (is_active),
                INDEX idx_points (points_value)
            )
        """)
        ensure_columns_exist(cursor, "badges", {
            "icon": "VARCHAR(50) NOT NULL DEFAULT '🎯'",
            "category": "ENUM('consistency','streaks','milestones','improvement','special','seasonal','mastery') NOT NULL DEFAULT 'consistency'",
            "tier": "ENUM('bronze','silver','gold','platinum','diamond') NOT NULL DEFAULT 'bronze'",
            "criteria": "JSON NULL",
            "points_value": "INT DEFAULT 10",
            "is_secret": "BOOLEAN DEFAULT FALSE"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_badges (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                badge_id INT NOT NULL,
                earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                progress_data JSON,
                is_displayed BOOLEAN DEFAULT TRUE,
                notes TEXT,
                FOREIGN KEY (badge_id) REFERENCES badges(id),
                UNIQUE KEY unique_user_badge (user_email, badge_id),
                INDEX idx_user_email (user_email),
                INDEX idx_earned_at (earned_at)
            )
        """)
        ensure_columns_exist(cursor, "user_badges", {
            "progress_data": "JSON NULL",
            "is_displayed": "BOOLEAN DEFAULT TRUE",
            "notes": "TEXT NULL"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS badge_progress (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                badge_id INT NOT NULL,
                current_progress INT DEFAULT 0,
                target_progress INT NOT NULL,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (badge_id) REFERENCES badges(id),
                UNIQUE KEY unique_user_badge_progress (user_email, badge_id),
                INDEX idx_user_email (user_email),
                INDEX idx_progress (current_progress)
            )
        """)
        ensure_columns_exist(cursor, "badge_progress", {
            "current_progress": "INT DEFAULT 0",
            "target_progress": "INT NOT NULL DEFAULT 1",
            "last_updated": "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_points (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                total_points INT DEFAULT 0,
                level INT DEFAULT 1,
                points_to_next_level INT DEFAULT 100,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_points (user_email),
                INDEX idx_user_email (user_email),
                INDEX idx_level (level)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS badge_notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                badge_id INT NOT NULL,
                notification_type ENUM('earned', 'progress', 'milestone') NOT NULL,
                message TEXT NOT NULL,
                is_read BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (badge_id) REFERENCES badges(id),
                INDEX idx_user_email (user_email),
                INDEX idx_is_read (is_read),
                INDEX idx_created_at (created_at)
            )
        """)
        ensure_columns_exist(cursor, "badge_notifications", {
            "notification_type": "ENUM('earned','progress','milestone') NOT NULL DEFAULT 'earned'",
            "is_read": "BOOLEAN DEFAULT FALSE"
        })

        # Backfill criteria for legacy badges seeded before JSON column existed
        cursor.execute("""
            UPDATE badges
            SET criteria = JSON_OBJECT('type', requirement_type, 'target', requirement_value)
            WHERE (criteria IS NULL OR JSON_TYPE(criteria) IS NULL)
              AND requirement_type IS NOT NULL
              AND requirement_value IS NOT NULL
        """)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def populate_default_badges():
    """Populate database with default badges"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if badges already exist
        cursor.execute("SELECT COUNT(*) FROM badges")
        badge_count = cursor.fetchone()[0]
        
        if badge_count > 0:
            return  # Badges already populated
        
        # Default badges: (name, description, icon, category, tier, criteria_dict, points_value, is_secret)
        default_badges = [
            # Consistency Badges
            ("First Step", "Complete your first habit log", "🎯", "consistency", "bronze", {"type": "total_logs", "target": 1}, 10, False),
            ("Getting Started", "Complete 10 habit logs", "🌟", "consistency", "bronze", {"type": "total_logs", "target": 10}, 25, False),
            ("Habit Builder", "Complete 50 habit logs", "🏗️", "consistency", "silver", {"type": "total_logs", "target": 50}, 50, False),
            ("Consistent Performer", "Complete 100 habit logs", "💪", "consistency", "silver", {"type": "total_logs", "target": 100}, 75, False),
            ("Habit Master", "Complete 500 habit logs", "👑", "consistency", "gold", {"type": "total_logs", "target": 500}, 150, False),
            ("Legendary", "Complete 1000 habit logs", "🔥", "consistency", "platinum", {"type": "total_logs", "target": 1000}, 300, False),
            
            # Streak Badges
            ("Day One", "Maintain a 1-day streak", "📅", "streaks", "bronze", {"type": "longest_streak", "target": 1}, 15, False),
            ("Week Warrior", "Maintain a 7-day streak", "🗓️", "streaks", "bronze", {"type": "longest_streak", "target": 7}, 35, False),
            ("Two Week Triumph", "Maintain a 14-day streak", "🏆", "streaks", "silver", {"type": "longest_streak", "target": 14}, 60, False),
            ("Month Master", "Maintain a 30-day streak", "🌙", "streaks", "silver", {"type": "longest_streak", "target": 30}, 100, False),
            ("Quarter Champion", "Maintain a 90-day streak", "🌈", "streaks", "gold", {"type": "longest_streak", "target": 90}, 200, False),
            ("Half-Year Hero", "Maintain a 180-day streak", "⭐", "streaks", "platinum", {"type": "longest_streak", "target": 180}, 350, False),
            ("Year Legend", "Maintain a 365-day streak", "🎊", "streaks", "diamond", {"type": "longest_streak", "target": 365}, 500, False),
            
            # Milestone Badges
            ("Perfect Week", "Complete all habits for 7 consecutive days", "✨", "milestones", "bronze", {"type": "perfect_week", "target": 1}, 40, False),
            ("Perfect Month", "Complete all habits for 30 consecutive days", "🌟", "milestones", "silver", {"type": "perfect_month", "target": 1}, 80, False),
            ("Habit Collector", "Create 5 different habits", "📚", "milestones", "bronze", {"type": "habit_count", "target": 5}, 30, False),
            ("Habit Enthusiast", "Create 10 different habits", "🎨", "milestones", "silver", {"type": "habit_count", "target": 10}, 60, False),
            ("Habit Expert", "Create 20 different habits", "🎭", "milestones", "gold", {"type": "habit_count", "target": 20}, 120, False),
            
            # Improvement Badges
            ("Comeback Kid", "Break a personal best streak after a setback", "🔄", "improvement", "bronze", {"type": "comeback", "target": 1}, 45, False),
            ("Consistency Climber", "Improve weekly consistency by 20%", "📈", "improvement", "silver", {"type": "consistency_improvement", "target": 20}, 55, False),
            ("Goal Crusher", "Exceed daily goal by 50% for 7 consecutive days", "💥", "improvement", "gold", {"type": "goal_exceed", "target": 7}, 85, False),
            
            # Special Badges
            ("Early Bird", "Complete habits before 8 AM for 7 days", "🌅", "special", "bronze", {"type": "early_completion", "target": 7}, 40, False),
            ("Night Owl", "Complete habits after 10 PM for 7 days", "🌙", "special", "bronze", {"type": "late_completion", "target": 7}, 40, False),
            ("Weekend Warrior", "Complete all habits on weekends for 4 weeks", "🎉", "special", "silver", {"type": "weekend_warrior", "target": 4}, 70, False),
            ("Perfectionist", "Achieve 100% completion rate for a month", "💯", "special", "gold", {"type": "perfect_month", "target": 1}, 100, False),
            
            # Seasonal Badges
            ("Spring Starter", "Start 3 new habits in spring", "🌸", "seasonal", "bronze", {"type": "seasonal_habits", "season": "spring", "target": 3}, 35, False),
            ("Summer Achiever", "Maintain 30-day streak in summer", "☀️", "seasonal", "silver", {"type": "seasonal_streak", "season": "summer", "target": 30}, 65, False),
            ("Autumn Achiever", "Complete 100 logs in autumn", "🍂", "seasonal", "silver", {"type": "seasonal_logs", "season": "autumn", "target": 100}, 75, False),
            ("Winter Warrior", "Maintain consistency through winter", "❄️", "seasonal", "gold", {"type": "winter_consistency", "target": 80}, 90, False),
            
            # Mastery Badges
            ("Consistency Master", "Maintain 80%+ consistency for 6 months", "🏅", "mastery", "gold", {"type": "long_term_consistency", "target": 180}, 150, False),
            ("Multi-Habit Master", "Maintain 5+ habits with 90% consistency", "🎯", "mastery", "platinum", {"type": "multi_habit_mastery", "target": 5}, 250, False),
            ("Lifetime Achiever", "Maintain habits for 2+ years", "🏆", "mastery", "diamond", {"type": "lifetime_achievement", "target": 730}, 500, False),
            
            # Secret Badges
            ("Midnight Motivator", "Complete a habit at exactly midnight", "🕛", "special", "bronze", {"type": "midnight_completion", "target": 1}, 50, True),
            ("Speed Demon", "Complete all daily habits within 1 hour", "⚡", "special", "silver", {"type": "speed_completion", "target": 1}, 60, True),
            ("Habit Ninja", "Complete habits for 30 days without missing", "🥷", "special", "gold", {"type": "ninja_streak", "target": 30}, 100, True)
        ]

        # Convert criteria dicts to JSON strings for insertion
        prepared_badges = [
            (name, desc, icon, category, tier, json.dumps(criteria), points, is_secret)
            for (name, desc, icon, category, tier, criteria, points, is_secret) in default_badges
        ]
        
        cursor.executemany("""
            INSERT INTO badges 
            (name, description, icon, category, tier, criteria, points_value, is_secret)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, prepared_badges)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def get_user_points(user_email: str) -> Dict:
    """Get user's current points and level"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT * FROM user_points WHERE user_email = %s
        """, (user_email.lower(),))
        
        result = cursor.fetchone()
        
        if not result:
            # Initialize user points
            cursor.execute("""
                INSERT INTO user_points (user_email, total_points, level, points_to_next_level)
                VALUES (%s, 0, 1, 100)
            """, (user_email.lower(),))
            
            conn.commit()
            return {'total_points': 0, 'level': 1, 'points_to_next_level': 100}
        
        return result
    finally:
        cursor.close()
        conn.close()

def update_user_points(user_email: str, points_to_add: int) -> Dict:
    """Update user points and check for level up"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT * FROM user_points WHERE user_email = %s
        """, (user_email.lower(),))
        
        user_points = cursor.fetchone()
        
        if not user_points:
            user_points = {'total_points': 0, 'level': 1, 'points_to_next_level': 100}
            cursor.execute("""
                INSERT INTO user_points (user_email, total_points, level, points_to_next_level)
                VALUES (%s, 0, 1, 100)
            """, (user_email.lower(),))
        
        # Add points
        new_total = user_points['total_points'] + points_to_add
        new_level = user_points['level']
        points_to_next = user_points['points_to_next_level']
        
        # Check for level up (100 points per level)
        while new_total >= points_to_next:
            new_level += 1
            points_to_next = new_level * 100
        
        cursor.execute("""
            UPDATE user_points 
            SET total_points = %s, level = %s, points_to_next_level = %s
            WHERE user_email = %s
        """, (new_total, new_level, points_to_next, user_email.lower(),))
        
        conn.commit()
        
        return {
            'total_points': new_total,
            'level': new_level,
            'points_to_next_level': points_to_next,
            'leveled_up': new_level > user_points['level']
        }
    finally:
        cursor.close()
        conn.close()

def check_badge_criteria(user_email: str, badge_criteria: Dict) -> Tuple[bool, int]:
    """Check if user meets badge criteria and return current progress"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        criteria_type = badge_criteria['type']
        target = badge_criteria['target']
        
        if criteria_type == 'total_logs':
            cursor.execute("""
                SELECT COUNT(*) as count FROM habit_logs l
                JOIN habits h ON l.habit_id = h.id
                WHERE h.user_email = %s
            """, (user_email.lower(),))
            result = cursor.fetchone()
            current = result['count']
        
        elif criteria_type == 'longest_streak':
            cursor.execute("""
                SELECT MAX(longest_streak) as max_streak FROM habit_streaks
                WHERE user_email = %s
            """, (user_email.lower(),))
            result = cursor.fetchone()
            current = result['max_streak'] or 0
        
        elif criteria_type == 'perfect_week':
            # Check for perfect week (all habits completed for 7 days)
            cursor.execute("""
                SELECT COUNT(DISTINCT DATE(l.log_date)) as perfect_days
                FROM habits h
                JOIN habit_logs l ON h.id = l.habit_id
                WHERE h.user_email = %s 
                AND l.amount >= h.goal
                AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                GROUP BY DATE(l.log_date)
                HAVING COUNT(DISTINCT h.id) = (SELECT COUNT(*) FROM habits WHERE user_email = %s AND is_active = TRUE)
            """, (user_email.lower(), user_email.lower()))
            result = cursor.fetchall()
            current = len(result)
        
        elif criteria_type == 'perfect_month':
            # Similar logic for perfect month
            cursor.execute("""
                SELECT COUNT(DISTINCT DATE(l.log_date)) as perfect_days
                FROM habits h
                JOIN habit_logs l ON h.id = l.habit_id
                WHERE h.user_email = %s 
                AND l.amount >= h.goal
                AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY DATE(l.log_date)
                HAVING COUNT(DISTINCT h.id) = (SELECT COUNT(*) FROM habits WHERE user_email = %s AND is_active = TRUE)
            """, (user_email.lower(), user_email.lower()))
            result = cursor.fetchall()
            current = 30 if len(result) >= 30 else len(result)
        
        elif criteria_type == 'habit_count':
            cursor.execute("""
                SELECT COUNT(*) as count FROM habits WHERE user_email = %s
            """, (user_email.lower(),))
            result = cursor.fetchone()
            current = result['count']
        
        elif criteria_type == 'consistency_improvement':
            # Calculate improvement in consistency
            cursor.execute("""
                SELECT 
                    CASE 
                        WHEN COUNT(*) = 0 THEN 0
                        ELSE ROUND((SUM(CASE WHEN l.amount >= h.goal THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
                    END as consistency_rate
                FROM habits h
                LEFT JOIN habit_logs l ON h.id = l.habit_id AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                WHERE h.user_email = %s
            """, (user_email.lower(),))
            current_week = cursor.fetchone()['consistency_rate'] or 0
            
            cursor.execute("""
                SELECT 
                    CASE 
                        WHEN COUNT(*) = 0 THEN 0
                        ELSE ROUND((SUM(CASE WHEN l.amount >= h.goal THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
                    END as consistency_rate
                FROM habits h
                LEFT JOIN habit_logs l ON h.id = l.habit_id AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND l.log_date < DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                WHERE h.user_email = %s
            """, (user_email.lower(),))
            previous_week = cursor.fetchone()['consistency_rate'] or 0
            
            current = max(0, current_week - previous_week)
        
        elif criteria_type == 'goal_exceed':
            # Check consecutive days of exceeding goals
            cursor.execute("""
                SELECT COUNT(*) as consecutive_days
                FROM (
                    SELECT DATE(l.log_date) as log_date,
                           SUM(CASE WHEN l.amount >= h.goal * 1.5 THEN 1 ELSE 0 END) as exceeded_goals,
                           COUNT(*) as total_habits
                    FROM habits h
                    JOIN habit_logs l ON h.id = l.habit_id
                    WHERE h.user_email = %s AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                    GROUP BY DATE(l.log_date)
                    HAVING exceeded_goals = total_habits
                    ORDER BY log_date DESC
                ) as perfect_days
                """, (user_email.lower(),))
            result = cursor.fetchone()
            current = result['consecutive_days'] or 0
        
        elif criteria_type == 'early_completion':
            # Check for early morning completions
            cursor.execute("""
                SELECT COUNT(DISTINCT DATE(l.log_date)) as early_days
                FROM habit_logs l
                JOIN habits h ON l.habit_id = h.id
                WHERE h.user_email = %s 
                AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                AND HOUR(l.created_at) < 8
            """, (user_email.lower(),))
            result = cursor.fetchone()
            current = result['early_days'] or 0
        
        elif criteria_type == 'late_completion':
            # Check for late night completions
            cursor.execute("""
                SELECT COUNT(DISTINCT DATE(l.log_date)) as late_days
                FROM habit_logs l
                JOIN habits h ON l.habit_id = h.id
                WHERE h.user_email = %s 
                AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                AND HOUR(l.created_at) >= 22
            """, (user_email.lower(),))
            result = cursor.fetchone()
            current = result['late_days'] or 0
        
        elif criteria_type == 'weekend_warrior':
            # Check weekend completions
            cursor.execute("""
                SELECT COUNT(DISTINCT DATE(l.log_date)) as weekend_days
                FROM habit_logs l
                JOIN habits h ON l.habit_id = h.id
                WHERE h.user_email = %s 
                AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 28 DAY)
                AND DAYOFWEEK(l.log_date) IN (1, 7)  -- Saturday and Sunday
                GROUP BY DATE(l.log_date)
                HAVING COUNT(DISTINCT h.id) = (SELECT COUNT(*) FROM habits WHERE user_email = %s AND is_active = TRUE)
            """, (user_email.lower(), user_email.lower()))
            result = cursor.fetchall()
            current = len(result)
        
        elif criteria_type == 'midnight_completion':
            # Check for midnight completion (secret badge)
            cursor.execute("""
                SELECT COUNT(*) as count
                FROM habit_logs l
                JOIN habits h ON l.habit_id = h.id
                WHERE h.user_email = %s 
                AND HOUR(l.created_at) = 0 
                AND MINUTE(l.created_at) < 5
            """, (user_email.lower(),))
            result = cursor.fetchone()
            current = result['count'] or 0
        
        elif criteria_type == 'speed_completion':
            # Check for speed completion (all habits within 1 hour)
            cursor.execute("""
                SELECT COUNT(*) as speed_days
                FROM (
                    SELECT DATE(l.log_date) as log_date,
                           MIN(l.created_at) as first_completion,
                           MAX(l.created_at) as last_completion
                    FROM habits h
                    JOIN habit_logs l ON h.id = l.habit_id
                    WHERE h.user_email = %s AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                    GROUP BY DATE(l.log_date)
                    HAVING COUNT(DISTINCT h.id) = (SELECT COUNT(*) FROM habits WHERE user_email = %s AND is_active = TRUE)
                    AND TIMESTAMPDIFF(MINUTE, first_completion, last_completion) <= 60
                ) as speed_days
            """, (user_email.lower(), user_email.lower()))
            result = cursor.fetchone()
            current = result['speed_days'] or 0
        
        elif criteria_type == 'ninja_streak':
            # Check for ninja streak (no misses for 30 days)
            cursor.execute("""
                SELECT COUNT(DISTINCT DATE(l.log_date)) as ninja_days
                FROM habits h
                JOIN habit_logs l ON h.id = l.habit_id
                WHERE h.user_email = %s 
                AND l.amount >= h.goal
                AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY DATE(l.log_date)
                HAVING COUNT(DISTINCT h.id) = (SELECT COUNT(*) FROM habits WHERE user_email = %s AND is_active = TRUE)
            """, (user_email.lower(), user_email.lower()))
            result = cursor.fetchall()
            current = 30 if len(result) >= 30 else len(result)
        
        else:
            current = 0
        
        return current >= target, current
    
    finally:
        cursor.close()
        conn.close()

def check_and_award_badges(user_email: str) -> List[Dict]:
    """Check all badges and award any that the user has earned"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Get all active badges that user hasn't earned
        cursor.execute("""
            SELECT b.* FROM badges b
            LEFT JOIN user_badges ub ON b.id = ub.badge_id AND ub.user_email = %s
            WHERE b.is_active = TRUE AND ub.badge_id IS NULL
        """, (user_email.lower(),))
        
        available_badges = cursor.fetchall()
        newly_earned = []
        
        for badge in available_badges:
            criteria = json.loads(badge['criteria'])
            earned, progress = check_badge_criteria(user_email, criteria)
            
            if earned:
                # Award badge
                cursor.execute("""
                    INSERT INTO user_badges (user_email, badge_id, progress_data)
                    VALUES (%s, %s, %s)
                """, (user_email.lower(), badge['id'], json.dumps({'progress': progress, 'earned_at': datetime.now().isoformat()})))
                
                # Update user points
                points_update = update_user_points(user_email, badge['points_value'])
                
                # Create notification
                cursor.execute("""
                    INSERT INTO badge_notifications (user_email, badge_id, notification_type, message)
                    VALUES (%s, %s, 'earned', %s)
                """, (user_email.lower(), badge['id'], f"🎉 Congratulations! You earned the '{badge['name']}' badge and {badge['points_value']} points!"))
                
                newly_earned.append({
                    'badge': badge,
                    'points_update': points_update
                })
            else:
                # Update progress
                cursor.execute("""
                    INSERT INTO badge_progress (user_email, badge_id, current_progress, target_progress)
                    VALUES (%s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE 
                    current_progress = %s, last_updated = CURRENT_TIMESTAMP
                """, (user_email.lower(), badge['id'], progress, criteria['target'], progress))
        
        conn.commit()
        return newly_earned
    
    finally:
        cursor.close()
        conn.close()

def get_user_badges(user_email: str) -> List[Dict]:
    """Get all badges earned by user"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT b.*, ub.earned_at, ub.progress_data, ub.is_displayed, ub.notes
            FROM badges b
            JOIN user_badges ub ON b.id = ub.badge_id
            WHERE ub.user_email = %s AND ub.is_displayed = TRUE
            ORDER BY ub.earned_at DESC
        """, (user_email.lower(),))
        
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def get_badge_progress(user_email: str) -> List[Dict]:
    """Get progress on badges user hasn't earned yet"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT b.*, bp.current_progress, bp.target_progress
            FROM badges b
            JOIN badge_progress bp ON b.id = bp.badge_id
            WHERE bp.user_email = %s AND b.is_active = TRUE
            ORDER BY (bp.current_progress / bp.target_progress) DESC
        """, (user_email.lower(),))
        
        rows = cursor.fetchall()
        # Ensure criteria is a dict (parsed from JSON string) for downstream usage
        for row in rows:
            if isinstance(row.get('criteria'), str):
                try:
                    row['criteria'] = json.loads(row['criteria'])
                except Exception:
                    row['criteria'] = {}
        return rows
    finally:
        cursor.close()
        conn.close()

def get_unread_notifications(user_email: str) -> List[Dict]:
    """Get unread badge notifications"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT bn.*, b.name as badge_name, b.icon as badge_icon
            FROM badge_notifications bn
            JOIN badges b ON bn.badge_id = b.id
            WHERE bn.user_email = %s AND bn.is_read = FALSE
            ORDER BY bn.created_at DESC
        """, (user_email.lower(),))
        
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def mark_notification_read(user_email: str, notification_id: int):
    """Mark notification as read"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            UPDATE badge_notifications 
            SET is_read = TRUE 
            WHERE id = %s AND user_email = %s
        """, (notification_id, user_email.lower()))
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def render_badge_card(badge: Dict, show_progress: bool = False, progress: int = 0) -> None:
    """Render a single badge card"""
    tier_colors = {
        'bronze': '#CD7F32',
        'silver': '#C0C0C0',
        'gold': '#FFD700',
        'platinum': '#E5E4E2',
        'diamond': '#B9F2FF'
    }
    
    color = tier_colors.get(badge['tier'], '#808080')
    
    if show_progress:
        # Show progress card
        progress_percent = min(100, (progress / badge['criteria'].get('target', 1)) * 100)
        
        st.markdown(f"""
        <div style="border: 2px solid {color}; border-radius: 10px; padding: 15px; margin: 10px 0; background: linear-gradient(135deg, rgba({color[1:]},0.1), rgba(255,255,255,0.9));">
            <div style="display: flex; align-items: center; margin-bottom: 10px;">
                <span style="font-size: 2em; margin-right: 10px;">{badge['icon']}</span>
                <div>
                    <h4 style="margin: 0; color: {color};">{badge['name']}</h4>
                    <p style="margin: 0; font-size: 0.9em; color: #666;">{badge['description']}</p>
                </div>
            </div>
            <div style="background: #f0f0f0; border-radius: 5px; height: 10px; overflow: hidden;">
                <div style="background: {color}; height: 100%; width: {progress_percent}%; transition: width 0.3s;"></div>
            </div>
            <p style="margin: 5px 0 0 0; font-size: 0.8em; color: #666;">Progress: {progress}/{badge['criteria'].get('target', 1)} ({progress_percent:.1f}%)</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        # Show earned badge
        st.markdown(f"""
        <div style="border: 2px solid {color}; border-radius: 10px; padding: 15px; margin: 10px 0; background: linear-gradient(135deg, rgba({color[1:]},0.2), rgba(255,255,255,0.9));">
            <div style="display: flex; align-items: center;">
                <span style="font-size: 2.5em; margin-right: 15px;">{badge['icon']}</span>
                <div>
                    <h4 style="margin: 0; color: {color};">{badge['name']}</h4>
                    <p style="margin: 0; font-size: 0.9em; color: #666;">{badge['description']}</p>
                    <p style="margin: 5px 0 0 0; font-size: 0.8em; color: #888;">Earned: {badge['earned_at'].strftime('%Y-%m-%d')} | Points: {badge['points_value']}</p>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

def render_badge_center(user_email: str):
    """Main badge center interface"""
    # Ensure tables exist and are populated
    create_badge_system_tables()
    populate_default_badges()
    
    # Check for new badges
    newly_earned = check_and_award_badges(user_email)
    
    st.title("🏆 Badge Center")
    
    # Show newly earned badges
    if newly_earned:
        st.success(f"🎉 Congratulations! You earned {len(newly_earned)} new badge(s)!")
        for item in newly_earned:
            badge = item['badge']
            points_update = item['points_update']
            
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #FFD700, #FFA500); color: white; padding: 20px; border-radius: 10px; margin: 10px 0; text-align: center;">
                <h3 style="margin: 0;">🎉 New Badge Unlocked!</h3>
                <div style="font-size: 3em; margin: 10px 0;">{badge['icon']}</div>
                <h4>{badge['name']}</h4>
                <p>{badge['description']}</p>
                <p><strong>+{badge['points_value']} Points</strong></p>
                {f"<p>🎊 Level Up! You're now level {points_update['level']}!</p>" if points_update.get('leveled_up') else ''}
            </div>
            """, unsafe_allow_html=True)
    
    # User points and level
    user_points = get_user_points(user_email)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("🏅 Total Points", user_points['total_points'])
    with col2:
        st.metric("⭐ Level", user_points['level'])
    with col3:
        progress_to_next = (user_points['total_points'] / user_points['points_to_next_level']) * 100
        st.metric("📈 Progress to Next Level", f"{progress_to_next:.1f}%")
    
    # Tabs for different views
    tab1, tab2, tab3 = st.tabs(["🏆 Earned Badges", "📊 In Progress", "🔔 Notifications"])
    
    with tab1:
        earned_badges = get_user_badges(user_email)
        
        if not earned_badges:
            st.info("You haven't earned any badges yet. Keep working on your habits to unlock your first badge!")
        else:
            # Group badges by category
            categories = {}
            for badge in earned_badges:
                if badge['category'] not in categories:
                    categories[badge['category']] = []
                categories[badge['category']].append(badge)
            
            for category, badges in categories.items():
                st.subheader(f"📂 {category.title()}")
                for badge in badges:
                    render_badge_card(badge)
    
    with tab2:
        progress_badges = get_badge_progress(user_email)
        
        if not progress_badges:
            st.info("No badges in progress. Start tracking your habits to begin earning badges!")
        else:
            st.subheader("📊 Badges in Progress")
            
            for badge in progress_badges:
                # criteria already parsed to dict in get_badge_progress
                render_badge_card(badge, show_progress=True, progress=badge['current_progress'])
    
    with tab3:
        notifications = get_unread_notifications(user_email)
        
        if not notifications:
            st.info("No new notifications.")
        else:
            st.subheader("🔔 Recent Notifications")
            
            for notification in notifications:
                with st.container():
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown(f"""
                        <div style="background: #f0f8ff; padding: 15px; border-radius: 10px; margin: 10px 0; border-left: 4px solid #007bff;">
                            <div style="display: flex; align-items: center;">
                                <span style="font-size: 1.5em; margin-right: 10px;">{notification['badge_icon']}</span>
                                <div>
                                    <p style="margin: 0; font-weight: bold;">{notification['message']}</p>
                                    <p style="margin: 5px 0 0 0; font-size: 0.8em; color: #666;">{notification['created_at'].strftime('%Y-%m-%d %H:%M')}</p>
                                </div>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col2:
                        if st.button("✓", key=f"read_{notification['id']}"):
                            mark_notification_read(user_email, notification['id'])
                            st.rerun()

def render_badge_overview(user_email: str) -> None:
    """Render compact badge overview for dashboard"""
    user_points = get_user_points(user_email)
    earned_badges = get_user_badges(user_email)
    
    # Show recent badges
    recent_badges = earned_badges[:3] if earned_badges else []
    
    if recent_badges:
        st.subheader("🏆 Recent Badges")
        for badge in recent_badges:
            render_badge_card(badge)
    
    # Points summary
    st.subheader("⭐ Points Summary")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total Points", user_points['total_points'])
    with col2:
        st.metric("Level", user_points['level'])
    
    # Progress to next level
    if user_points['points_to_next_level'] > 0:
        progress = (user_points['total_points'] / user_points['points_to_next_level']) * 100
        st.progress(min(100, progress))
        st.caption(f"{user_points['total_points']} / {user_points['points_to_next_level']} points to next level")
