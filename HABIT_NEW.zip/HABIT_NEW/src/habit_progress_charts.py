import streamlit as st
import mysql.connector
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta, date
from typing import List, Dict, Optional, Tuple
import calendar
from collections import defaultdict

from src.db import get_db_connection

def get_habit_completion_data(user_email: str, habit_id: Optional[int] = None, 
                             start_date: Optional[date] = None, end_date: Optional[date] = None) -> pd.DataFrame:
    """Get habit completion data for charting"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        query = """
            SELECT h.id as habit_id, h.name as habit_name, h.goal, h.frequency,
                   l.log_date, l.amount, l.completed_at
            FROM habits h
            LEFT JOIN habit_logs l ON h.id = l.habit_id
            WHERE h.user_email = %s AND h.is_active = TRUE
        """
        params = [user_email.lower()]
        
        if habit_id:
            query += " AND h.id = %s"
            params.append(habit_id)
        
        if start_date:
            query += " AND (l.log_date >= %s OR l.log_date IS NULL)"
            params.append(start_date)
        
        if end_date:
            query += " AND (l.log_date <= %s OR l.log_date IS NULL)"
            params.append(end_date)
        
        query += " ORDER BY h.name, l.log_date"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        
        df = pd.DataFrame(results)
        if not df.empty:
            df['date'] = pd.to_datetime(df['log_date']).dt.date
            df['amount'] = df['amount'].fillna(0)
            df['completed'] = df['amount'] > 0
            
        return df
    finally:
        cursor.close()
        conn.close()

def get_streak_data(user_email: str, habit_id: Optional[int] = None) -> pd.DataFrame:
    """Get streak data for habits"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        query = """
            SELECT h.id as habit_id, h.name as habit_name,
                   MAX(l.log_date) as last_completion_date,
                   COUNT(CASE WHEN l.amount >= h.goal THEN 1 END) as successful_days,
                   COUNT(l.log_date) as total_days_tracked
            FROM habits h
            LEFT JOIN habit_logs l ON h.id = l.habit_id
            WHERE h.user_email = %s AND h.is_active = TRUE
            AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
        """
        params = [user_email.lower()]
        
        if habit_id:
            query += " AND h.id = %s"
            params.append(habit_id)
        
        query += " GROUP BY h.id, h.name ORDER BY h.name"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        
        df = pd.DataFrame(results)
        if not df.empty:
            df['last_completion_date'] = pd.to_datetime(df['last_completion_date']).dt.date
            df['success_rate'] = (df['successful_days'] / df['total_days_tracked'] * 100).round(1)
            
        return df
    finally:
        cursor.close()
        conn.close()

def get_weekly_progress_data(user_email: str, habit_id: Optional[int] = None, weeks: int = 8) -> pd.DataFrame:
    """Get weekly progress data"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        query = """
            SELECT h.id as habit_id, h.name as habit_name, h.goal,
                   YEARWEEK(l.log_date, 1) as week_year,
                   MIN(l.log_date) as week_start,
                   MAX(l.log_date) as week_end,
                   SUM(CASE WHEN l.amount >= h.goal THEN 1 ELSE 0 END) as successful_days,
                   COUNT(l.log_date) as active_days,
                   SUM(l.amount) as total_amount
            FROM habits h
            LEFT JOIN habit_logs l ON h.id = l.habit_id
            WHERE h.user_email = %s AND h.is_active = TRUE
            AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL %s WEEK)
        """
        params = [user_email.lower(), weeks]
        
        if habit_id:
            query += " AND h.id = %s"
            params.append(habit_id)
        
        query += " GROUP BY h.id, h.name, YEARWEEK(l.log_date, 1) ORDER BY week_year"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        
        df = pd.DataFrame(results)
        if not df.empty:
            df['week_start'] = pd.to_datetime(df['week_start']).dt.date
            df['week_end'] = pd.to_datetime(df['week_end']).dt.date
            df['success_rate'] = (df['successful_days'] / df['active_days'] * 100).round(1)
            
        return df
    finally:
        cursor.close()
        conn.close()

def get_monthly_summary_data(user_email: str, habit_id: Optional[int] = None, months: int = 6) -> pd.DataFrame:
    """Get monthly summary data"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        query = """
            SELECT h.id as habit_id, h.name as habit_name, h.goal,
                   YEAR(l.log_date) as year, MONTH(l.log_date) as month,
                   COUNT(CASE WHEN l.amount >= h.goal THEN 1 END) as successful_days,
                   COUNT(l.log_date) as active_days,
                   SUM(l.amount) as total_amount,
                   AVG(l.amount) as avg_amount
            FROM habits h
            LEFT JOIN habit_logs l ON h.id = l.habit_id
            WHERE h.user_email = %s AND h.is_active = TRUE
            AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL %s MONTH)
        """
        params = [user_email.lower(), months]
        
        if habit_id:
            query += " AND h.id = %s"
            params.append(habit_id)
        
        query += " GROUP BY h.id, h.name, YEAR(l.log_date), MONTH(l.log_date) ORDER BY year, month"
        
        cursor.execute(query, params)
        results = cursor.fetchall()
        
        df = pd.DataFrame(results)
        if not df.empty:
            df['success_rate'] = (df['successful_days'] / df['active_days'] * 100).round(1)
            df['month_name'] = df.apply(lambda row: f"{calendar.month_abbr[row['month']]} {row['year']}", axis=1)
            
        return df
    finally:
        cursor.close()
        conn.close()

def create_progress_line_chart(df: pd.DataFrame, title: str = "Habit Progress Over Time") -> go.Figure:
    """Create a line chart showing habit progress over time"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    fig = go.Figure()
    
    habits = df['habit_name'].unique()
    colors = px.colors.qualitative.Set3
    
    for i, habit in enumerate(habits):
        habit_data = df[df['habit_name'] == habit].sort_values('date')
        if habit_data.empty:
            continue
            
        color = colors[i % len(colors)]
        
        # Add completion line
        fig.add_trace(go.Scatter(
            x=habit_data['date'],
            y=habit_data['amount'],
            mode='lines+markers',
            name=f"{habit} (Actual)",
            line=dict(color=color, width=2),
            marker=dict(size=6),
            hovertemplate='<b>%{fullData.name}</b><br>Date: %{x}<br>Amount: %{y}<extra></extra>'
        ))
        
        # Add goal line
        goal = habit_data['goal'].iloc[0]
        fig.add_trace(go.Scatter(
            x=habit_data['date'],
            y=[goal] * len(habit_data),
            mode='lines',
            name=f"{habit} (Goal)",
            line=dict(color=color, width=2, dash='dash'),
            opacity=0.7,
            hovertemplate='<b>%{fullData.name}</b><br>Goal: %{y}<extra></extra>'
        ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Amount",
        hovermode='x unified',
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    return fig

def create_success_rate_bar_chart(df: pd.DataFrame, title: str = "Success Rate by Habit") -> go.Figure:
    """Create a bar chart showing success rates"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    # Group by habit and calculate success rate
    success_rates = []
    for habit in df['habit_name'].unique():
        habit_data = df[df['habit_name'] == habit]
        if habit_data.empty:
            continue
            
        successful_days = (habit_data['amount'] >= habit_data['goal']).sum()
        total_days = len(habit_data[habit_data['amount'] > 0])
        success_rate = (successful_days / total_days * 100) if total_days > 0 else 0
        
        success_rates.append({
            'habit_name': habit,
            'success_rate': round(success_rate, 1),
            'successful_days': successful_days,
            'total_days': total_days
        })
    
    if not success_rates:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    success_df = pd.DataFrame(success_rates)
    success_df = success_df.sort_values('success_rate', ascending=True)
    
    fig = go.Figure()
    
    # Color based on success rate
    colors = ['red' if rate < 50 else 'orange' if rate < 75 else 'lightgreen' 
              for rate in success_df['success_rate']]
    
    fig.add_trace(go.Bar(
        x=success_df['success_rate'],
        y=success_df['habit_name'],
        orientation='h',
        marker_color=colors,
        text=[f"{rate}%" for rate in success_df['success_rate']],
        textposition='auto',
        hovertemplate='<b>%{y}</b><br>Success Rate: %{x}%<br>Successful Days: %{customdata[0]} / %{customdata[1]}<extra></extra>',
        customdata=list(zip(success_df['successful_days'], success_df['total_days']))
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Success Rate (%)",
        yaxis_title="Habit",
        height=max(300, len(success_df) * 40)
    )
    
    return fig

def create_streak_heatmap(df: pd.DataFrame, title: str = "Habit Completion Heatmap") -> go.Figure:
    """Create a heatmap showing habit completion patterns"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    # Ensure we have valid dates only
    df_valid = df.dropna(subset=['date'])
    if df_valid.empty:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig

    # Create date range
    min_date = df_valid['date'].min()
    max_date = df_valid['date'].max()
    if pd.isna(min_date) or pd.isna(max_date):
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig

    date_range = pd.date_range(start=min_date, end=max_date, freq='D')
    
    # Create habit x date matrix
    habits = sorted(df_valid['habit_name'].unique())
    completion_matrix = []
    
    for habit in habits:
        habit_data = df_valid[df_valid['habit_name'] == habit].set_index('date')
        row = []
        for date in date_range:
            date_only = date.date()
            if date_only in habit_data.index:
                amount = habit_data.loc[date_only, 'amount']
                goal = habit_data.loc[date_only, 'goal']
                completion = 1 if amount >= goal else (0.5 if amount > 0 else 0)
            else:
                completion = 0
            row.append(completion)
        completion_matrix.append(row)
    
    fig = go.Figure(data=go.Heatmap(
        z=completion_matrix,
        x=[d.strftime('%Y-%m-%d') for d in date_range],
        y=habits,
        colorscale='RdYlGn',
        showscale=True,
        hovertemplate='<b>%{y}</b><br>Date: %{x}<br>Completion: %{z:.0%}<extra></extra>'
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Habit",
        height=max(300, len(habits) * 30)
    )
    
    return fig

def create_weekly_trend_chart(df: pd.DataFrame, title: str = "Weekly Progress Trend") -> go.Figure:
    """Create a chart showing weekly progress trends"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    fig = go.Figure()
    
    habits = df['habit_name'].unique()
    colors = px.colors.qualitative.Set3
    
    for i, habit in enumerate(habits):
        habit_data = df[df['habit_name'] == habit].sort_values('week_start')
        if habit_data.empty:
            continue
            
        color = colors[i % len(colors)]
        
        fig.add_trace(go.Scatter(
            x=habit_data['week_start'],
            y=habit_data['success_rate'],
            mode='lines+markers',
            name=habit,
            line=dict(color=color, width=2),
            marker=dict(size=6),
            hovertemplate='<b>%{fullData.name}</b><br>Week: %{x}<br>Success Rate: %{y}%<extra></extra>'
        ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Week Starting",
        yaxis_title="Success Rate (%)",
        hovermode='x unified'
    )
    
    return fig

def create_monthly_summary_chart(df: pd.DataFrame, title: str = "Monthly Summary") -> go.Figure:
    """Create a monthly summary chart"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=('Success Rate Trend', 'Total Amount Trend'),
        vertical_spacing=0.1
    )
    
    habits = df['habit_name'].unique()
    colors = px.colors.qualitative.Set3
    
    for i, habit in enumerate(habits):
        habit_data = df[df['habit_name'] == habit].sort_values(['year', 'month'])
        if habit_data.empty:
            continue
            
        color = colors[i % len(colors)]
        
        # Success rate
        fig.add_trace(go.Scatter(
            x=habit_data['month_name'],
            y=habit_data['success_rate'],
            mode='lines+markers',
            name=f"{habit} (Success Rate)",
            line=dict(color=color, width=2),
            legendgroup=habit,
            hovertemplate='<b>%{fullData.name}</b><br>Month: %{x}<br>Success Rate: %{y}%<extra></extra>'
        ), row=1, col=1)
        
        # Total amount
        fig.add_trace(go.Scatter(
            x=habit_data['month_name'],
            y=habit_data['total_amount'],
            mode='lines+markers',
            name=f"{habit} (Total)",
            line=dict(color=color, width=2, dash='dot'),
            legendgroup=habit,
            showlegend=False,
            hovertemplate='<b>%{fullData.name}</b><br>Month: %{x}<br>Total: %{y}<extra></extra>'
        ), row=2, col=1)
    
    fig.update_layout(
        title=title,
        height=600,
        hovermode='x unified'
    )
    
    fig.update_yaxes(title_text="Success Rate (%)", row=1, col=1)
    fig.update_yaxes(title_text="Total Amount", row=2, col=1)
    fig.update_xaxes(title_text="Month", row=2, col=1)
    
    return fig

def create_streak_comparison_chart(df: pd.DataFrame, title: str = "Current Streaks") -> go.Figure:
    """Create a chart comparing current streaks"""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    # Calculate current streaks
    streaks = []
    for _, row in df.iterrows():
        # This is simplified - in a real implementation, you'd calculate actual streaks
        streaks.append({
            'habit_name': row['habit_name'],
            'success_rate': row['success_rate'],
            'successful_days': row['successful_days'],
            'total_days': row['total_days']
        })
    
    if not streaks:
        fig = go.Figure()
        fig.add_annotation(text="No data available", xref="paper", yref="paper",
                         x=0.5, y=0.5, showarrow=False, font=dict(size=16))
        return fig
    
    streak_df = pd.DataFrame(streaks)
    streak_df = streak_df.sort_values('success_rate', ascending=False)
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=streak_df['success_rate'],
        y=streak_df['habit_name'],
        orientation='h',
        marker_color='lightblue',
        text=[f"{rate}%" for rate in streak_df['success_rate']],
        textposition='auto',
        hovertemplate='<b>%{y}</b><br>Success Rate: %{x}%<br>Days: %{customdata[0]} / %{customdata[1]}<extra></extra>',
        customdata=list(zip(streak_df['successful_days'], streak_df['total_days']))
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Success Rate (%)",
        yaxis_title="Habit",
        height=max(300, len(streak_df) * 40)
    )
    
    return fig

def render_date_filter() -> Tuple[Optional[date], Optional[date]]:
    """Render date filter controls"""
    st.write("**Date Range Filter**")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        preset = st.selectbox(
            "Time Period",
            options=["Last 7 days", "Last 30 days", "Last 90 days", "Last 6 months", "Custom"],
            index=1
        )
    
    if preset == "Custom":
        with col2:
            start_date = st.date_input("Start Date", value=date.today() - timedelta(days=30))
        with col3:
            end_date = st.date_input("End Date", value=date.today())
    else:
        days_map = {
            "Last 7 days": 7,
            "Last 30 days": 30,
            "Last 90 days": 90,
            "Last 6 months": 180
        }
        days = days_map[preset]
        start_date = date.today() - timedelta(days=days)
        end_date = date.today()
    
    return start_date, end_date

def render_habit_selector(user_email: str) -> Optional[int]:
    """Render habit selector"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT id, name FROM habits 
            WHERE user_email = %s AND is_active = TRUE 
            ORDER BY name
        """, (user_email.lower(),))
        habits = cursor.fetchall()
        
        if not habits:
            st.warning("No habits found. Create some habits first!")
            return None
        
        habit_options = [("All Habits", None)] + [(h['name'], h['id']) for h in habits]
        selected_habit_name, selected_habit_id = st.selectbox(
            "Select Habit",
            options=habit_options,
            format_func=lambda x: x[0]
        )
        
        return selected_habit_id
    finally:
        cursor.close()
        conn.close()

def render_progress_charts_page(user_email: str):
    """Main progress charts page"""
    st.title("📊 Habit Progress Charts")
    
    # Filters
    col1, col2 = st.columns([1, 2])
    with col1:
        selected_habit_id = render_habit_selector(user_email)
    with col2:
        start_date, end_date = render_date_filter()
    
    # Get data
    completion_data = get_habit_completion_data(user_email, selected_habit_id, start_date, end_date)
    weekly_data = get_weekly_progress_data(user_email, selected_habit_id)
    monthly_data = get_monthly_summary_data(user_email, selected_habit_id)
    streak_data = get_streak_data(user_email, selected_habit_id)
    
    if completion_data.empty:
        st.warning("No progress data found. Start completing your habits to see charts!")
        return
    
    # Chart tabs
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "📈 Progress Line", "📊 Success Rates", "🔥 Completion Heatmap", 
        "📅 Weekly Trends", "📆 Monthly Summary", "⚡ Current Streaks"
    ])
    
    with tab1:
        st.plotly_chart(
            create_progress_line_chart(completion_data, "Habit Progress Over Time"),
            use_container_width=True,
            key="progress_line_chart"
        )
    
    with tab2:
        st.plotly_chart(
            create_success_rate_bar_chart(completion_data, "Success Rate by Habit"),
            use_container_width=True,
            key="success_rate_chart"
        )
    
    with tab3:
        st.plotly_chart(
            create_streak_heatmap(completion_data, "Habit Completion Heatmap"),
            use_container_width=True,
            key="completion_heatmap"
        )
    
    with tab4:
        st.plotly_chart(
            create_weekly_trend_chart(weekly_data, "Weekly Progress Trends"),
            use_container_width=True,
            key="weekly_trend_chart"
        )
    
    with tab5:
        st.plotly_chart(
            create_monthly_summary_chart(monthly_data, "Monthly Progress Summary"),
            use_container_width=True,
            key="monthly_summary_chart"
        )
    
    with tab6:
        st.plotly_chart(
            create_streak_comparison_chart(streak_data, "Current Streak Comparison"),
            use_container_width=True,
            key="streak_comparison_chart"
        )
    
    # Summary statistics
    st.write("---")
    st.subheader("📋 Summary Statistics")
    
    if not completion_data.empty:
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_days = len(completion_data[completion_data['amount'] > 0])
            st.metric("Active Days", total_days)
        
        with col2:
            successful_days = len(completion_data[completion_data['amount'] >= completion_data['goal']])
            success_rate = (successful_days / total_days * 100) if total_days > 0 else 0
            st.metric("Success Rate", f"{success_rate:.1f}%")
        
        with col3:
            total_amount = completion_data['amount'].sum()
            st.metric("Total Amount", int(total_amount))
        
        with col4:
            avg_amount = completion_data[completion_data['amount'] > 0]['amount'].mean()
            st.metric("Daily Average", f"{avg_amount:.1f}")

def render_progress_manager(user_email: str):
    """Render progress charts manager"""
    render_progress_charts_page(user_email)
