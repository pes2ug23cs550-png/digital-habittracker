from __future__ import annotations
from datetime import date, timedelta, datetime
from typing import Dict, Tuple
from .db import get_conn
from .frequency import get_frequencies_for_user


def _logs_count_in_window(habit_id: int, start: date, end: date) -> int:
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            SELECT COUNT(*) FROM habit_logs
            WHERE habit_id=%s AND log_date BETWEEN %s AND %s
            """,
            (habit_id, start, end),
        )
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else 0


def _expected_occurrences(frequency: str, window_days: int) -> int:
    d = max(1, int(window_days))
    f = (frequency or "daily").lower()
    if f == "daily":
        return d
    if f == "weekly":
        return max(1, round(d / 7))
    if f == "monthly":
        return max(1, round(d / 30))
    # fallback
    return d


def get_progress_for_user(user_email: str, window_days: int = 30) -> Dict[int, Tuple[int, int, int]]:
    """
    Returns a dict: habit_id -> (achieved_count, expected_count, percent_int)
    where percent_int is 0..100 rounded.
    """
    end = date.today()
    start = end - timedelta(days=window_days - 1)
    # get user's habits
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT id FROM habits WHERE user_email=%s",
            (user_email.lower(),),
        )
        habit_ids = [int(r[0]) for r in (cur.fetchall() or [])]
    freq_map = {}
    try:
        freq_map = get_frequencies_for_user(user_email) or {}
    except Exception:
        freq_map = {}
    result: Dict[int, Tuple[int, int, int]] = {}
    for hid in habit_ids:
        freq = freq_map.get(hid, "daily")
        achieved = _logs_count_in_window(hid, start, end)
        expected = _expected_occurrences(freq, window_days)
        percent = min(100, int(round((achieved / expected) * 100))) if expected > 0 else 0
        result[hid] = (achieved, expected, percent)
    return result


def get_progress_for_habit(habit_id: int, frequency: str | None, window_days: int = 30) -> Tuple[int, int, int]:
    end = date.today()
    start = end - timedelta(days=window_days - 1)
    achieved = _logs_count_in_window(habit_id, start, end)
    expected = _expected_occurrences((frequency or "daily"), window_days)
    percent = min(100, int(round((achieved / expected) * 100))) if expected > 0 else 0
    return achieved, expected, percent
