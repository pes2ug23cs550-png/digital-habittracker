import os
import streamlit as st

try:
    import mysql.connector
except Exception:
    mysql = None


def _db_conn():
    cfg = st.secrets.get("mysql", {})
    kwargs = {
        "host": cfg.get("host", "localhost"),
        "user": cfg.get("user", "root"),
        "password": cfg.get("password", ""),
        "database": cfg.get("database", "habit"),
        "port": int(cfg.get("port", 3306)),
    }
    if cfg.get("auth_plugin"):
        kwargs["auth_plugin"] = cfg.get("auth_plugin")
    return mysql.connector.connect(**kwargs)


def _init_db():
    if mysql is None:
        st.error("mysql-connector-python is required")
        return
    with _db_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
              id INT AUTO_INCREMENT PRIMARY KEY,
              email VARCHAR(255) UNIQUE,
              password_hash VARCHAR(128),
              password_salt VARCHAR(64),
              provider ENUM('email','google') NOT NULL,
              google_sub VARCHAR(64),
              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        # Ensure session_version column exists (MySQL 8.0+ supports IF NOT EXISTS)
        try:
            cur.execute(
                """
                ALTER TABLE users
                ADD COLUMN IF NOT EXISTS session_version INT NOT NULL DEFAULT 0
                """
            )
        except Exception:
            # Fallback for older MySQL versions: attempt to detect column
            try:
                cur.execute("SHOW COLUMNS FROM users LIKE 'session_version'")
                if not cur.fetchone():
                    cur.execute("ALTER TABLE users ADD COLUMN session_version INT NOT NULL DEFAULT 0")
            except Exception:
                pass
        cnx.commit()


def _email_exists(email: str) -> bool:
    with _db_conn() as cnx:
        cur = cnx.cursor()
        cur.execute("SELECT 1 FROM users WHERE email=%s", (email.lower(),))
        return cur.fetchone() is not None


def verify_user_email(email: str, password: str) -> bool:
    with _db_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT id FROM users WHERE email=%s AND provider='email' AND password_hash=%s",
            (email.lower(), password),
        )
        row = cur.fetchone()
        return row is not None


def get_session_version(email: str) -> int:
    with _db_conn() as cnx:
        cur = cnx.cursor()
        cur.execute("SELECT session_version FROM users WHERE email=%s", (email.lower(),))
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else 0


def bump_session_version(email: str) -> bool:
    with _db_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "UPDATE users SET session_version = session_version + 1 WHERE email=%s",
            (email.lower(),),
        )
        cnx.commit()
        return cur.rowcount > 0


def create_user_email(email: str, password: str) -> bool:
    if mysql is None:
        st.error("mysql-connector-python is required")
        return False
    _init_db()
    if _email_exists(email):
        st.warning("Email already registered")
        return False
    pwd_hash, salt = password, ""
    with _db_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "INSERT INTO users (email, password_hash, password_salt, provider) VALUES (%s,%s,%s,'email')",
            (email.lower(), pwd_hash, salt),
        )
        cnx.commit()
    return True


# UI moved to src/signup.py and src/signin.py
