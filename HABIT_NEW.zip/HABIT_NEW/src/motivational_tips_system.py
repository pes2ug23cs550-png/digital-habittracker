import streamlit as st
import mysql.connector
import pandas as pd
import random
import numpy as np
from datetime import datetime, timedelta, date, time
from typing import List, Dict, Optional, Tuple
import json

from src.db import get_db_connection

def ensure_columns_exist(cursor, table_name: str, columns: Dict[str, str]):
    """Ensure required columns exist in the specified table."""
    for column_name, column_definition in columns.items():
        cursor.execute("""
            SELECT COUNT(*) 
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = %s
        """, (table_name, column_name))
        exists = cursor.fetchone()[0]
        if not exists:
            cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_definition}")


def create_motivational_tables():
    """Create motivational tips and quotes tables if they don't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS motivational_quotes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                quote_text TEXT NOT NULL,
                author VARCHAR(255),
                category ENUM('general', 'consistency', 'streaks', 'improvement', 'setback', 'achievement', 'motivation', 'discipline', 'success', 'persistence') NOT NULL,
                mood_tag ENUM('uplifting', 'encouraging', 'thoughtful', 'energetic', 'calm', 'determined') DEFAULT 'encouraging',
                length_tag ENUM('short', 'medium', 'long') DEFAULT 'medium',
                is_active BOOLEAN DEFAULT TRUE,
                usage_count INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_category (category),
                INDEX idx_mood_tag (mood_tag),
                INDEX idx_length_tag (length_tag),
                INDEX idx_active (is_active)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS motivational_tips (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tip_text TEXT NOT NULL,
                tip_type ENUM('general', 'consistency', 'streak_building', 'habit_formation', 'goal_setting', 'time_management', 'motivation', 'overcoming_setbacks') NOT NULL,
                difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
                context_trigger ENUM('low_consistency', 'new_streak', 'broken_streak', 'milestone', 'plateau', 'high_performance', 'weekly_review') DEFAULT 'general',
                is_actionable BOOLEAN DEFAULT TRUE,
                priority_score INT DEFAULT 50,
                is_active BOOLEAN DEFAULT TRUE,
                usage_count INT DEFAULT 0,
                effectiveness_score DECIMAL(3,2) DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_tip_type (tip_type),
                INDEX idx_context_trigger (context_trigger),
                INDEX idx_difficulty (difficulty_level),
                INDEX idx_priority (priority_score),
                INDEX idx_active (is_active)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_motivational_preferences (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                preferred_quote_categories JSON,
                preferred_tip_types JSON,
                preferred_mood_tags JSON,
                delivery_frequency ENUM('daily', 'every_other_day', 'weekly', 'milestones_only') DEFAULT 'daily',
                preferred_time TIME DEFAULT '09:00:00',
                enable_tips BOOLEAN DEFAULT TRUE,
                enable_quotes BOOLEAN DEFAULT TRUE,
                enable_contextual BOOLEAN DEFAULT TRUE,
                last_tip_date DATE,
                last_quote_date DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_email (user_email),
                INDEX idx_user_email (user_email)
            )
        """)

        # Ensure schema is up-to-date for existing installations
        ensure_columns_exist(cursor, "user_motivational_preferences", {
            "preferred_quote_categories": "JSON NULL",
            "preferred_tip_types": "JSON NULL",
            "preferred_mood_tags": "JSON NULL",
            "delivery_frequency": "ENUM('daily', 'every_other_day', 'weekly', 'milestones_only') DEFAULT 'daily'",
            "preferred_time": "TIME DEFAULT '09:00:00'",
            "enable_tips": "BOOLEAN DEFAULT TRUE",
            "enable_quotes": "BOOLEAN DEFAULT TRUE",
            "enable_contextual": "BOOLEAN DEFAULT TRUE",
            "last_tip_date": "DATE NULL",
            "last_quote_date": "DATE NULL"
        })
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_motivational_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                content_type ENUM('quote', 'tip') NOT NULL,
                content_id INT NOT NULL,
                context_trigger VARCHAR(255),
                user_reaction ENUM('liked', 'neutral', 'disliked') DEFAULT 'neutral',
                viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                was_helpful BOOLEAN DEFAULT NULL,
                INDEX idx_user_email (user_email),
                INDEX idx_content_type (content_type),
                INDEX idx_context_trigger (context_trigger),
                INDEX idx_viewed_at (viewed_at)
            )
        """)

        ensure_columns_exist(cursor, "user_motivational_history", {
            "context_trigger": "VARCHAR(255) NULL",
            "user_reaction": "ENUM('liked','neutral','disliked') DEFAULT 'neutral'",
            "was_helpful": "BOOLEAN DEFAULT NULL"
        })
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def populate_default_motivational_content():
    """Populate database with default quotes and tips"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if content already exists
        cursor.execute("SELECT COUNT(*) FROM motivational_quotes")
        quote_count = cursor.fetchone()[0]
        
        if quote_count > 0:
            return  # Content already populated
        
        # Default quotes
        default_quotes = [
            ("The secret of getting ahead is getting started.", "Mark Twain", "motivation", "energetic", "short"),
            ("Success is the sum of small efforts repeated day in and day out.", "Robert Collier", "consistency", "encouraging", "medium"),
            ("We are what we repeatedly do. Excellence, then, is not an act, but a habit.", "Aristotle", "habit_formation", "thoughtful", "medium"),
            ("The only way to do great work is to love what you do.", "Steve Jobs", "motivation", "uplifting", "short"),
            ("Don't watch the clock; do what it does. Keep going.", "Sam Levenson", "persistence", "determined", "short"),
            ("Motivation is what gets you started. Habit is what keeps you going.", "Jim Ryun", "discipline", "encouraging", "medium"),
            ("The journey of a thousand miles begins with one step.", "Lao Tzu", "general", "thoughtful", "short"),
            ("Success is not final, failure is not fatal: it is the courage to continue that counts.", "Winston Churchill", "persistence", "determined", "medium"),
            ("You don't have to be great to start, but you have to start to be great.", "Zig Ziglar", "motivation", "uplifting", "short"),
            ("A year from now you may wish you had started today.", "Karen Lamb", "motivation", "encouraging", "short"),
            ("The only impossible journey is the one you never begin.", "Tony Robbins", "motivation", "energetic", "short"),
            ("Excellence is not a singular act, but a habit. You are what you repeatedly do.", "Aristotle", "consistency", "thoughtful", "medium"),
            ("Discipline is the bridge between goals and accomplishment.", "Jim Rohn", "discipline", "determined", "short"),
            ("The secret of change is to focus all of your energy not on fighting the old, but on building the new.", "Socrates", "improvement", "thoughtful", "medium"),
            ("Fall seven times, stand up eight.", "Japanese Proverb", "persistence", "determined", "short"),
            ("Your limitation—it's only your imagination.", "Unknown", "motivation", "uplifting", "short"),
            ("Great things never come from comfort zones.", "Unknown", "achievement", "energetic", "short"),
            ("Dream it. Wish it. Do it.", "Unknown", "motivation", "energetic", "short"),
            ("Success doesn't just find you. You have to go out and get it.", "Unknown", "success", "determined", "short"),
            ("The harder you work for something, the greater you'll feel when you achieve it.", "Unknown", "achievement", "encouraging", "medium"),
            ("Dream bigger. Do bigger.", "Unknown", "motivation", "energetic", "short"),
            ("Don't stop when you're tired. Stop when you're done.", "Unknown", "persistence", "determined", "short"),
            ("Wake up with determination. Go to bed with satisfaction.", "Unknown", "discipline", "encouraging", "short"),
            ("Do something today that your future self will thank you for.", "Unknown", "motivation", "thoughtful", "medium"),
            ("Little things make big days.", "Unknown", "consistency", "encouraging", "short"),
            ("It's going to be hard, but hard does not mean impossible.", "Unknown", "persistence", "determined", "short"),
            ("Don't wait for opportunity. Create it.", "Unknown", "motivation", "energetic", "short"),
            ("Sometimes we're tested not to show our weaknesses, but to discover our strengths.", "Unknown", "setback", "thoughtful", "medium"),
            ("The key to success is to focus on goals, not obstacles.", "Unknown", "success", "determined", "short"),
            ("Dream it. Believe it. Build it.", "Unknown", "achievement", "uplifting", "short")
        ]
        
        cursor.executemany("""
            INSERT INTO motivational_quotes 
            (quote_text, author, category, mood_tag, length_tag)
            VALUES (%s, %s, %s, %s, %s)
        """, default_quotes)
        
        # Default tips
        default_tips = [
            ("Start with just 2 minutes of your habit. The hardest part is starting.", "habit_formation", "beginner", "low_consistency", True, 80),
            ("Stack your new habit with an existing one. Do your new habit right after something you already do daily.", "habit_formation", "beginner", "new_streak", True, 85),
            ("Prepare everything you need the night before to reduce friction in the morning.", "time_management", "beginner", "general", True, 75),
            ("Track your habit visually. Use a calendar or app to mark off completed days.", "consistency", "beginner", "weekly_review", True, 90),
            ("If you miss a day, don't worry. Just get back on track the next day. Never miss twice in a row.", "persistence", "beginner", "broken_streak", True, 95),
            ("Set a specific time and place for your habit. Context triggers make habits automatic.", "habit_formation", "intermediate", "consistency", True, 80),
            ("Use the '2-minute rule': If it takes less than 2 minutes, do it immediately.", "time_management", "beginner", "general", True, 70),
            ("Reward yourself immediately after completing your habit to reinforce the behavior.", "motivation", "beginner", "milestone", True, 85),
            ("Focus on building the identity of someone who does this habit, not just the action itself.", "habit_formation", "intermediate", "high_performance", True, 90),
            ("When motivation is low, rely on discipline. Your future self will thank you.", "discipline", "intermediate", "low_consistency", True, 85),
            ("Break large goals into smaller, manageable chunks. Small wins build momentum.", "goal_setting", "beginner", "plateau", True, 80),
            ("Use habit tracking apps or simple calendars to visualize your progress.", "consistency", "beginner", "weekly_review", True, 75),
            ("Find an accountability partner. Share your progress with someone regularly.", "motivation", "intermediate", "consistency", True, 85),
            ("If you're struggling, consider if your goal is too big. Reduce it temporarily to build momentum.", "goal_setting", "intermediate", "low_consistency", True, 90),
            ("Celebrate small wins! Every completed day is a victory worth acknowledging.", "motivation", "beginner", "milestone", True, 80),
            ("Use environment design. Make good habits easy and bad habits hard.", "habit_formation", "advanced", "plateau", True, 85),
            ("Track your 'why'. Write down the reason behind each habit and review it weekly.", "motivation", "intermediate", "weekly_review", True, 90),
            ("Use implementation intentions: 'I will [HABIT] at [TIME] in [PLACE]'", "habit_formation", "intermediate", "new_streak", True, 80),
            ("If you miss a day, analyze what went wrong without judgment. Learn and adjust.", "overcoming_setbacks", "advanced", "broken_streak", True, 85),
            ("Focus on consistency over intensity. It's better to do a little every day than a lot occasionally.", "consistency", "intermediate", "plateau", True, 90),
            ("Use the 'one habit at a time' rule. Master one habit before adding another.", "habit_formation", "beginner", "new_streak", True, 85),
            ("Create a 'minimum viable habit' - the smallest version that still counts.", "goal_setting", "beginner", "low_consistency", True, 80),
            ("Use time blocking. Schedule your habits in your calendar like appointments.", "time_management", "intermediate", "consistency", True, 85),
            ("Review your progress weekly. What worked? What didn't? Adjust accordingly.", "goal_setting", "intermediate", "weekly_review", True, 90),
            ("Create a ritual around your habit. Make it enjoyable and something you look forward to.", "motivation", "advanced", "high_performance", True, 85),
            ("Use the 'seinfeld method' - don't break the chain of consecutive days.", "streak_building", "intermediate", "new_streak", True, 95),
            ("When you feel like quitting, remember why you started. Reconnect with your motivation.", "motivation", "beginner", "low_consistency", True, 85),
            ("Focus on the process, not just the outcome. Enjoy the daily practice.", "habit_formation", "advanced", "high_performance", True, 80),
            ("Use visual cues. Put reminders where you'll see them at the right time.", "habit_formation", "beginner", "consistency", True, 75),
            ("Track not just completion, but also how you felt. This helps identify patterns.", "consistency", "advanced", "weekly_review", True, 85),
            ("If you're consistently failing, consider if the habit aligns with your values and schedule.", "goal_setting", "advanced", "plateau", True, 90),
            ("Use habit stacking with multiple habits. Create a routine that flows naturally.", "habit_formation", "advanced", "high_performance", True, 85),
            ("Remember that habits are like compound interest - small daily gains add up exponentially.", "motivation", "intermediate", "milestone", True, 90),
            ("Create accountability by making your goals public or sharing with a friend.", "motivation", "intermediate", "consistency", True, 85),
            ("Use the 'if-then' planning: If [situation], then [habit response].", "habit_formation", "advanced", "low_consistency", True, 80),
            ("Celebrate streak milestones with meaningful rewards that reinforce your identity.", "streak_building", "intermediate", "milestone", True, 85),
            ("When motivation dips, focus on your identity: 'I am the type of person who...'", "habit_formation", "advanced", "low_consistency", True, 90),
            ("Review and adjust your habits seasonally. What worked in summer might not work in winter.", "goal_setting", "advanced", "plateau", True, 85),
            ("Create a 'failure recovery' plan. What will you do when you inevitably miss a day?", "overcoming_setbacks", "advanced", "broken_streak", True, 90),
            ("Use technology wisely - apps can help track, but don't let them become the focus.", "time_management", "intermediate", "consistency", True, 75),
            ("Remember that perfect is the enemy of good. Done is better than perfect.", "habit_formation", "beginner", "low_consistency", True, 85),
            ("Create morning and evening routines that bookend your day with purpose.", "habit_formation", "intermediate", "consistency", True, 80),
            ("Use the 21/90 rule: 21 days to build a habit, 90 days to build a lifestyle.", "habit_formation", "intermediate", "milestone", True, 85),
            ("Track your energy levels. Schedule demanding habits when you have the most energy.", "time_management", "advanced", "plateau", True, 85),
            ("Remember that every expert was once a beginner. Be patient with your progress.", "motivation", "beginner", "setback", True, 90),
            ("Use visual progress tracking. Seeing your progress graphically can be very motivating.", "consistency", "beginner", "weekly_review", True, 80),
            ("Create a 'why board' with visual reminders of your motivations and goals.", "motivation", "intermediate", "low_consistency", True, 85),
            ("Practice self-compassion. Habits take time to build. Be kind to yourself during the process.", "overcoming_setbacks", "intermediate", "broken_streak", True, 90)
        ]
        
        cursor.executemany("""
            INSERT INTO motivational_tips 
            (tip_text, tip_type, difficulty_level, context_trigger, is_actionable, priority_score)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, default_tips)
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def get_user_motivational_preferences(user_email: str) -> Dict:
    """Get or create user motivational preferences"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT * FROM user_motivational_preferences WHERE user_email = %s
        """, (user_email.lower(),))
        
        result = cursor.fetchone()
        
        if not result:
            # Create default preferences
            default_prefs = {
                'preferred_quote_categories': ['motivation', 'consistency', 'persistence'],
                'preferred_tip_types': ['habit_formation', 'consistency', 'motivation'],
                'preferred_mood_tags': ['encouraging', 'uplifting', 'determined'],
                'delivery_frequency': 'daily',
                'preferred_time': '09:00:00',
                'enable_tips': True,
                'enable_quotes': True,
                'enable_contextual': True,
                'last_tip_date': None,
                'last_quote_date': None
            }
            
            cursor.execute("""
                INSERT INTO user_motivational_preferences 
                (user_email, preferred_quote_categories, preferred_tip_types,
                 preferred_mood_tags, delivery_frequency, preferred_time,
                 enable_tips, enable_quotes, enable_contextual)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (user_email.lower(),
                  json.dumps(default_prefs['preferred_quote_categories']),
                  json.dumps(default_prefs['preferred_tip_types']),
                  json.dumps(default_prefs['preferred_mood_tags']),
                  default_prefs['delivery_frequency'],
                  default_prefs['preferred_time'],
                  default_prefs['enable_tips'],
                  default_prefs['enable_quotes'],
                  default_prefs['enable_contextual']))
            
            conn.commit()
            return default_prefs
        
        # Parse JSON fields
        result['preferred_quote_categories'] = json.loads(result['preferred_quote_categories']) if result['preferred_quote_categories'] else []
        result['preferred_tip_types'] = json.loads(result['preferred_tip_types']) if result['preferred_tip_types'] else []
        result['preferred_mood_tags'] = json.loads(result['preferred_mood_tags']) if result['preferred_mood_tags'] else []
        
        return result
    finally:
        cursor.close()
        conn.close()

def analyze_user_context(user_email: str) -> Dict:
    """Analyze user's current context for motivational content"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Get recent habit performance
        cursor.execute("""
            SELECT h.name, h.goal, COUNT(l.id) as total_logs,
                   SUM(CASE WHEN l.log_date IS NOT NULL THEN 1 ELSE 0 END) as completed_days,
                   MAX(l.log_date) as last_completion
            FROM habits h
            LEFT JOIN habit_logs l ON h.id = l.habit_id AND l.log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            WHERE h.user_email = %s AND h.is_active = TRUE
            GROUP BY h.id, h.name, h.goal
        """, (user_email.lower(),))
        
        habit_performance = cursor.fetchall()
        
        # Analyze patterns
        total_habits = len(habit_performance)
        active_habits = len([h for h in habit_performance if h['last_completion']])
        
        if total_habits == 0:
            return {'context': 'new_user', 'triggers': ['new_streak']}
        
        # Calculate average completion rate
        completion_rates = []
        for habit in habit_performance:
            if habit['total_logs'] > 0:
                rate = (habit['completed_days'] / habit['total_logs']) * 100
                completion_rates.append(rate)
        
        avg_completion = np.mean(completion_rates) if completion_rates else 0
        
        # Determine context
        triggers = []
        
        if avg_completion < 30:
            triggers.append('low_consistency')
        elif avg_completion > 80:
            triggers.append('high_performance')
        
        # Check for recent streaks (simplified)
        recent_completions = len([h for h in habit_performance if h['last_completion'] == date.today()])
        if recent_completions == 0:
            triggers.append('broken_streak')
        elif recent_completions >= total_habits * 0.8:
            triggers.append('milestone')
        
        # Check if it's been a while since any activity
        max_last_completion = max([h['last_completion'] for h in habit_performance if h['last_completion']], default=None)
        if max_last_completion and (date.today() - max_last_completion).days > 3:
            triggers.append('setback')
        
        # Weekly review trigger (simplified - could be enhanced with actual schedule)
        if date.today().weekday() == 0:  # Monday
            triggers.append('weekly_review')
        
        return {
            'context': 'established_user',
            'triggers': triggers,
            'avg_completion': avg_completion,
            'active_habits': active_habits,
            'total_habits': total_habits
        }
    finally:
        cursor.close()
        conn.close()

def get_contextual_quote(user_email: str, context: Dict) -> Optional[Dict]:
    """Get a contextual quote based on user's current situation"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        preferences = get_user_motivational_preferences(user_email)
        
        if not preferences['enable_quotes']:
            return None
        
        # Determine quote category based on context
        category_map = {
            'low_consistency': ['consistency', 'motivation', 'persistence'],
            'high_performance': ['achievement', 'success', 'motivation'],
            'broken_streak': ['setback', 'persistence', 'motivation'],
            'milestone': ['achievement', 'success', 'motivation'],
            'new_streak': ['motivation', 'discipline', 'habit_formation'],
            'setback': ['setback', 'persistence', 'motivation'],
            'weekly_review': ['consistency', 'improvement', 'success']
        }
        
        # Select categories based on triggers
        preferred_categories = []
        for trigger in context.get('triggers', []):
            if trigger in category_map:
                preferred_categories.extend(category_map[trigger])
        
        # Fall back to user preferences if no contextual categories
        if not preferred_categories:
            preferred_categories = preferences['preferred_quote_categories']
        
        # Build query
        if preferred_categories:
            placeholders = ','.join(['%s'] * len(preferred_categories))
            query = f"""
                SELECT * FROM motivational_quotes 
                WHERE category IN ({placeholders}) AND is_active = TRUE
                ORDER BY RAND() LIMIT 1
            """
            cursor.execute(query, preferred_categories)
        else:
            cursor.execute("""
                SELECT * FROM motivational_quotes 
                WHERE is_active = TRUE ORDER BY RAND() LIMIT 1
            """)
        
        quote = cursor.fetchone()
        
        if quote:
            # Update usage count
            cursor.execute("""
                UPDATE motivational_quotes SET usage_count = usage_count + 1 WHERE id = %s
            """, (quote['id'],))
            
            # Log delivery
            cursor.execute("""
                INSERT INTO user_motivational_history 
                (user_email, content_type, content_id, context_trigger)
                VALUES (%s, 'quote', %s, %s)
            """, (user_email.lower(), quote['id'], ','.join(context.get('triggers', []))))
            
            conn.commit()
        
        return quote
    finally:
        cursor.close()
        conn.close()

def get_contextual_tip(user_email: str, context: Dict) -> Optional[Dict]:
    """Get a contextual tip based on user's current situation"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        preferences = get_user_motivational_preferences(user_email)
        
        if not preferences['enable_tips']:
            return None
        
        # Get tips based on context triggers
        triggers = context.get('triggers', ['general'])
        
        # Build query prioritized by context triggers
        trigger_placeholders = ','.join(['%s'] * len(triggers))
        query = f"""
            SELECT * FROM motivational_tips 
            WHERE context_trigger IN ({trigger_placeholders}) 
            AND is_active = TRUE
            ORDER BY priority_score DESC, RAND() LIMIT 1
        """
        cursor.execute(query, triggers)
        tip = cursor.fetchone()
        
        # Fallback to general tips if no contextual tip found
        if not tip:
            cursor.execute("""
                SELECT * FROM motivational_tips 
                WHERE context_trigger = 'general' AND is_active = TRUE
                ORDER BY priority_score DESC, RAND() LIMIT 1
            """)
            tip = cursor.fetchone()
        
        if tip:
            # Update usage count
            cursor.execute("""
                UPDATE motivational_tips SET usage_count = usage_count + 1 WHERE id = %s
            """, (tip['id'],))
            
            # Log delivery
            cursor.execute("""
                INSERT INTO user_motivational_history 
                (user_email, content_type, content_id, context_trigger)
                VALUES (%s, 'tip', %s, %s)
            """, (user_email.lower(), tip['id'], ','.join(triggers)))
            
            conn.commit()
        
        return tip
    finally:
        cursor.close()
        conn.close()

def should_show_motivational_content(user_email: str, content_type: str) -> bool:
    """Check if user should receive motivational content based on preferences"""
    preferences = get_user_motivational_preferences(user_email)
    
    if content_type == 'quote' and not preferences['enable_quotes']:
        return False
    
    if content_type == 'tip' and not preferences['enable_tips']:
        return False
    
    # Check frequency
    today = date.today()
    last_date_field = f'last_{content_type}_date'
    
    if preferences[last_date_field]:
        last_date = preferences[last_date_field]
        days_since = (today - last_date).days
        
        frequency_map = {
            'daily': 1,
            'every_other_day': 2,
            'weekly': 7,
            'milestones_only': 999  # Only show on milestones
        }
        
        required_days = frequency_map.get(preferences['delivery_frequency'], 1)
        
        if days_since < required_days:
            return False
    
    return True

def update_last_content_date(user_email: str, content_type: str):
    """Update the last content delivery date for user"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        field_name = f'last_{content_type}_date'
        cursor.execute(f"""
            UPDATE user_motivational_preferences 
            SET {field_name} = CURDATE() 
            WHERE user_email = %s
        """, (user_email.lower(),))
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def get_daily_motivation(user_email: str) -> Dict:
    """Get daily motivational content (quote and/or tip)"""
    context = analyze_user_context(user_email)
    result = {'quote': None, 'tip': None, 'context': context}
    
    # Get quote if enabled and due
    if should_show_motivational_content(user_email, 'quote'):
        quote = get_contextual_quote(user_email, context)
        if quote:
            result['quote'] = quote
            update_last_content_date(user_email, 'quote')
    
    # Get tip if enabled and due
    if should_show_motivational_content(user_email, 'tip'):
        tip = get_contextual_tip(user_email, context)
        if tip:
            result['tip'] = tip
            update_last_content_date(user_email, 'tip')
    
    return result

def render_motivational_card(content: Dict, content_type: str) -> None:
    """Render a motivational content card"""
    if content_type == 'quote' and content:
        with st.container():
            st.markdown("---")
            col1, col2 = st.columns([1, 8])
            with col1:
                st.markdown("💭")
            with col2:
                st.markdown(f"**{content['quote_text']}**")
                if content['author']:
                    st.markdown(f"*— {content['author']}*")
                st.caption(f"Category: {content['category'].replace('_', ' ').title()}")
    
    elif content_type == 'tip' and content:
        with st.container():
            st.markdown("---")
            col1, col2 = st.columns([1, 8])
            with col1:
                st.markdown("💡")
            with col2:
                st.markdown(f"**{content['tip_text']}**")
                st.caption(f"Type: {content['tip_type'].replace('_', ' ').title()} | Difficulty: {content['difficulty_level'].title()}")

def render_motivational_preferences(user_email: str) -> None:
    """Render motivational preferences interface"""
    st.subheader("🎯 Motivational Preferences")
    
    preferences = get_user_motivational_preferences(user_email)
    
    with st.form("motivational_preferences"):
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Content Settings**")
            enable_quotes = st.checkbox("Enable Daily Quotes", value=preferences['enable_quotes'])
            enable_tips = st.checkbox("Enable Daily Tips", value=preferences['enable_tips'])
            enable_contextual = st.checkbox("Enable Contextual Content", value=preferences['enable_contextual'])
            
            delivery_frequency = st.selectbox(
                "Delivery Frequency",
                options=['daily', 'every_other_day', 'weekly', 'milestones_only'],
                index=['daily', 'every_other_day', 'weekly', 'milestones_only'].index(preferences['delivery_frequency'])
            )
            
            # Preferred time – handle stored TIME, timedelta, or string formats safely
            raw_pref_time = preferences['preferred_time']
            default_time = time(9, 0)

            parsed_time = default_time
            try:
                if isinstance(raw_pref_time, time):
                    parsed_time = raw_pref_time
                else:
                    s = str(raw_pref_time)
                    parts = s.split(':')
                    if len(parts) >= 2:
                        hour = int(parts[0])
                        minute = int(parts[1])
                        parsed_time = time(hour, minute)
            except Exception:
                parsed_time = default_time

            preferred_time = st.time_input("Preferred Time", value=parsed_time)
        
        with col2:
            st.write("**Content Preferences**")
            
            # Quote categories
            all_quote_categories = ['general', 'consistency', 'streaks', 'improvement', 'setback', 'achievement', 'motivation', 'discipline', 'success', 'persistence']
            selected_quote_categories = st.multiselect(
                "Preferred Quote Categories",
                options=all_quote_categories,
                default=preferences['preferred_quote_categories']
            )
            
            # Tip types
            all_tip_types = ['general', 'consistency', 'streak_building', 'habit_formation', 'goal_setting', 'time_management', 'motivation', 'overcoming_setbacks']
            selected_tip_types = st.multiselect(
                "Preferred Tip Types",
                options=all_tip_types,
                default=preferences['preferred_tip_types']
            )
            
            # Mood tags
            all_mood_tags = ['encouraging', 'uplifting', 'determined', 'calm', 'energetic', 'focused', 'positive', 'resilient']
            selected_mood_tags = st.multiselect(
                "Preferred Mood Tags",
                options=all_mood_tags,
                default=preferences['preferred_mood_tags']
            )
        
        if st.form_submit_button("Save Preferences"):
            conn = get_db_connection()
            cursor = conn.cursor()
            
            try:
                cursor.execute("""
                    UPDATE user_motivational_preferences 
                    SET enable_quotes = %s, enable_tips = %s, enable_contextual = %s,
                        delivery_frequency = %s, preferred_time = %s,
                        preferred_quote_categories = %s, preferred_tip_types = %s,
                        preferred_mood_tags = %s
                    WHERE user_email = %s
                """, (enable_quotes, enable_tips, enable_contextual,
                      delivery_frequency, preferred_time,
                      json.dumps(selected_quote_categories), json.dumps(selected_tip_types),
                      json.dumps(selected_mood_tags),
                      user_email.lower()))
                
                conn.commit()
                st.success("Preferences saved successfully!")
            finally:
                cursor.close()
                conn.close()

def render_motivational_history(user_email: str) -> None:
    """Render motivational content history"""
    st.subheader("📚 Motivational History")
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT umh.*, 
                   CASE 
                       WHEN umh.content_type = 'quote' THEN mq.quote_text
                       WHEN umh.content_type = 'tip' THEN mt.tip_text
                   END as content_text,
                   CASE 
                       WHEN umh.content_type = 'quote' THEN mq.author
                       ELSE NULL
                   END as author
            FROM user_motivational_history umh
            LEFT JOIN motivational_quotes mq ON umh.content_type = 'quote' AND umh.content_id = mq.id
            LEFT JOIN motivational_tips mt ON umh.content_type = 'tip' AND umh.content_id = mt.id
            WHERE umh.user_email = %s
            ORDER BY umh.viewed_at DESC
            LIMIT 20
        """, (user_email.lower(),))
        
        history = cursor.fetchall()
        
        if not history:
            st.info("No motivational content viewed yet.")
            return
        
        for item in history:
            with st.expander(f"{item['content_type'].title()} - {item['viewed_at'].strftime('%Y-%m-%d %H:%M')}"):
                if item['content_type'] == 'quote':
                    st.markdown(f"**{item['content_text']}**")
                    if item['author']:
                        st.markdown(f"*— {item['author']}*")
                else:
                    st.markdown(f"**{item['content_text']}**")
                
                if item['context_trigger']:
                    st.caption(f"Context: {item['context_trigger']}")
                
                # Reaction buttons
                col1, col2, col3 = st.columns(3)
                with col1:
                    if st.button("👍 Helpful", key=f"helpful_{item['id']}"):
                        cursor.execute("""
                            UPDATE user_motivational_history 
                            SET user_reaction = 'liked', was_helpful = TRUE 
                            WHERE id = %s
                        """, (item['id'],))
                        conn.commit()
                        st.success("Marked as helpful!")
                        st.rerun()
                
                with col2:
                    if st.button("😐 Neutral", key=f"neutral_{item['id']}"):
                        cursor.execute("""
                            UPDATE user_motivational_history 
                            SET user_reaction = 'neutral', was_helpful = FALSE 
                            WHERE id = %s
                        """, (item['id'],))
                        conn.commit()
                        st.success("Marked as neutral!")
                        st.rerun()
                
                with col3:
                    if st.button("👎 Not Helpful", key=f"nothelpful_{item['id']}"):
                        cursor.execute("""
                            UPDATE user_motivational_history 
                            SET user_reaction = 'disliked', was_helpful = FALSE 
                            WHERE id = %s
                        """, (item['id'],))
                        conn.commit()
                        st.success("Marked as not helpful!")
                        st.rerun()
    
    finally:
        cursor.close()
        conn.close()

def render_motivational_manager(user_email: str):
    """Main motivational content manager"""
    # Ensure tables exist and are populated
    create_motivational_tables()
    populate_default_motivational_content()
    
    st.title("🌟 Motivational Center")
    
    # Get daily motivation
    daily_motivation = get_daily_motivation(user_email)
    
    # Display daily content
    st.subheader("📅 Today's Motivation")
    
    if daily_motivation['quote']:
        render_motivational_card(daily_motivation['quote'], 'quote')
    
    if daily_motivation['tip']:
        render_motivational_card(daily_motivation['tip'], 'tip')
    
    if not daily_motivation['quote'] and not daily_motivation['tip']:
        st.info("No motivational content available today. Check your preferences or try again tomorrow!")
    
    # Context analysis
    if daily_motivation['context']:
        st.write("---")
        st.subheader("🔍 Your Current Context")
        context = daily_motivation['context']
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("📊 Avg Completion", f"{context.get('avg_completion', 0):.1f}%")
        with col2:
            st.metric("🎯 Active Habits", context.get('active_habits', 0))
        with col3:
            st.metric("📋 Total Habits", context.get('total_habits', 0))
        
        if context.get('triggers'):
            st.write("**Current Triggers:**")
            for trigger in context['triggers']:
                st.write(f"• {trigger.replace('_', ' ').title()}")
    
    # Preferences and history
    st.write("---")
    
    tab1, tab2 = st.tabs(["⚙️ Preferences", "📚 History"])
    
    with tab1:
        render_motivational_preferences(user_email)
    
    with tab2:
        render_motivational_history(user_email)
