import streamlit as st
import mysql.connector
from datetime import datetime, timedelta, time
from typing import List, Dict, Optional, Tuple
import json

from src.db import get_db_connection

def create_snooze_table():
    """Create snooze_requests table if it doesn't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS snooze_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                reminder_id INT,
                notification_id INT,
                snooze_until TIMESTAMP NOT NULL,
                snooze_duration_minutes INT NOT NULL,
                original_time TIME,
                original_days VARCHAR(20),
                reminder_type ENUM('habit_reminder', 'notification') NOT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP GENERATED ALWAYS AS (DATE_ADD(created_at, INTERVAL snooze_duration_minutes MINUTE)) STORED,
                INDEX idx_user_email (user_email),
                INDEX idx_reminder_id (reminder_id),
                INDEX idx_notification_id (notification_id),
                INDEX idx_snooze_until (snooze_until),
                INDEX idx_expires_at (expires_at)
            )
        """)
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def create_snooze_request(user_email: str, reminder_id: Optional[int], 
                         notification_id: Optional[int], snooze_duration_minutes: int,
                         reminder_type: str, original_time: Optional[time] = None,
                         original_days: Optional[str] = None) -> bool:
    """Create a new snooze request"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        snooze_until = datetime.now() + timedelta(minutes=snooze_duration_minutes)
        
        cursor.execute("""
            INSERT INTO snooze_requests (user_email, reminder_id, notification_id, 
                                       snooze_until, snooze_duration_minutes, 
                                       original_time, original_days, reminder_type)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (user_email.lower(), reminder_id, notification_id, snooze_until, 
              snooze_duration_minutes, original_time, original_days, reminder_type))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error creating snooze request: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_active_snooze_requests(user_email: str) -> List[Dict]:
    """Get all active snooze requests for a user"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT sr.*, 
                   CASE 
                       WHEN sr.reminder_type = 'habit_reminder' THEN h.name
                       WHEN sr.reminder_type = 'notification' THEN nh.name
                       ELSE 'Unknown'
                   END as item_name
            FROM snooze_requests sr
            LEFT JOIN habit_reminders hr ON sr.reminder_id = hr.id
            LEFT JOIN habits h ON hr.habit_id = h.id
            LEFT JOIN notifications n ON sr.notification_id = n.id
            LEFT JOIN habits nh ON n.habit_id = nh.id
            WHERE sr.user_email = %s AND sr.is_active = TRUE AND sr.snooze_until > NOW()
            ORDER BY sr.snooze_until
        """, (user_email.lower(),))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def get_expired_snooze_requests(user_email: str) -> List[Dict]:
    """Get expired snooze requests that should be reactivated"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute("""
            SELECT sr.*, 
                   CASE 
                       WHEN sr.reminder_type = 'habit_reminder' THEN h.name
                       WHEN sr.reminder_type = 'notification' THEN nh.name
                       ELSE 'Unknown'
                   END as item_name
            FROM snooze_requests sr
            LEFT JOIN habit_reminders hr ON sr.reminder_id = hr.id
            LEFT JOIN habits h ON hr.habit_id = h.id
            LEFT JOIN notifications n ON sr.notification_id = n.id
            LEFT JOIN habits nh ON n.habit_id = nh.id
            WHERE sr.user_email = %s AND sr.is_active = TRUE AND sr.snooze_until <= NOW()
            ORDER BY sr.snooze_until
        """, (user_email.lower(),))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def cancel_snooze_request(snooze_id: int) -> bool:
    """Cancel a snooze request (set as inactive)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            UPDATE snooze_requests SET is_active = FALSE WHERE id = %s
        """, (snooze_id,))
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error canceling snooze: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def cleanup_expired_snooze_requests(user_email: str) -> int:
    """Mark expired snooze requests as inactive and return count"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            UPDATE snooze_requests 
            SET is_active = FALSE 
            WHERE user_email = %s AND is_active = TRUE AND snooze_until <= NOW()
        """, (user_email.lower(),))
        conn.commit()
        return cursor.rowcount
    finally:
        cursor.close()
        conn.close()

def is_item_snoozed(user_email: str, reminder_id: Optional[int], 
                    notification_id: Optional[int], reminder_type: str) -> bool:
    """Check if a specific reminder or notification is currently snoozed"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        if reminder_type == 'habit_reminder' and reminder_id:
            cursor.execute("""
                SELECT COUNT(*) FROM snooze_requests 
                WHERE user_email = %s AND reminder_id = %s AND reminder_type = %s 
                AND is_active = TRUE AND snooze_until > NOW()
            """, (user_email.lower(), reminder_id, reminder_type))
        elif reminder_type == 'notification' and notification_id:
            cursor.execute("""
                SELECT COUNT(*) FROM snooze_requests 
                WHERE user_email = %s AND notification_id = %s AND reminder_type = %s 
                AND is_active = TRUE AND snooze_until > NOW()
            """, (user_email.lower(), notification_id, reminder_type))
        else:
            return False
        
        return cursor.fetchone()[0] > 0
    finally:
        cursor.close()
        conn.close()

def get_snooze_options() -> List[Tuple[str, int]]:
    """Get predefined snooze options"""
    return [
        ("5 minutes", 5),
        ("10 minutes", 10),
        ("15 minutes", 15),
        ("30 minutes", 30),
        ("1 hour", 60),
        ("2 hours", 120),
        ("4 hours", 240),
        ("8 hours", 480),
        ("1 day", 1440),
        ("Custom", -1)
    ]

def render_snooze_dialog(user_email: str, reminder_id: Optional[int], 
                        notification_id: Optional[int], reminder_type: str,
                        item_name: str, original_time: Optional[time] = None,
                        original_days: Optional[str] = None) -> bool:
    """Render snooze dialog for a reminder or notification"""
    st.subheader(f"⏰ Snooze: {item_name}")
    
    snooze_options = get_snooze_options()
    option_labels = [opt[0] for opt in snooze_options]
    
    selected_option = st.selectbox("Snooze for:", options=option_labels)
    
    custom_minutes = None
    if selected_option == "Custom":
        custom_minutes = st.number_input(
            "Custom minutes:", 
            min_value=1, 
            max_value=10080,  # Max 1 week
            value=30
        )
    
    snooze_duration = None
    for label, minutes in snooze_options:
        if label == selected_option:
            snooze_duration = minutes if minutes != -1 else custom_minutes
            break
    
    if snooze_duration is None:
        st.error("Please select a valid snooze duration")
        return False
    
    # Show snooze until time
    snooze_until = datetime.now() + timedelta(minutes=snooze_duration)
    st.info(f"Reminder will appear again at: {snooze_until.strftime('%Y-%m-%d %H:%M')}")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("✅ Confirm Snooze", key=f"confirm_snooze_{reminder_id}_{notification_id}"):
            if create_snooze_request(
                user_email, reminder_id, notification_id, 
                snooze_duration, reminder_type, original_time, original_days
            ):
                st.success(f"Snoozed {item_name} for {selected_option}")
                st.rerun()
                return True
    with col2:
        if st.button("❌ Cancel", key=f"cancel_snooze_{reminder_id}_{notification_id}"):
            st.info("Snooze canceled")
            return False
    
    return False

def render_snooze_list(user_email: str):
    """Render list of active snooze requests"""
    active_snoozes = get_active_snooze_requests(user_email)
    
    if not active_snoozes:
        st.info("No active snooze requests.")
        return
    
    st.subheader("🔕 Active Snooze Requests")
    
    for snooze in active_snoozes:
        with st.expander(f"⏰ {snooze['item_name']} - Snoozed until {snooze['snooze_until'].strftime('%Y-%m-%d %H:%M')}"):
            st.write(f"**Duration:** {snooze['snooze_duration_minutes']} minutes")
            st.write(f"**Type:** {snooze['reminder_type'].replace('_', ' ').title()}")
            st.write(f"**Snoozed at:** {snooze['created_at'].strftime('%Y-%m-%d %H:%M')}")
            
            time_remaining = snooze['snooze_until'] - datetime.now()
            if time_remaining.total_seconds() > 0:
                hours, remainder = divmod(time_remaining.total_seconds(), 3600)
                minutes, seconds = divmod(remainder, 60)
                st.write(f"**Time remaining:** {int(hours)}h {int(minutes)}m")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🔔 Wake Up Now", key=f"wakeup_{snooze['id']}"):
                    if cancel_snooze_request(snooze['id']):
                        st.success(f"Reminder '{snooze['item_name']}' restored!")
                        st.rerun()
            with col2:
                if st.button("🗑️ Delete", key=f"delete_snooze_{snooze['id']}"):
                    if cancel_snooze_request(snooze['id']):
                        st.success("Snooze request deleted!")
                        st.rerun()

def check_and_show_expired_snoozes(user_email: str):
    """Check for expired snooze requests and show them"""
    expired = get_expired_snooze_requests(user_email)
    
    if expired:
        st.success("🔔 **Snoozed Reminders Back:**")
        for snooze in expired:
            st.info(f"⏰ **{snooze['item_name']}** - Your snooze has expired!")
            
            # Mark as inactive
            cancel_snooze_request(snooze['id'])
        
        # Clean up expired snoozes
        cleanup_expired_snooze_requests(user_email)

def render_snooze_manager(user_email: str):
    """Main snooze management page"""
    st.title("🔕 Snooze Manager")
    
    # Create snooze table if it doesn't exist
    create_snooze_table()
    
    # Check for expired snoozes
    check_and_show_expired_snoozes(user_email)
    
    # Tab layout
    tab1, tab2 = st.tabs(["🔕 Active Snoozes", "📊 Snooze Statistics"])
    
    with tab1:
        render_snooze_list(user_email)
    
    with tab2:
        st.subheader("Snooze Statistics")
        
        active_snoozes = get_active_snooze_requests(user_email)
        
        if active_snoozes:
            # Calculate statistics
            total_snoozes = len(active_snoozes)
            
            # Group by snooze duration ranges
            duration_ranges = {
                "Under 30 min": 0,
                "30 min - 1 hour": 0,
                "1 - 4 hours": 0,
                "4 - 8 hours": 0,
                "Over 8 hours": 0
            }
            
            for snooze in active_snoozes:
                duration = snooze['snooze_duration_minutes']
                if duration < 30:
                    duration_ranges["Under 30 min"] += 1
                elif duration <= 60:
                    duration_ranges["30 min - 1 hour"] += 1
                elif duration <= 240:
                    duration_ranges["1 - 4 hours"] += 1
                elif duration <= 480:
                    duration_ranges["4 - 8 hours"] += 1
                else:
                    duration_ranges["Over 8 hours"] += 1
            
            st.metric("Total Active Snoozes", total_snoozes)
            
            st.write("**Snooze Duration Distribution:**")
            for range_name, count in duration_ranges.items():
                if count > 0:
                    st.write(f"- {range_name}: {count}")
        else:
            st.info("No snooze statistics available.")

def get_snooze_button(user_email: str, reminder_id: Optional[int], 
                     notification_id: Optional[int], reminder_type: str,
                     item_name: str, original_time: Optional[time] = None,
                     original_days: Optional[str] = None) -> bool:
    """Render a snooze button and handle snooze action"""
    
    # Check if already snoozed
    if is_item_snoozed(user_email, reminder_id, notification_id, reminder_type):
        snooze_requests = get_active_snooze_requests(user_email)
        for snooze in snooze_requests:
            if ((reminder_type == 'habit_reminder' and snooze['reminder_id'] == reminder_id) or
                (reminder_type == 'notification' and snooze['notification_id'] == notification_id)):
                time_remaining = snooze['snooze_until'] - datetime.now()
                if time_remaining.total_seconds() > 0:
                    hours, remainder = divmod(time_remaining.total_seconds(), 3600)
                    minutes, seconds = divmod(remainder, 60)
                    st.info(f"🔕 Snoozed for {int(hours)}h {int(minutes)}m")
                    return False
    
    if st.button(f"⏰ Snooze {item_name}", key=f"snooze_btn_{reminder_id}_{notification_id}"):
        # Store snooze request in session state
        st.session_state[f"snooze_dialog_{reminder_id}_{notification_id}"] = {
            'user_email': user_email,
            'reminder_id': reminder_id,
            'notification_id': notification_id,
            'reminder_type': reminder_type,
            'item_name': item_name,
            'original_time': original_time,
            'original_days': original_days
        }
        st.rerun()
    
    # Check if we need to show snooze dialog
    dialog_key = f"snooze_dialog_{reminder_id}_{notification_id}"
    if dialog_key in st.session_state:
        dialog_data = st.session_state[dialog_key]
        
        with st.expander("⏰ Snooze Options", expanded=True):
            success = render_snooze_dialog(
                dialog_data['user_email'],
                dialog_data['reminder_id'],
                dialog_data['notification_id'],
                dialog_data['reminder_type'],
                dialog_data['item_name'],
                dialog_data['original_time'],
                dialog_data['original_days']
            )
            
            if success or st.button("Close", key=f"close_snooze_{reminder_id}_{notification_id}"):
                del st.session_state[dialog_key]
                st.rerun()
    
    return True
