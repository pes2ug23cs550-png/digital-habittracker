import streamlit as st

try:
    import mysql.connector
except Exception:
    mysql = None


def get_conn():
    if mysql is None:
        raise RuntimeError("mysql-connector-python is required")
    cfg = st.secrets.get("mysql", {})
    kwargs = {
        "host": cfg.get("host", "localhost"),
        "user": cfg.get("user", "root"),
        "password": cfg.get("password", "rahul"),
        "database": cfg.get("database", "habit"),
        "port": int(cfg.get("port", 3306)),
    }
    if cfg.get("auth_plugin"):
        kwargs["auth_plugin"] = cfg.get("auth_plugin")
    return mysql.connector.connect(**kwargs)


# Alias for backward compatibility
def get_db_connection():
    return get_conn()
