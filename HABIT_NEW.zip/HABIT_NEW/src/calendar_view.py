import calendar
from datetime import date, datetime, timedelta
import streamlit as st
from .db import get_conn


def _get_logs_map(habit_id: int, start: date, end: date) -> set[date]:
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            SELECT log_date FROM habit_logs
            WHERE habit_id=%s AND log_date BETWEEN %s AND %s
            """,
            (habit_id, start, end),
        )
        rows = cur.fetchall() or []
        return {r[0] if isinstance(r[0], date) else datetime.strptime(str(r[0]), "%Y-%m-%d").date() for r in rows}


def get_current_and_best_streak(habit_id: int) -> tuple[int, int]:
    """Compute current and best daily streaks for a habit based on habit_logs."""
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT log_date FROM habit_logs WHERE habit_id=%s ORDER BY log_date DESC",
            (habit_id,),
        )
        rows = [r[0] for r in (cur.fetchall() or [])]
    # Normalize to date objects
    logs = []
    for v in rows:
        if isinstance(v, date):
            logs.append(v)
        else:
            try:
                logs.append(datetime.strptime(str(v), "%Y-%m-%d").date())
            except Exception:
                pass
    s = set(logs)
    # current streak from today backwards
    cur_streak = 0
    d = date.today()
    while d in s:
        cur_streak += 1
        d = d - timedelta(days=1)
    # best streak
    best = 0
    visited = set()
    for dt in s:
        if dt in visited:
            continue
        # walk back to start of streak
        start_dt = dt
        while (start_dt - timedelta(days=1)) in s:
            start_dt = start_dt - timedelta(days=1)
        # count forward
        length = 0
        cur_dt = start_dt
        while cur_dt in s:
            visited.add(cur_dt)
            length += 1
            cur_dt = cur_dt + timedelta(days=1)
        if length > best:
            best = length
    return cur_streak, best


def render_month_calendar(habit_id: int, year: int, month: int):
    """Render a simple month calendar with colored squares for completion days."""
    cal = calendar.Calendar(firstweekday=0)  # Monday=0 in py docs, but calendar uses Monday=0? Actually default 0=Monday? We'll show weeks as returned
    month_days = list(cal.itermonthdates(year, month))
    start = date(year, month, 1)
    end = date(year, month, calendar.monthrange(year, month)[1])
    logs = _get_logs_map(habit_id, start, end)

    st.caption(f"{calendar.month_name[month]} {year}")
    # Build 7 columns header
    cols = st.columns(7)
    for i, wd in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]):
        with cols[i]:
            st.markdown(f"**{wd}**")
    # Render weeks
    week = []
    for dt in month_days:
        if dt.month != month:
            week.append((dt, False))
        else:
            week.append((dt, True))
        if len(week) == 7:
            cols = st.columns(7)
            for i, (dte, in_month) in enumerate(week):
                with cols[i]:
                    if not in_month:
                        st.write(" ")
                    else:
                        done = dte in logs
                        bg = "#22c55e" if done else "#334155"
                        fg = "#000" if done else "#cbd5e1"
                        st.markdown(
                            f"<div style='text-align:center;border-radius:6px;padding:8px;background:{bg};color:{fg};'>{dte.day}</div>",
                            unsafe_allow_html=True,
                        )
            week = []
    if week:
        # remaining days of last week
        cols = st.columns(7)
        for i in range(7):
            if i < len(week):
                dte, in_month = week[i]
                with cols[i]:
                    if not in_month:
                        st.write(" ")
                    else:
                        done = dte in logs
                        bg = "#22c55e" if done else "#334155"
                        fg = "#000" if done else "#cbd5e1"
                        st.markdown(
                            f"<div style='text-align:center;border-radius:6px;padding:8px;background:{bg};color:{fg};'>{dte.day}</div>",
                            unsafe_allow_html=True,
                        )


def render_calendar_block(habit_id: int):
    today = date.today()
    y = st.number_input("Year", min_value=2000, max_value=2100, value=today.year, step=1, key=f"cal_year_{habit_id}")
    m = st.number_input("Month", min_value=1, max_value=12, value=today.month, step=1, key=f"cal_month_{habit_id}")
    render_month_calendar(habit_id, int(y), int(m))
    cur_streak, best = get_current_and_best_streak(habit_id)
    st.caption(f"Current streak: {cur_streak} days • Best streak: {best} days")
