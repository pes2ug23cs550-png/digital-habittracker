from datetime import date
import streamlit as st
from .db import get_conn


def _init_tables():
    # Ensure required tables exist (idempotent)
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habits (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                name VARCHAR(255) NOT NULL,
                goal INT NOT NULL DEFAULT 1,
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_habit (user_email, name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habit_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL,
                log_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_habit_date (habit_id, log_date),
                CONSTRAINT fk_habit_logs_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cnx.commit()


def mark_today(habit_id: int) -> bool:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "INSERT INTO habit_logs (habit_id, log_date, completed_at) VALUES (%s,%s, CURRENT_TIMESTAMP)",
                (habit_id, date.today()),
            )
            cnx.commit()
            return True
        except Exception:
            return False


def is_marked_today(habit_id: int) -> bool:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT 1 FROM habit_logs WHERE habit_id=%s AND log_date=%s",
            (habit_id, date.today()),
        )
        return cur.fetchone() is not None


def recent_logs(habit_id: int, limit: int = 10) -> list[tuple]:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT log_date FROM habit_logs WHERE habit_id=%s ORDER BY log_date DESC LIMIT %s",
            (habit_id, limit),
        )
        return cur.fetchall()
