from datetime import date
import streamlit as st
from .db import get_conn


def _init_tables():
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habits (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_email VARCHAR(255) NOT NULL,
                name VARCHAR(255) NOT NULL,
                goal INT NOT NULL DEFAULT 1,
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_user_habit (user_email, name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        # Backfill/migration for existing tables missing 'goal'
        try:
            cur.execute(
                """
                ALTER TABLE habits
                ADD COLUMN IF NOT EXISTS goal INT NOT NULL DEFAULT 1
                """
            )
        except Exception:
            try:
                cur.execute("SHOW COLUMNS FROM habits LIKE 'goal'")
                if not cur.fetchone():
                    cur.execute("ALTER TABLE habits ADD COLUMN goal INT NOT NULL DEFAULT 1")
            except Exception:
                pass
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habit_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL,
                log_date DATE NOT NULL,
                amount INT DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_habit_date (habit_id, log_date),
                CONSTRAINT fk_habit_logs_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        
        # Add amount column to existing habit_logs table if it doesn't exist
        try:
            cur.execute("SELECT amount FROM habit_logs LIMIT 1")
            cur.fetchone()
        except Exception:
            cur.execute("ALTER TABLE habit_logs ADD COLUMN amount INT DEFAULT 1")
        
        cnx.commit()


def create_habit(user_email: str, name: str, goal: int = 1) -> bool:
    _init_tables()
    if not name.strip():
        st.warning("Habit name cannot be empty")
        return False
    if goal is None or int(goal) < 1:
        st.warning("Goal must be at least 1")
        return False
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "INSERT INTO habits (user_email, name, goal) VALUES (%s,%s,%s)",
                (user_email.lower(), name.strip(), int(goal)),
            )
            cnx.commit()
            return True
        except Exception as e:
            st.warning("Habit already exists or invalid")
            return False


def list_habits(user_email: str) -> list[tuple]:
    _init_tables()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT id, name, goal, is_active FROM habits WHERE user_email=%s ORDER BY created_at DESC",
            (user_email.lower(),),
        )
        return cur.fetchall()


def is_marked_today(habit_id: int) -> bool:
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT 1 FROM habit_logs WHERE habit_id=%s AND log_date=%s",
            (habit_id, date.today()),
        )
        return cur.fetchone() is not None


def mark_today(habit_id: int) -> bool:
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            cur.execute(
                "INSERT INTO habit_logs (habit_id, log_date, amount, completed_at) VALUES (%s,%s,1, CURRENT_TIMESTAMP)",
                (habit_id, date.today()),
            )
            cnx.commit()
            return True
        except Exception:
            return False


def recent_logs(habit_id: int, limit: int = 10) -> list[tuple]:
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT log_date FROM habit_logs WHERE habit_id=%s ORDER BY log_date DESC LIMIT %s",
            (habit_id, limit),
        )
        return cur.fetchall()
