import streamlit as st
from .db import get_conn


def _init_table():
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS habit_category (
                id INT AUTO_INCREMENT PRIMARY KEY,
                habit_id INT NOT NULL UNIQUE,
                category VARCHAR(64) NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_habit_cat_habit
                    FOREIGN KEY (habit_id) REFERENCES habits(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        )
        cnx.commit()


def set_category(habit_id: int, category: str | None) -> bool:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        try:
            if category is None or not str(category).strip():
                # unset category by deleting mapping
                cur.execute("DELETE FROM habit_category WHERE habit_id=%s", (habit_id,))
                cnx.commit()
                return True
            # upsert mapping
            cur.execute(
                "INSERT INTO habit_category (habit_id, category) VALUES (%s,%s)\n                 ON DUPLICATE KEY UPDATE category=VALUES(category)",
                (habit_id, category.strip()),
            )
            cnx.commit()
            return True
        except Exception:
            return False


def get_category(habit_id: int) -> str | None:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute("SELECT category FROM habit_category WHERE habit_id=%s", (habit_id,))
        row = cur.fetchone()
        return row[0] if row else None


def get_categories_for_user(user_email: str) -> list[str]:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            SELECT DISTINCT hc.category
            FROM habits h
            LEFT JOIN habit_category hc ON hc.habit_id = h.id
            WHERE h.user_email=%s AND hc.category IS NOT NULL AND hc.category <> ''
            ORDER BY hc.category ASC
            """,
            (user_email.lower(),),
        )
        rows = cur.fetchall() or []
        return [r[0] for r in rows if r and r[0]]


def get_category_map_for_user(user_email: str) -> dict[int, str | None]:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            """
            SELECT h.id, hc.category
            FROM habits h
            LEFT JOIN habit_category hc ON hc.habit_id = h.id
            WHERE h.user_email=%s
            """,
            (user_email.lower(),),
        )
        rows = cur.fetchall() or []
        return {int(hid): (cat if cat else None) for hid, cat in rows}


def set_category_by_name(user_email: str, habit_name: str, category: str | None) -> bool:
    _init_table()
    with get_conn() as cnx:
        cur = cnx.cursor()
        cur.execute(
            "SELECT id FROM habits WHERE user_email=%s AND name=%s",
            (user_email.lower(), habit_name.strip()),
        )
        row = cur.fetchone()
        if not row:
            return False
        habit_id = int(row[0])
        return set_category(habit_id, category)
